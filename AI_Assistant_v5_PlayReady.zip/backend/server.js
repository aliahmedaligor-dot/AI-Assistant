import 'dotenv/config';
import express from 'express';
import multer from 'multer';

const app = express();
const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 8 * 1024 * 1024 } });
const PORT = process.env.PORT || 8080;
const MODEL = process.env.AI_MODEL || 'gpt-5.6-luna';

const SYSTEM = `أنت AI Assistant، مساعد عربي عام.
أجب بالعربية السهلة إذا كتب المستخدم بالعربية، وبنفس لغة المستخدم إن كانت مختلفة.
في الرياضيات: اعرض خطوات الحل وتحقق من النتيجة.
في أسئلة الهاتف: قدم خطوات عملية وآمنة ولا تدّعي معرفة شيء غير متاح.
في الصور: صف ما تراه بدقة وحل المسائل الظاهرة إن أمكن.
إذا كان البحث مفعلاً، استخدمه للمعلومات التي تحتاج حداثة واذكر المصادر باختصار.
لا تخترع حقائق أو مصادر.`;

function dataUrl(file) {
  const mime = file.mimetype || 'image/jpeg';
  return `data:${mime};base64,${file.buffer.toString('base64')}`;
}

app.get('/health', (_req,res)=>res.json({ok:true, model:MODEL}));

app.post('/chat', upload.single('image'), async (req,res)=>{
  const message = String(req.body?.message || '').trim();
  const webSearch = String(req.body?.web_search || 'false') === 'true';
  if (!message && !req.file) return res.status(400).json({error:'message required'});
  if (!process.env.OPENAI_API_KEY) return res.status(500).json({error:'OPENAI_API_KEY missing'});

  const content = [];
  content.push({ type:'input_text', text: message || 'حلل هذه الصورة.' });
  if (req.file) content.push({ type:'input_image', image_url:dataUrl(req.file) });

  const payload = {
    model: MODEL,
    instructions: SYSTEM,
    input: [{ role:'user', content }]
  };
  if (webSearch) payload.tools = [{ type:'web_search' }];

  try {
    const r = await fetch('https://api.openai.com/v1/responses', {
      method:'POST',
      headers:{'Authorization':`Bearer ${process.env.OPENAI_API_KEY}`,'Content-Type':'application/json'},
      body:JSON.stringify(payload)
    });
    const raw = await r.text();
    let data;
    try { data = JSON.parse(raw); } catch { data = {error:raw}; }
    if (!r.ok) return res.status(r.status).json({error:data?.error?.message || 'AI request failed'});
    const reply = data.output_text || data.output?.flatMap(x=>x.content||[]).map(x=>x.text||'').join('') || 'لم تصل إجابة.';
    res.json({reply, model:MODEL});
  } catch (e) {
    res.status(500).json({error:'Server error', detail:e.message});
  }
});

app.listen(PORT,()=>console.log(`AI Assistant backend listening on ${PORT}`));
