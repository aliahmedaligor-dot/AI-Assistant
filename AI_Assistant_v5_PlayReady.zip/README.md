# AI Assistant v1.4

نسخة أقرب للتشغيل الفعلي:
- واجهة عربية RTL.
- إرسال نص + صورة إلى Backend واحد.
- البحث على الويب من الخادم عند تفعيله.
- مفتاح OpenAI يبقى على الخادم.
- نقطة `/health` لفحص الخادم.

## تشغيل الـBackend
داخل مجلد `backend`:
1. `npm install`
2. انسخ `.env.example` إلى `.env`
3. ضع `OPENAI_API_KEY`
4. `npm start`

ثم غيّر `apiUrl` في `lib/main.dart` إلى عنوان الخادم.

## ملاحظة الصوت
النسخة الحالية تسجل الصوت محلياً في التطبيق. تحويل التسجيل إلى نص يحتاج إضافة endpoint `/transcribe` وربطه بنموذج تفريغ صوتي، ثم إرسال النص إلى `/chat`.

## Android
بعد `flutter create .` أو داخل مشروع Flutter:
- تأكد من صلاحية الميكروفون للتسجيل.
- اختبر الكاميرا والمعرض على جهاز حقيقي.
- لا تضع OPENAI_API_KEY داخل التطبيق.

النماذج الحالية في وثائق OpenAI تدعم إدخال النص والصور عبر Responses API، وGPT-5.6 Luna مخصص للتطبيقات الحساسة للتكلفة، كما أن Web search متاح كأداة للنماذج الحديثة.


## Google Play readiness
- `PRIVACY_POLICY.md`: نموذج سياسة الخصوصية يجب استضافته على رابط HTTPS قبل النشر.
- `GOOGLE_PLAY_LISTING.md`: مسودة وصف المتجر.
- `app_icon.svg`: مصدر هوية الأيقونة.
- لا تضع `OPENAI_API_KEY` داخل Flutter.
- أنشئ Android App Bundle من بيئة Flutter/Android، ثم وقّعه بمفتاح إصدار محفوظ بأمان.

### مهم
هذه الحزمة لا تحتوي على Android SDK/Flutter toolchain نفسه، لذلك لا يمكنني من هذه البيئة إخراج ملف `.aab` موقّع نهائياً. الكود والـBackend جاهزان للبناء في بيئة Flutter.
