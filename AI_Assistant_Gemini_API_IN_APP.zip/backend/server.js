import 'dotenv/config';
import express from 'express';
import multer from 'multer';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import Database from 'better-sqlite3';

const app = express();
const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 18 * 1024 * 1024 } });
const PORT = process.env.PORT || 8080;
const JWT_SECRET = process.env.JWT_SECRET || 'CHANGE_THIS_SECRET_IN_PRODUCTION';
const GEMINI_MODEL = process.env.GEMINI_MODEL || 'gemini-3.8-flash';
const GROQ_MODEL = process.env.GROQ_MODEL || 'openai/gpt-oss-120b';
const GROQ_FALLBACK_MODEL = process.env.GROQ_FALLBACK_MODEL || 'qwen/qwen3.8-27b';
const CREATOR_NAME = process.env.CREATOR_NAME || 'المبرمج علي أحمد قرباج (Ali Ahmed Gorbag)';

const db = new Database(process.env.DB_PATH || 'ai_assistant.sqlite');
db.pragma('journal_mode = WAL');
db.exec(`
CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  email TEXT NOT NULL UNIQUE,
  password_hash TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  last_seen TEXT
);
CREATE TABLE IF NOT EXISTS usage (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL,
  provider TEXT NOT NULL,
  kind TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY(user_id) REFERENCES users(id)
);
`);

const SYSTEM = `
أنت AI Assistant عربي متقدم جدًا.
أجب بلغة المستخدم وبأسلوب طبيعي ومنظم يشبه مساعدًا حديثًا: لا تعرض عناوين Markdown غريبة مثل ### للمستخدم؛ استخدم عناوين واضحة أو نصًا عاديًا. لا تحيط المعادلات بعلامات الدولار.
افهم وتفاعل بطلاقة مع جميع اللهجات العربية (الخليجية، الليبية، المصرية، الشامية، المغربية، وغيرها) وبأي لغة عالمية أخرى يكتب بها المستخدم، وحاول الرد بنفس لهجته أو لغته.
مرجع لهجة ليبية: «نبي/نبغي»=أريد، «عايز»=أريد، «دير/ديري لي»=اعمل لي، «شنو»=ماذا، «كيفاش»=كيف، «وقتاش»=متى، «علاش»=لماذا، «برشة»=كثير جدًا، «توا»=الآن، «ماشي»=حسنًا، «حوس»=ابحث. استخدمها لفهم الليبي فعليًا بدل التخمين.
افهم السياق كاملًا وتتبع حالة الأشياء زمنيًا ومكانيًا.
في الرياضيات والفيزياء والعلوم: احسب وتحقق من النتيجة قبل الإجابة، واعرض الخطوات عند الحاجة.
إذا طلب المستخدم عددًا محددًا من الكلمات، يجب أن يكون النص النهائي بعد مراجعة العدد مطابقًا للعدد المطلوب تمامًا.
إذا سأل المستخدم عن صانع التطبيق أو مطوره، قل: «صانع هذا التطبيق هو ${CREATOR_NAME}، وهو مبرمج يطوّر تطبيقات مثل هذا التطبيق.».
إذا طلب إنشاء صورة، أخبره أن التطبيق يستطيع إنشاء الصور وسيعرض الصورة نفسها داخل المحادثة تلقائيًا. ممنوع كتابة رابط الصورة كنص عادي أبدًا.
إذا كان البحث متاحًا، استخدم Google Search وأعد روابط حقيقية قابلة للفتح فعليًا. عند طلب تطبيق أو لعبة أعد رابط Google Play الرسمي المباشر إن وُجد. لا تخترع روابط.
`;

app.use(express.json({ limit: '25mb' }));

function tokenFor(user) {
  return jwt.sign({ id: user.id, email: user.email, name: user.name }, JWT_SECRET, { expiresIn: '30d' });
}
function auth(req, res, next) {
  const raw = String(req.headers.authorization || '');
  const token = raw.startsWith('Bearer ') ? raw.slice(7) : '';
  try { req.user = jwt.verify(token, JWT_SECRET); next(); }
  catch { res.status(401).json({ error: 'انتهت الجلسة. سجّل الدخول مرة أخرى.' }); }
}
function history(raw) {
  try {
    return JSON.parse(raw || '[]').slice(-18).map(x => ({
      role: x.role === 'assistant' ? 'model' : 'user',
      parts: [{ text: String(x.text || '') }]
    }));
  } catch { return []; }
}
function urls(x) {
  const out = new Set();
  const walk = v => {
    if (Array.isArray(v)) v.forEach(walk);
    else if (v && typeof v === 'object') Object.values(v).forEach(z => {
      if (typeof z === 'string' && /^https?:\/\//i.test(z)) out.add(z);
      walk(z);
    });
  };
  walk(x);
  return [...out].slice(0, 16);
}
function mime(file) { return file?.mimetype || 'application/octet-stream'; }
function countWords(text) { return String(text).trim().split(/\s+/u).filter(Boolean).length; }
function requestedWordCount(message) {
  const s = String(message);
  const patterns = [
    /(?:جملة|نص|إجابة|كلام)\s*(?:من|تتكون من)\s*(\d+)\s*كلم(?:ة|ات)/iu,
    /(?:exactly|exact)\s*(\d+)\s*words?/iu,
    /(?:بالضبط|فقط)\s*(\d+)\s*كلمة/iu,
  ];
  for (const p of patterns) { const m = s.match(p); if (m) return Number(m[1]); }
  return null;
}
async function repairWordCount(answer, original, target, providerCall) {
  if (!target || countWords(answer) === target) return answer;
  let current = answer;
  for (let i = 0; i < 2; i++) {
    current = await providerCall(`أعد صياغة إجابتك التالية لتصبح ${target} كلمة بالضبط، لا أكثر ولا أقل. حافظ على المعنى وأجب فقط بالنص النهائي دون شرح أو تعداد.\n\nالسؤال الأصلي: ${original}\n\nالإجابة: ${current}`);
    if (countWords(current) === target) return current.trim();
  }
  return current.trim();
}

app.get('/health', (_, res) => res.json({ ok: true, accounts: true, creator: CREATOR_NAME }));

app.post('/auth/register', async (req, res) => {
  const name = String(req.body?.name || '').trim();
  const email = String(req.body?.email || '').trim().toLowerCase();
  const password = String(req.body?.password || '');
  if (name.length < 2 || !/^\S+@\S+\.\S+$/u.test(email) || password.length < 8) {
    return res.status(400).json({ error: 'أدخل اسمًا وبريدًا صحيحين وكلمة مرور من 8 أحرف على الأقل.' });
  }
  try {
    const hash = await bcrypt.hash(password, 12);
    const info = db.prepare('INSERT INTO users(name,email,password_hash) VALUES(?,?,?)').run(name, email, hash);
    const user = { id: info.lastInsertRowid, name, email };
    res.status(201).json({ token: tokenFor(user), user });
  } catch (e) {
    res.status(409).json({ error: 'هذا البريد مستخدم بالفعل.' });
  }
});

app.post('/auth/login', async (req, res) => {
  const email = String(req.body?.email || '').trim().toLowerCase();
  const password = String(req.body?.password || '');
  const user = db.prepare('SELECT id,name,email,password_hash FROM users WHERE email=?').get(email);
  if (!user || !(await bcrypt.compare(password, user.password_hash))) return res.status(401).json({ error: 'البريد أو كلمة المرور غير صحيحة.' });
  db.prepare('UPDATE users SET last_seen=CURRENT_TIMESTAMP WHERE id=?').run(user.id);
  res.json({ token: tokenFor(user), user: { id: user.id, name: user.name, email: user.email } });
});

app.get('/auth/me', auth, (req, res) => {
  const user = db.prepare('SELECT id,name,email,created_at,last_seen FROM users WHERE id=?').get(req.user.id);
  if (!user) return res.status(404).json({ error: 'الحساب غير موجود.' });
  res.json({ user });
});

app.get('/usage', auth, (req, res) => {
  const total = db.prepare('SELECT COUNT(*) AS n FROM usage WHERE user_id=?').get(req.user.id).n;
  const today = db.prepare("SELECT COUNT(*) AS n FROM usage WHERE user_id=? AND date(created_at)=date('now')").get(req.user.id).n;
  const byProvider = db.prepare('SELECT provider, COUNT(*) AS n FROM usage WHERE user_id=? GROUP BY provider').all(req.user.id);
  const registeredUsers = db.prepare('SELECT COUNT(*) AS n FROM users').get().n;
  res.json({ total, today, byProvider, registeredUsers });
});

async function gemini(message, hist, web, file) {
  if (!process.env.GEMINI_API_KEY) throw Error('GEMINI_API_KEY missing');
  const parts = [{ text: message }];
  if (file) parts.push({ inline_data: { mime_type: mime(file), data: file.buffer.toString('base64') } });
  const body = { systemInstruction: { parts: [{ text: SYSTEM }] }, contents: [...hist, { role: 'user', parts }] };
  if (web) body.tools = [{ google_search: {} }];
  const r = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${GEMINI_MODEL}:generateContent?key=${encodeURIComponent(process.env.GEMINI_API_KEY)}`, {
    method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body)
  });
  const d = await r.json();
  if (!r.ok) throw Error(d?.error?.message || 'Gemini request failed');
  let text = (d?.candidates?.[0]?.content?.parts || []).map(x => x.text || '').join('').trim() || 'لم تصل إجابة.';
  return { reply: text, sources: urls(d), provider: 'gemini' };
}

async function groq(message, hist, file) {
  if (!process.env.GROQ_API_KEY) throw Error('GROQ_API_KEY missing');
  const image = file && /^image\//.test(file.mimetype || '');
  const base = [{ role: 'system', content: SYSTEM }, ...hist.map(x => ({ role: x.role === 'model' ? 'assistant' : 'user', content: x.parts?.[0]?.text || '' }))];
  if (image) base.push({ role: 'user', content: [{ type: 'text', text: message }, { type: 'image_url', image_url: { url: `data:${file.mimetype};base64,${file.buffer.toString('base64')}` } }] });
  else base.push({ role: 'user', content: message });
  let last;
  for (const model of [GROQ_MODEL, GROQ_FALLBACK_MODEL]) {
    try {
      const r = await fetch('https://api.groq.com/openai/v1/chat/completions', {
        method: 'POST', headers: { Authorization: `Bearer ${process.env.GROQ_API_KEY}`, 'Content-Type': 'application/json' },
        body: JSON.stringify({ model: image ? 'qwen/qwen3.8-27b' : model, messages: base, temperature: .15, reasoning_effort: 'medium' })
      });
      const d = await r.json();
      if (!r.ok) throw Error(d?.error?.message || `Groq request failed (${r.status})`);
      const text = String(d?.choices?.[0]?.message?.content || '').trim();
      if (text) return { reply: text, sources: [], provider: 'groq' };
      throw Error('Groq returned an empty response');
    } catch (e) { last = e; if (image) break; }
  }
  throw last || Error('Groq request failed');
}

app.post('/chat', auth, upload.single('file'), async (req, res) => {
  const message = String(req.body?.message || '').trim();
  if (!message && !req.file) return res.status(400).json({ error: 'message required' });
  const web = String(req.body?.web_search) === 'true';
  const hist = history(req.body?.history);
  const target = requestedWordCount(message);
  try {
    let out;
    try { out = await gemini(message || 'حلل الملف المرفق.', hist, web, req.file); }
    catch { out = await groq(message || 'حلل الملف المرفق.', hist, req.file); }
    if (target) {
      const repair = async prompt => {
        const x = await gemini(prompt, [], false, null).catch(() => groq(prompt, [], null));
        return x.reply;
      };
      out.reply = await repairWordCount(out.reply, message, target, repair);
    }
    db.prepare('INSERT INTO usage(user_id,provider,kind) VALUES(?,?,?)').run(req.user.id, out.provider || 'unknown', req.file ? 'file' : 'chat');
    res.json(out);
  } catch (e) { res.status(500).json({ error: e.message }); }
});

app.listen(PORT, () => console.log(`AI Assistant backend listening on ${PORT}`));
