import 'dotenv/config';
import express from 'express';
import os from 'node:os';
import path from 'node:path';
import fs from 'node:fs';
import multer from 'multer';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import Database from 'better-sqlite3';
import { LoreMotionBrowser, LoreMotionClient, loreMotionConfig } from './loremotion.js';
import { composeVideo, extractLastFrame, probeMedia } from './video_pipeline.js';

const app = express();
const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 18 * 1024 * 1024 } });
const PORT = process.env.PORT || 8080;
const JWT_SECRET = process.env.JWT_SECRET || 'CHANGE_THIS_SECRET_IN_PRODUCTION';
const GEMINI_MODEL = process.env.GEMINI_MODEL || 'gemini-3.8-flash';
const GROQ_MODEL = process.env.GROQ_MODEL || 'openai/gpt-oss-120b';
const GROQ_FALLBACK_MODEL = process.env.GROQ_FALLBACK_MODEL || 'qwen/qwen3.8-27b';
const CREATOR_NAME = process.env.CREATOR_NAME || 'المبرمج علي أحمد قرباج (Ali Ahmed Gorbaj)';
const VIDEO_DEFAULT_DURATION_SECONDS = Math.max(3, Math.min(600, Number(process.env.VIDEO_DEFAULT_DURATION_SECONDS || 30)));
const VIDEO_MAX_DURATION_SECONDS = Math.max(VIDEO_DEFAULT_DURATION_SECONDS, Math.min(3600, Number(process.env.VIDEO_MAX_DURATION_SECONDS || 3600)));
const VIDEO_TRANSITION_SECONDS = Math.max(0.15, Math.min(0.8, Number(process.env.VIDEO_TRANSITION_SECONDS || 0.35)));
const VIDEO_MAX_SEGMENTS = Math.max(1, Math.min(480, Number(process.env.VIDEO_MAX_SEGMENTS || 480)));
const VIDEO_JOB_RETENTION_MS = Math.max(60 * 60 * 1000, Number(process.env.VIDEO_JOB_RETENTION_HOURS || 6) * 60 * 60 * 1000);

const db = new Database(process.env.DB_PATH || 'ai_assistant.sqlite');
db.pragma('journal_mode = WAL');
db.exec(`
CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  email TEXT NOT NULL UNIQUE,
  password_hash TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  last_seen TEXT
);
CREATE TABLE IF NOT EXISTS usage (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL,
  provider TEXT NOT NULL,
  kind TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY(user_id) REFERENCES users(id)
);
`);

const SYSTEM = `
أنت AI Assistant عربي متقدم جدًا.
أجب بلغة المستخدم وبأسلوب طبيعي ومنظم يشبه مساعدًا حديثًا: لا تعرض عناوين Markdown غريبة مثل ### للمستخدم؛ استخدم عناوين واضحة أو نصًا عاديًا. لا تحيط المعادلات بعلامات الدولار. عند مقارنة بيانات استخدم جدول Markdown حقيقي لأن التطبيق يعرضه كجدول منسّق. كن مباشرًا بدون حشو أو مقدمات طويلة.
افهم وتفاعل بطلاقة مع جميع اللهجات العربية (الخليجية، الليبية، المصرية، الشامية، المغربية، وغيرها) وبأي لغة عالمية أخرى يكتب بها المستخدم، وحاول الرد بنفس لهجته أو لغته.
مرجع لهجة ليبية: «نبي/نبغي»=أريد، «عايز»=أريد، «دير/ديري لي»=اعمل لي، «شنو»=ماذا، «كيفاش»=كيف، «وقتاش»=متى، «علاش»=لماذا، «برشة»=كثير جدًا، «توا»=الآن، «ماشي»=حسنًا، «حوس»=ابحث.
مرجع خليجي: «أبغى»=أريد، «شلون»=كيف، «وش»=ماذا، «وايد»=كثير، «الحين»=الآن، «زين»=جيد.
مرجع مصري: «عايز»=أريد، «إزاي»=كيف، «ليه»=لماذا، «فين»=أين، «دلوقتي»=الآن.
مرجع شامي: «بدي»=أريد، «شو»=ماذا، «وين»=أين، «هلق»=الآن، «منيح»=جيد.
مرجع مغاربي: «بغيت»=أريد، «فين»=أين، «دابا»=الآن، «بزاف»=كثير.
استخدم هذه كأرضية أساسية، وفي أي كلمة أخرى اعتمد على السياق الكامل بدل تعميم الفصحى.
افهم السياق كاملًا وتتبع حالة الأشياء زمنيًا ومكانيًا.
في الرياضيات والفيزياء والعلوم: احسب وتحقق من النتيجة قبل الإجابة، واعرض الخطوات عند الحاجة.
إذا طلب المستخدم عددًا محددًا من الكلمات، يجب أن يكون النص النهائي بعد مراجعة العدد مطابقًا للعدد المطلوب تمامًا.
إذا سأل المستخدم عن صانع التطبيق أو مطوره، قل: «صانع هذا التطبيق هو ${CREATOR_NAME}، وهو مبرمج يطوّر تطبيقات مثل هذا التطبيق.».
إذا سأل المستخدم سؤال قدرة مثل «تقدر تسوي فيديو؟» أو «هل تستطيع إنشاء فيديو؟» فأجب بوضوح «نعم، أقدر» ولا تبدأ التوليد حتى يطلب إنشاء فيديو فعليًا. إذا طلب إنشاء فيديو، فالتطبيق يستطيع توليد الفيديو وعرض ملف الفيديو نفسه داخل المحادثة تلقائيًا، وليس كرابط للمستخدم. افهم جميع اللهجات العربية وسياقها، بما فيها الليبية والخليجية والمصرية والشامية والمغاربية والعراقية والسودانية واليمنية والحجازية وغيرها، ولا تعتمد على تطابق كلمة واحدة فقط لتحديد نية المستخدم.
إذا طلب إنشاء صورة، أخبره أن التطبيق يستطيع إنشاء الصور وسيعرض الصورة نفسها داخل المحادثة تلقائيًا. ممنوع كتابة رابط الصورة كنص عادي أبدًا.
إذا كان البحث متاحًا، استخدم Google Search وأعد روابط حقيقية قابلة للفتح فعليًا. عند طلب تطبيق أو لعبة أعد رابط Google Play الرسمي المباشر إن وُجد. لا تخترع روابط.
`;

app.use(express.json({ limit: '25mb' }));

// Simple in-memory rate limiter: protects the free/unlimited backend from a
// single IP flooding it with requests (default 40 requests/minute/IP).
const RATE_LIMIT_MAX = Number(process.env.RATE_LIMIT_MAX || 40);
const RATE_LIMIT_WINDOW_MS = 60 * 1000;
const rateBuckets = new Map();
app.use((req, res, next) => {
  const ip = req.ip || req.socket.remoteAddress || 'unknown';
  const now = Date.now();
  const bucket = rateBuckets.get(ip);
  if (!bucket || now - bucket.start > RATE_LIMIT_WINDOW_MS) {
    rateBuckets.set(ip, { start: now, count: 1 });
    return next();
  }
  bucket.count += 1;
  if (bucket.count > RATE_LIMIT_MAX) {
    return res.status(429).json({ error: 'طلبات كثيرة جدًا، حاول بعد قليل.' });
  }
  next();
});
setInterval(() => {
  const now = Date.now();
  for (const [ip, bucket] of rateBuckets) {
    if (now - bucket.start > RATE_LIMIT_WINDOW_MS) rateBuckets.delete(ip);
  }
}, 5 * 60 * 1000);

function tokenFor(user) {
  return jwt.sign({ id: user.id, email: user.email, name: user.name }, JWT_SECRET, { expiresIn: '30d' });
}
function auth(req, res, next) {
  const raw = String(req.headers.authorization || '');
  const token = raw.startsWith('Bearer ') ? raw.slice(7) : '';
  try { req.user = jwt.verify(token, JWT_SECRET); next(); }
  catch { res.status(401).json({ error: 'انتهت الجلسة. سجّل الدخول مرة أخرى.' }); }
}
function history(raw) {
  try {
    return JSON.parse(raw || '[]').slice(-18).map(x => ({
      role: x.role === 'assistant' ? 'model' : 'user',
      parts: [{ text: String(x.text || '') }]
    }));
  } catch { return []; }
}
function urls(x) {
  const out = new Set();
  const walk = v => {
    if (Array.isArray(v)) v.forEach(walk);
    else if (v && typeof v === 'object') Object.values(v).forEach(z => {
      if (typeof z === 'string' && /^https?:\/\//i.test(z)) out.add(z);
      walk(z);
    });
  };
  walk(x);
  return [...out].slice(0, 16);
}
function mime(file) { return file?.mimetype || 'application/octet-stream'; }
function countWords(text) { return String(text).trim().split(/\s+/u).filter(Boolean).length; }
function requestedWordCount(message) {
  const s = String(message);
  const patterns = [
    /(?:جملة|نص|إجابة|كلام)\s*(?:من|تتكون من)\s*(\d+)\s*كلم(?:ة|ات)/iu,
    /(?:exactly|exact)\s*(\d+)\s*words?/iu,
    /(?:بالضبط|فقط)\s*(\d+)\s*كلمة/iu,
  ];
  for (const p of patterns) { const m = s.match(p); if (m) return Number(m[1]); }
  return null;
}
async function repairWordCount(answer, original, target, providerCall) {
  if (!target || countWords(answer) === target) return answer;
  let current = answer;
  for (let i = 0; i < 2; i++) {
    current = await providerCall(`أعد صياغة إجابتك التالية لتصبح ${target} كلمة بالضبط، لا أكثر ولا أقل. حافظ على المعنى وأجب فقط بالنص النهائي دون شرح أو تعداد.\n\nالسؤال الأصلي: ${original}\n\nالإجابة: ${current}`);
    if (countWords(current) === target) return current.trim();
  }
  return current.trim();
}

app.get('/health', (_, res) => res.json({ ok: true, accounts: true, creator: CREATOR_NAME }));

app.post('/auth/register', async (req, res) => {
  const name = String(req.body?.name || '').trim();
  const email = String(req.body?.email || '').trim().toLowerCase();
  const password = String(req.body?.password || '');
  if (name.length < 2 || !/^\S+@\S+\.\S+$/u.test(email) || password.length < 8) {
    return res.status(400).json({ error: 'أدخل اسمًا وبريدًا صحيحين وكلمة مرور من 8 أحرف على الأقل.' });
  }
  try {
    const hash = await bcrypt.hash(password, 12);
    const info = db.prepare('INSERT INTO users(name,email,password_hash) VALUES(?,?,?)').run(name, email, hash);
    const user = { id: info.lastInsertRowid, name, email };
    res.status(201).json({ token: tokenFor(user), user });
  } catch (e) {
    res.status(409).json({ error: 'هذا البريد مستخدم بالفعل.' });
  }
});

app.post('/auth/login', async (req, res) => {
  const email = String(req.body?.email || '').trim().toLowerCase();
  const password = String(req.body?.password || '');
  const user = db.prepare('SELECT id,name,email,password_hash FROM users WHERE email=?').get(email);
  if (!user || !(await bcrypt.compare(password, user.password_hash))) return res.status(401).json({ error: 'البريد أو كلمة المرور غير صحيحة.' });
  db.prepare('UPDATE users SET last_seen=CURRENT_TIMESTAMP WHERE id=?').run(user.id);
  res.json({ token: tokenFor(user), user: { id: user.id, name: user.name, email: user.email } });
});

app.get('/auth/me', auth, (req, res) => {
  const user = db.prepare('SELECT id,name,email,created_at,last_seen FROM users WHERE id=?').get(req.user.id);
  if (!user) return res.status(404).json({ error: 'الحساب غير موجود.' });
  res.json({ user });
});

app.get('/usage', auth, (req, res) => {
  const total = db.prepare('SELECT COUNT(*) AS n FROM usage WHERE user_id=?').get(req.user.id).n;
  const today = db.prepare("SELECT COUNT(*) AS n FROM usage WHERE user_id=? AND date(created_at)=date('now')").get(req.user.id).n;
  const byProvider = db.prepare('SELECT provider, COUNT(*) AS n FROM usage WHERE user_id=? GROUP BY provider').all(req.user.id);
  const registeredUsers = db.prepare('SELECT COUNT(*) AS n FROM users').get().n;
  res.json({ total, today, byProvider, registeredUsers });
});

async function gemini(message, hist, web, file) {
  if (!process.env.GEMINI_API_KEY) throw Error('GEMINI_API_KEY missing');
  const parts = [{ text: message }];
  if (file) parts.push({ inline_data: { mime_type: mime(file), data: file.buffer.toString('base64') } });
  const body = { systemInstruction: { parts: [{ text: SYSTEM }] }, contents: [...hist, { role: 'user', parts }] };
  if (web) body.tools = [{ google_search: {} }];
  const r = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${GEMINI_MODEL}:generateContent?key=${encodeURIComponent(process.env.GEMINI_API_KEY)}`, {
    method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body)
  });
  const d = await r.json();
  if (!r.ok) throw Error(d?.error?.message || 'Gemini request failed');
  let text = (d?.candidates?.[0]?.content?.parts || []).map(x => x.text || '').join('').trim() || 'لم تصل إجابة.';
  return { reply: text, sources: urls(d), provider: 'gemini' };
}

async function groq(message, hist, file) {
  if (!process.env.GROQ_API_KEY) throw Error('GROQ_API_KEY missing');
  const image = file && /^image\//.test(file.mimetype || '');
  const base = [{ role: 'system', content: SYSTEM }, ...hist.map(x => ({ role: x.role === 'model' ? 'assistant' : 'user', content: x.parts?.[0]?.text || '' }))];
  if (image) base.push({ role: 'user', content: [{ type: 'text', text: message }, { type: 'image_url', image_url: { url: `data:${file.mimetype};base64,${file.buffer.toString('base64')}` } }] });
  else base.push({ role: 'user', content: message });
  let last;
  for (const model of [GROQ_MODEL, GROQ_FALLBACK_MODEL]) {
    try {
      const r = await fetch('https://api.groq.com/openai/v1/chat/completions', {
        method: 'POST', headers: { Authorization: `Bearer ${process.env.GROQ_API_KEY}`, 'Content-Type': 'application/json' },
        body: JSON.stringify({ model: image ? 'qwen/qwen3.8-27b' : model, messages: base, temperature: .15, reasoning_effort: 'medium' })
      });
      const d = await r.json();
      if (!r.ok) throw Error(d?.error?.message || `Groq request failed (${r.status})`);
      const text = String(d?.choices?.[0]?.message?.content || '').trim();
      if (text) return { reply: text, sources: [], provider: 'groq' };
      throw Error('Groq returned an empty response');
    } catch (e) { last = e; if (image) break; }
  }
  throw last || Error('Groq request failed');
}

app.post('/chat', auth, upload.single('file'), async (req, res) => {
  const message = String(req.body?.message || '').trim();
  if (!message && !req.file) return res.status(400).json({ error: 'message required' });
  const web = String(req.body?.web_search) === 'true';
  const hist = history(req.body?.history);
  const target = requestedWordCount(message);
  try {
    let out;
    try { out = await gemini(message || 'حلل الملف المرفق.', hist, web, req.file); }
    catch { out = await groq(message || 'حلل الملف المرفق.', hist, req.file); }
    if (target) {
      const repair = async prompt => {
        const x = await gemini(prompt, [], false, null).catch(() => groq(prompt, [], null));
        return x.reply;
      };
      out.reply = await repairWordCount(out.reply, message, target, repair);
    }
    db.prepare('INSERT INTO usage(user_id,provider,kind) VALUES(?,?,?)').run(req.user.id, out.provider || 'unknown', req.file ? 'file' : 'chat');
    res.json(out);
  } catch (e) { res.status(500).json({ error: e.message }); }
});


async function optimizeVideoPrompt(prompt) {
  const instruction = `حوّل طلب الفيديو التالي إلى Prompt إنجليزي احترافي جدًا ومحدد لمولد LoreMotion باستخدام LTX-Video 2.5 أو نموذج الفيديو المجاني المتاح.
- افهم المعنى من السياق حتى لو كتب المستخدم بأي لهجة عربية أو مزج بين لهجات ولغات: الليبية، الخليجية، السعودية، الكويتية، الإماراتية، القطرية، البحرينية، العمانية، المصرية، الشامية السورية واللبنانية والأردنية والفلسطينية، العراقية، اليمنية، السودانية، الحجازية، النجدية، المغربية، الجزائرية، التونسية، الموريتانية، وغيرها.
- لا تعتمد على تطابق كلمة واحدة فقط؛ فكّك المعنى المقصود، والفاعل، والمفعول، والزمن، والمكان، والحركة، ودرجة الواقعية من الجملة كاملة.
- حافظ حرفيًا على تفاصيل المستخدم المقصودة ولا تستبدل أسماء الأشخاص أو الأماكن أو الأشياء أو ألوانها أو أفعالها.
- اكتب Prompt واحدًا متصلًا بالإنجليزية، بصياغة سينمائية دقيقة، ويشمل الموضوع والحركة والكاميرا والإضاءة والعدسة والعمق والتفاصيل البصرية والصوت والجو العام عندما تكون ذات صلة.
- لا تخترع عناصر جوهرية غير موجودة في الطلب. يمكنك إضافة تفاصيل تقنية صغيرة فقط لتحسين الاتساق البصري عندما لا تغيّر المعنى.
- إذا لم يحدد المستخدم حركة كاميرا، اختر حركة بسيطة وطبيعية مناسبة للمشهد بدل حركة مبالغ فيها.
- إذا طلب المستخدم فيديو واقعيًا، استخدم وصفًا فوتوغرافيًا/سينمائيًا واقعيًا؛ وإذا طلب كرتونًا أو أنمي أو لعبة أو أسلوبًا فنيًا، حافظ على ذلك الأسلوب.
- اجعل الناتج أقل من 200 كلمة، ولا تضف شرحًا أو عنوانًا أو اقتباسات.

طلب المستخدم:
${String(prompt || '').trim()}`;
  try {
    const x = await gemini(instruction, [], false, null);
    if (x.reply?.trim()) return x.reply.trim();
  } catch {}
  try {
    const x = await groq(instruction, [], null);
    if (x.reply?.trim()) return x.reply.trim();
  } catch {}
  return String(prompt || '').trim();
}

function pickVideoAspectRatio(prompt) {
  const s = String(prompt || '').toLowerCase();
  if (/(عمودي|رأسي|طولي|ستوري|ريلز|رييلز|تيك ?توك|9\s*[:x×]\s*16|portrait|vertical|reel|tiktok|story)/iu.test(s)) return '9:16';
  return '16:9';
}

function pickCameraMotion(prompt) {
  const s = String(prompt || '').toLowerCase();
  if (/(زووم\s*إن|تقريب|اقتراب\s*الكاميرا|dolly\s*in|zoom\s*in)/iu.test(s)) return 'dolly_in';
  if (/(زووم\s*أوت|ابتعاد\s*الكاميرا|dolly\s*out|zoom\s*out)/iu.test(s)) return 'dolly_out';
  if (/(يسار|إلى اليسار|dolly\s*left|pan\s*left)/iu.test(s)) return 'dolly_left';
  if (/(يمين|إلى اليمين|dolly\s*right|pan\s*right)/iu.test(s)) return 'dolly_right';
  if (/(ترتفع|للأعلى|إلى فوق|jib\s*up|crane\s*up)/iu.test(s)) return 'jib_up';
  if (/(تنخفض|للأسفل|إلى تحت|jib\s*down|crane\s*down)/iu.test(s)) return 'jib_down';
  if (/(تركيز\s*على|فوكس|focus\s*shift|rack\s*focus)/iu.test(s)) return 'focus_shift';
  if (/(ثابتة|ثابت|بدون حركة|static|locked\s*off)/iu.test(s)) return 'static';
  return 'none';
}

const videoJobs = new Map();

function normalizeArabicDigits(value) {
  return String(value || '')
    .replace(/[٠-٩]/g, ch => String('٠١٢٣٤٥٦٧٨٩'.indexOf(ch)))
    .replace(/[۰-۹]/g, ch => String('۰۱۲۳۴۵۶۷۸۹'.indexOf(ch)));
}

function parseVideoDuration(text) {
  const s = normalizeArabicDigits(text).toLowerCase().trim();
  if (!s) return null;
  let total = 0;
  const hour = s.match(/(\d+(?:\.\d+)?)\s*(?:h|hr|hrs|hour|hours|ساعة|ساعات|ساعه|ساعةً)/iu);
  const minute = s.match(/(\d+(?:\.\d+)?)\s*(?:m|min|mins|minute|minutes|دقيقة|دقائق|دقيقه)/iu);
  const second = s.match(/(\d+(?:\.\d+)?)\s*(?:s|sec|secs|second|seconds|ثانية|ثواني|ثانيه)/iu);
  if (hour) total += Number(hour[1]) * 3600;
  if (minute) total += Number(minute[1]) * 60;
  if (second) total += Number(second[1]);
  if (!total && /(نصف\s+ساعة|نص\s+ساعة|half\s+an?\s+hour)/iu.test(s)) total = 1800;
  if (!total && /(ساعة\s+كاملة|لمدة\s+ساعة|مدة\s+ساعة|ساعة\s+واحدة|one\s+hour|an?\s+hour)/iu.test(s)) total = 3600;
  if (!total && /(دقيقة\s+واحدة|دقيقة\s+كاملة|لمدة\s+دقيقة|مدة\s+دقيقة|one\s+minute|a\s+minute)/iu.test(s)) total = 60;
  if (!total && /(ثانية\s+واحدة|ثانية\s+كاملة|one\s+second|a\s+second)/iu.test(s)) total = 1;
  return total > 0 ? Math.min(VIDEO_MAX_DURATION_SECONDS, Math.max(1, Math.round(total))) : null;
}

function createVideoJob(userId, prompt, imageFile) {
  const id = `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 10)}`;
  const requested = parseVideoDuration(prompt) || VIDEO_DEFAULT_DURATION_SECONDS;
  const safeRequested = Math.min(VIDEO_MAX_DURATION_SECONDS, Math.max(3, requested));
  const job = {
    id,
    userId,
    prompt,
    imageFile: imageFile ? { buffer: Buffer.from(imageFile.buffer), mimetype: imageFile.mimetype || 'image/png' } : null,
    status: 'queued',
    progress: 0,
    requestedDuration: safeRequested,
    duration: 0,
    quality: 'LoreMotion live maximum / model tier',
    videoUrl: null,
    shareUrl: null,
    outputPath: null,
    error: null,
    segmentsCompleted: 0,
    segmentsTotal: null,
    transitionSeconds: VIDEO_TRANSITION_SECONDS,
    createdAt: Date.now(),
  };
  videoJobs.set(id, job);
  return job;
}

function continuityPrompt(basePrompt, index, referenceFrame) {
  const first = index === 0;
  return [
    `This is ${first ? 'the first segment' : 'a continuation segment'} of one single continuous cinematic video.`,
    'Do not make it feel like a collection of separate clips.',
    first ? 'Start directly inside the action; no title card, no logo, no intro slate.' : 'Start exactly from the visual state of the supplied previous ending frame.',
    'Keep the same characters, faces, clothing, props, location, time of day, weather, lighting, color grade, lens language and overall visual style across the entire sequence.',
    'Continue motion naturally from the previous moment. No teleporting, no sudden reset, no unexplained cuts, no black frame, no scene restart.',
    'Avoid introducing new major characters or objects unless the user explicitly asked for them.',
    'Use realistic temporal continuity and physically plausible movement.',
    'Do not add subtitles, captions, watermarks, UI, borders, or end cards.',
    first ? '' : `A previous-segment final frame is attached as a visual continuity reference. Use it as the exact starting state: ${referenceFrame ? 'YES' : 'NO'}.`,
    `Scene request: ${String(basePrompt).trim()}`,
  ].filter(Boolean).join('\n');
}

async function runVideoJob(job) {
  job.status = 'running';
  const segmentFiles = [];
  const frameFiles = [];
  const temporaryFiles = [];
  let workingImagePath;
  try {
    const optimizedPrompt = await optimizeVideoPrompt(job.prompt);
    const model = /minimax|h3/i.test(job.prompt) ? 'minimax-h3' : 'ltx-2.5';
    if (job.imageFile) {
      workingImagePath = path.join(os.tmpdir(), `ai-assistant-${job.id}-input${path.extname(job.imageFile.mimetype || '') || '.png'}`);
      await fs.promises.writeFile(workingImagePath, job.imageFile.buffer);
      temporaryFiles.push(workingImagePath);
    }

    const target = Math.min(VIDEO_MAX_DURATION_SECONDS, Math.max(3, Number(job.requestedDuration) || VIDEO_DEFAULT_DURATION_SECONDS));
    job.totalSeconds = target;
    let completed = 0;
    let segmentIndex = 0;
    let lastResult = null;

    while (completed + 0.25 < target) {
      if (segmentIndex >= VIDEO_MAX_SEGMENTS) {
        throw new Error(`الفيديو المطلوب طويل جدًا لهذه الجلسة. الحد الحالي ${VIDEO_MAX_SEGMENTS} مقطعًا.`);
      }
      const remaining = target - completed;
      const prompt = continuityPrompt(optimizedPrompt, segmentIndex, workingImagePath);
      job.progress = Math.min(92, Math.max(1, Math.round((completed / target) * 88)));
      job.segmentsCompleted = segmentIndex;
      job.segmentsTotal = Math.max(segmentIndex + 1, Math.ceil(target / 3));

      const result = await loreMotion.generate({
        prompt,
        model,
        aspectRatio: pickVideoAspectRatio(job.prompt),
        durationSeconds: Math.max(1, Math.ceil(remaining)),
        imagePath: workingImagePath,
        timeoutMs: Number(process.env.LOREMOTION_GENERATION_TIMEOUT_MS || 900000),
      });
      lastResult = result;
      if (!result.videoUrl) throw new Error('LoreMotion لم يعرض ملف MP4 لهذا المقطع.');

      const segmentPath = await loreMotion.downloadVideo(result.videoUrl, `ai-assistant-${job.id}-segment-${String(segmentIndex + 1).padStart(4, '0')}`);
      segmentFiles.push(segmentPath);
      const measured = Number(result.actual) > 0 ? Number(result.actual) : (await probeMedia(segmentPath)).duration;
      const actual = Number(measured);
      if (!Number.isFinite(actual) || actual < 0.25) throw new Error('تعذر قياس مدة مقطع الفيديو الناتج.');
      completed += actual;
      job.segmentsCompleted = segmentIndex + 1;
      job.completedSeconds = Math.min(target, Math.round(completed));
      job.duration = completed;
      job.progress = Math.min(95, Math.round(Math.min(1, completed / target) * 95));

      if (completed + 0.25 >= target) break;
      const frame = path.join(os.tmpdir(), `ai-assistant-${job.id}-frame-${String(segmentIndex + 1).padStart(4, '0')}.jpg`);
      await extractLastFrame(segmentPath, frame);
      frameFiles.push(frame);
      workingImagePath = frame;
      temporaryFiles.push(frame);
      segmentIndex += 1;
    }

    job.segmentsTotal = segmentFiles.length;
    job.progress = 97;
    const outputDir = path.resolve(process.env.LOREMOTION_DOWNLOAD_DIR || 'downloads');
    await fs.promises.mkdir(outputDir, { recursive: true });
    const outputPath = path.join(outputDir, `ai-assistant-${job.id}-final.mp4`);
    const composed = await composeVideo(segmentFiles, outputPath, target, VIDEO_TRANSITION_SECONDS);
    job.outputPath = outputPath;
    job.requestedDuration = target;
    job.duration = composed.duration;
    job.totalSeconds = target;
    job.completedSeconds = Math.round(composed.duration);
    job.progress = 100;
    job.capped = Boolean(lastResult?.capped);
    job.cappedFrom = lastResult?.capped ? lastResult.requested : null;
    job.quality = `LoreMotion ${lastResult?.model || model} • ${lastResult?.max || '?'}s max/segment • ${lastResult?.aspectRatio || pickVideoAspectRatio(job.prompt)} • ${segmentFiles.length} seamless segments`;
    job.videoUrl = `/video/file/${encodeURIComponent(job.id)}`;
    job.shareUrl = lastResult?.shareUrl || null;
    job.status = 'succeeded';
    db.prepare('INSERT INTO usage(user_id,provider,kind) VALUES(?,?,?)').run(job.userId, `loremotion-${lastResult?.model || model}`, 'video');
  } catch (e) {
    job.error = e?.message || 'فشل توليد الفيديو.';
    job.status = 'failed';
  } finally {
    if (job.imageFile) job.imageFile = null;
    for (const frame of frameFiles) await fs.promises.rm(frame, { force: true }).catch(() => {});
    for (const file of segmentFiles) await fs.promises.rm(file, { force: true }).catch(() => {});
    for (const temp of temporaryFiles) await fs.promises.rm(temp, { force: true }).catch(() => {});
  }
}

function scheduleVideoCleanup(job) {
  setTimeout(async () => {
    if (job.outputPath) await fs.promises.rm(job.outputPath, { force: true }).catch(() => {});
    videoJobs.delete(job.id);
  }, VIDEO_JOB_RETENTION_MS);
}

app.post('/video/generate', auth, upload.single('image'), async (req, res) => {
  const prompt = String(req.body?.prompt || '').trim();
  if (!prompt) return res.status(400).json({ error: 'اكتب وصف الفيديو أولًا.' });
  try {
    const job = createVideoJob(req.user.id, prompt, req.file);
    void runVideoJob(job).finally(() => scheduleVideoCleanup(job));
    res.status(202).json({ job_id: job.id, status: job.status, duration: job.duration, requested_duration: job.requestedDuration, quality: job.quality, provider: 'loremotion' });
  } catch (e) {
    res.status(500).json({ error: e.message || 'فشل بدء توليد الفيديو.' });
  }
});

app.get('/video/file/:id', auth, async (req, res) => {
  const job = videoJobs.get(String(req.params.id || ''));
  if (!job || job.userId !== req.user.id || !job.outputPath || job.status !== 'succeeded') {
    return res.status(404).json({ error: 'ملف الفيديو غير متاح أو انتهت صلاحيته.' });
  }
  try {
    await fs.promises.access(job.outputPath, fs.constants.R_OK);
    return res.sendFile(path.resolve(job.outputPath));
  } catch {
    return res.status(404).json({ error: 'ملف الفيديو لم يعد موجودًا على الخادم.' });
  }
});

app.get('/video/status/:id', auth, async (req, res) => {
  const job = videoJobs.get(String(req.params.id || ''));
  if (!job || job.userId !== req.user.id) return res.status(404).json({ error: 'لم يتم العثور على مهمة الفيديو.' });
  const body = {
    job_id: job.id,
    status: job.status,
    progress: job.progress,
    duration: job.duration || 0,
    requested_duration: job.requestedDuration || null,
    quality: job.quality,
    completed_seconds: job.completedSeconds || 0,
    total_seconds: job.totalSeconds || job.duration || 0,
    provider: 'loremotion',
    capped: Boolean(job.capped),
    capped_from: job.cappedFrom || null,
    segments_completed: job.segmentsCompleted || 0,
    segments_total: job.segmentsTotal || 0,
    transition_seconds: job.transitionSeconds || VIDEO_TRANSITION_SECONDS,
    duration_target: job.requestedDuration || null,
  };
  if (job.status === 'succeeded') {
    body.video_url = job.videoUrl;
    body.share_url = job.shareUrl || null;
  }
  if (job.status === 'failed') body.error = job.error;
  res.json(body);
});

app.get('/video/config', auth, async (_req, res) => {
  res.json({
    provider: 'loremotion',
    session_mode: loreMotionConfig.sessionMode,
    base_url: loreMotionConfig.baseUrl,
    note: loreMotionConfig.sessionMode === 'persistent'
      ? 'LoreMotion uses the persistent browser profile for the signed-in session.'
      : 'Anonymous mode is limited by LoreMotion account/session policy; use persistent mode for an authenticated free account.',
  });
});

app.listen(PORT, () => console.log(`AI Assistant backend listening on ${PORT}`));
