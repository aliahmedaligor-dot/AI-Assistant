import 'dotenv/config';
import express from 'express';
import multer from 'multer';

const app=express();
const upload=multer({storage:multer.memoryStorage(),limits:{fileSize:18*1024*1024}});
const PORT=process.env.PORT||8080;
const GEMINI_MODEL=process.env.GEMINI_MODEL||'gemini-3.8-flash';
const GROQ_MODEL=process.env.GROQ_MODEL||'llama-3.3-70b-versatile';
const SYSTEM=`أنت AI Assistant ذكي ومتعدد الاستخدامات. أجب بلغة المستخدم والعربية افتراضيًا. في الرياضيات طبق ترتيب العمليات واعرض خطوات الحل وراجع الناتج. في أسئلة الاستدلال تتبع الحالة خطوة بخطوة ولا تفترض انتقال شيء موضوع فوق شيء عند نقل الجسم تحته. إذا كان البحث مفعلاً استخدم Google Search واذكر مصادر حقيقية وروابطها. لا تخترع روابط. حلل الصور والملفات بدقة.`;
app.use(express.json({limit:'25mb'}));
app.get('/health',(_,res)=>res.json({ok:true,gemini:!!process.env.GEMINI_API_KEY,groq:!!process.env.GROQ_API_KEY}));
function history(raw){try{return JSON.parse(raw||'[]').slice(-18).map(x=>({role:x.role==='assistant'?'model':'user',parts:[{text:String(x.text||'')}] }));}catch{return[];}}
function urls(x){const out=new Set();const walk=v=>{if(Array.isArray(v))v.forEach(walk);else if(v&&typeof v==='object')Object.values(v).forEach(z=>{if(typeof z==='string'&&z.startsWith('http'))out.add(z);walk(z);});};walk(x);return [...out].slice(0,12);}
function mime(file){return file?.mimetype||'application/octet-stream';}
async function gemini(message,hist,web,file){if(!process.env.GEMINI_API_KEY)throw Error('GEMINI_API_KEY missing');const parts=[{text:message}];if(file)parts.push({inline_data:{mime_type:mime(file),data:file.buffer.toString('base64')}});const body={systemInstruction:{parts:[{text:SYSTEM}]},contents:[...hist,{role:'user',parts}]};if(web)body.tools=[{google_search:{}}];const r=await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${GEMINI_MODEL}:generateContent?key=${encodeURIComponent(process.env.GEMINI_API_KEY)}`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});const d=await r.json();if(!r.ok)throw Error(d?.error?.message||'Gemini request failed');const text=(d?.candidates?.[0]?.content?.parts||[]).map(x=>x.text||'').join('');return {reply:text||'لم تصل إجابة.',sources:urls(d)};}
async function groq(message,hist){if(!process.env.GROQ_API_KEY)throw Error('GROQ_API_KEY missing');const messages=[{role:'system',content:SYSTEM},...hist.map(x=>({role:x.role==='model'?'assistant':'user',content:x.parts?.[0]?.text||''})),{role:'user',content:message}];const r=await fetch('https://api.groq.com/openai/v1/chat/completions',{method:'POST',headers:{Authorization:`Bearer ${process.env.GROQ_API_KEY}`,'Content-Type':'application/json'},body:JSON.stringify({model:GROQ_MODEL,messages,temperature:.15})});const d=await r.json();if(!r.ok)throw Error(d?.error?.message||'Groq request failed');return {reply:d?.choices?.[0]?.message?.content||'لم تصل إجابة.',sources:[]};}
app.post('/chat',upload.single('file'),async(req,res)=>{const message=String(req.body?.message||'').trim();if(!message&&!req.file)return res.status(400).json({error:'message required'});const web=String(req.body?.web_search)==='true';const hist=history(req.body?.history);try{let out;try{out=await gemini(message||'حلل الملف المرفق.',hist,web,req.file);}catch(e){if(!process.env.GROQ_API_KEY)throw e;out=await groq(message||'حلل الملف المرفق.',hist);}res.json(out);}catch(e){res.status(500).json({error:e.message});}});
app.listen(PORT,()=>console.log(`AI Assistant backend listening on ${PORT}`));
