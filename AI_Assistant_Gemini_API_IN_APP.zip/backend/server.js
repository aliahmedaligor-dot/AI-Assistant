import express from "express";
import cors from "cors";
const app=express(); app.use(cors()); app.use(express.json({limit:"25mb"}));
const PORT=process.env.PORT||8080;
const GK=process.env.GEMINI_API_KEY||"", QK=process.env.GROQ_API_KEY||"";
const GM=process.env.GEMINI_MODEL||"gemini-3.8-flash", QM=process.env.GROQ_MODEL||"llama-3.3-70b-versatile";
const SYSTEM="You are AI Assistant, Arabic-first and multimodal. Answer in the user's language. Solve math step by step. Use supplied device context only. When webSearch is true use Google Search grounding. Never invent URLs, citations or facts.";
function urls(x){const s=new Set();const w=v=>{if(Array.isArray(v))return v.forEach(w);if(v&&typeof v==="object"){if(typeof v.url==="string"&&/^https?:\/\//.test(v.url))s.add(v.url);Object.values(v).forEach(w)}};w(x);return[...s].slice(0,12)}
async function gemini({message,history,webSearch,imageBase64,mimeType}){
 if(!GK)throw Error("GEMINI_API_KEY missing");
 const contents=history.slice(-16).map(m=>({role:m.role==="assistant"?"model":"user",parts:[{text:String(m.text||"")}]}));
 const parts=[{text:message}];if(imageBase64)parts.push({inline_data:{mime_type:mimeType||"image/jpeg",data:imageBase64}});
 contents.push({role:"user",parts});
 const body={systemInstruction:{parts:[{text:SYSTEM}]},contents,generationConfig:{temperature:.35,maxOutputTokens:4096}};
 if(webSearch)body.tools=[{google_search:{}}];
 const r=await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${GM}:generateContent`,{method:"POST",headers:{"Content-Type":"application/json","x-goog-api-key":GK},body:JSON.stringify(body)});
 const d=await r.json();if(!r.ok)throw Error(`Gemini ${r.status}`);
 const text=(d.candidates?.[0]?.content?.parts||[]).map(p=>p.text||"").join("\n").trim();if(!text)throw Error("Gemini empty");
 return{text,sources:urls(d)}
}
async function groq({message,history}){
 if(!QK)throw Error("GROQ_API_KEY missing");
 const messages=[{role:"system",content:SYSTEM},...history.slice(-16).map(m=>({role:m.role==="assistant"?"assistant":"user",content:String(m.text||"")})),{role:"user",content:message}];
 const r=await fetch("https://api.groq.com/openai/v1/chat/completions",{method:"POST",headers:{"Content-Type":"application/json","Authorization":`Bearer ${QK}`},body:JSON.stringify({model:QM,messages,temperature:.35,max_completion_tokens:4096})});
 const d=await r.json();if(!r.ok)throw Error(`Groq ${r.status}`);const text=d.choices?.[0]?.message?.content;if(!text)throw Error("Groq empty");return{text,sources:[]}
}
app.get("/health",(q,r)=>r.json({ok:true,gemini:!!GK,groq:!!QK}));
app.post("/chat",async(req,res)=>{const b=req.body||{};const message=String(b.message||"").trim();if(!message&&!b.imageBase64)return res.status(400).json({error:"message required"});const device=b.deviceContext?`\nDevice context:\n${b.deviceContext}`:"";try{return res.json(await gemini({message:message+device,history:Array.isArray(b.history)?b.history:[],webSearch:!!b.webSearch,imageBase64:b.imageBase64||null,mimeType:b.mimeType||"image/jpeg"}))}catch(e){if(!b.imageBase64&&QK){try{return res.json(await groq({message:message+device,history:Array.isArray(b.history)?b.history:[]}))}catch(_){}}return res.status(502).json({error:e.message||String(e)})}});
app.listen(PORT,()=>console.log(`AI Assistant backend on ${PORT}`));
