import 'dotenv/config';
import express from 'express';
import multer from 'multer';

const app=express();
const upload=multer({storage:multer.memoryStorage(),limits:{fileSize:18*1024*1024}});
const PORT=process.env.PORT||8080;
const GEMINI_MODEL=process.env.GEMINI_MODEL||'gemini-3.8-flash';
const GROQ_MODEL=process.env.GROQ_MODEL||'openai/gpt-oss-120b';
const GROQ_FALLBACK_MODEL=process.env.GROQ_FALLBACK_MODEL||'qwen/qwen3.8-27b';
const SYSTEM=`أنت AI Assistant ذكي ومتعدد الاستخدامات. أجب بلغة المستخدم والعربية افتراضيًا. في الرياضيات طبق ترتيب العمليات واعرض خطوات الحل وراجع الناتج. في أسئلة الاستدلال تتبع الحالة خطوة بخطوة ولا تفترض انتقال شيء موضوع فوق شيء عند نقل الجسم تحته. إذا كان البحث مفعلاً استخدم Google Search واذكر مصادر حقيقية وروابطها. لا تخترع روابط. حلل الصور والملفات بدقة.`;
app.use(express.json({limit:'25mb'}));
app.get('/health',(_,res)=>res.json({ok:true,gemini:!!process.env.GEMINI_API_KEY,groq:!!process.env.GROQ_API_KEY}));
function history(raw){try{return JSON.parse(raw||'[]').slice(-18).map(x=>({role:x.role==='assistant'?'model':'user',parts:[{text:String(x.text||'')}] }));}catch{return[];}}
function urls(x){const out=new Set();const walk=v=>{if(Array.isArray(v))v.forEach(walk);else if(v&&typeof v==='object')Object.values(v).forEach(z=>{if(typeof z==='string'&&z.startsWith('http'))out.add(z);walk(z);});};walk(x);return [...out].slice(0,12);}
function mime(file){return file?.mimetype||'application/octet-stream';}
async function gemini(message,hist,web,file){if(!process.env.GEMINI_API_KEY)throw Error('GEMINI_API_KEY missing');const parts=[{text:message}];if(file)parts.push({inline_data:{mime_type:mime(file),data:file.buffer.toString('base64')}});const body={systemInstruction:{parts:[{text:SYSTEM}]},contents:[...hist,{role:'user',parts}]};if(web)body.tools=[{google_search:{}}];const r=await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${GEMINI_MODEL}:generateContent?key=${encodeURIComponent(process.env.GEMINI_API_KEY)}`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});const d=await r.json();if(!r.ok)throw Error(d?.error?.message||'Gemini request failed');const text=(d?.candidates?.[0]?.content?.parts||[]).map(x=>x.text||'').join('');return {reply:text||'لم تصل إجابة.',sources:urls(d)};}
async function groq(message,hist,file){
  if(!process.env.GROQ_API_KEY)throw Error('GROQ_API_KEY missing');
  const image=file && /^image\//.test(file.mimetype||'');
  const base=[{role:'system',content:SYSTEM},...hist.map(x=>({role:x.role==='model'?'assistant':'user',content:x.parts?.[0]?.text||''}))];
  if(image){
    if(file.buffer.length>10*1024*1024)throw Error('Image exceeds 10MB');
    base.push({role:'user',content:[{type:'text',text:message},{type:'image_url',image_url:{url:`data:${file.mimetype};base64,${file.buffer.toString('base64')}`}}]});
  }else base.push({role:'user',content:message});
  let last;
  for(const model of [GROQ_MODEL,GROQ_FALLBACK_MODEL]){
    try{
      const r=await fetch('https://api.groq.com/openai/v1/chat/completions',{method:'POST',headers:{Authorization:`Bearer ${process.env.GROQ_API_KEY}`,'Content-Type':'application/json'},body:JSON.stringify({model:image?'qwen/qwen3.8-27b':model,messages:base,temperature:.15,reasoning_effort:'medium'})});
      const d=await r.json();
      if(!r.ok)throw Error(d?.error?.message||`Groq request failed (${r.status})`);
      const text=d?.choices?.[0]?.message?.content||'';
      if(text.trim())return {reply:text,sources:[]};
      throw Error('Groq returned an empty response');
    }catch(e){last=e;if(image)break;}
  }
  throw last||Error('Groq request failed');
}
app.post('/chat',upload.single('file'),async(req,res)=>{const message=String(req.body?.message||'').trim();if(!message&&!req.file)return res.status(400).json({error:'message required'});const web=String(req.body?.web_search)==='true';const hist=history(req.body?.history);try{let out;try{out=await gemini(message||'حلل الملف المرفق.',hist,web,req.file);}catch(e){if(!process.env.GROQ_API_KEY)throw e;out=await groq(message||'حلل الملف المرفق.',hist);}res.json(out);}catch(e){res.status(500).json({error:e.message});}});
app.listen(PORT,()=>console.log(`AI Assistant backend listening on ${PORT}`));
