import 'dotenv/config';
import express from 'express';
import os from 'node:os';
import path from 'node:path';
import fs from 'node:fs';
import multer from 'multer';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import Database from 'better-sqlite3';
import { LoreMotionBrowser, LoreMotionClient, loreMotionConfig } from './loremotion.js';

const app = express();
const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 18 * 1024 * 1024 } });
const PORT = process.env.PORT || 8080;
const JWT_SECRET = process.env.JWT_SECRET || 'CHANGE_THIS_SECRET_IN_PRODUCTION';
const GEMINI_MODEL = process.env.GEMINI_MODEL || 'gemini-3.8-flash';
const GROQ_MODEL = process.env.GROQ_MODEL || 'openai/gpt-oss-120b';
const GROQ_FALLBACK_MODEL = process.env.GROQ_FALLBACK_MODEL || 'qwen/qwen3.8-27b';
const CREATOR_NAME = process.env.CREATOR_NAME || 'المبرمج علي أحمد قرباج (Ali Ahmed Gorbaj)';

const db = new Database(process.env.DB_PATH || 'ai_assistant.sqlite');
db.pragma('journal_mode = WAL');
db.exec(`
CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  email TEXT NOT NULL UNIQUE,
  password_hash TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  last_seen TEXT
);
CREATE TABLE IF NOT EXISTS usage (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL,
  provider TEXT NOT NULL,
  kind TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY(user_id) REFERENCES users(id)
);
`);

const SYSTEM = `
أنت AI Assistant عربي متقدم جدًا.
أجب بلغة المستخدم وبأسلوب طبيعي ومنظم يشبه مساعدًا حديثًا: لا تعرض عناوين Markdown غريبة مثل ### للمستخدم؛ استخدم عناوين واضحة أو نصًا عاديًا. لا تحيط المعادلات بعلامات الدولار. عند مقارنة بيانات استخدم جدول Markdown حقيقي لأن التطبيق يعرضه كجدول منسّق. كن مباشرًا بدون حشو أو مقدمات طويلة.
افهم وتفاعل بطلاقة مع جميع اللهجات العربية (الخليجية، الليبية، المصرية، الشامية، المغربية، وغيرها) وبأي لغة عالمية أخرى يكتب بها المستخدم، وحاول الرد بنفس لهجته أو لغته.
مرجع لهجة ليبية: «نبي/نبغي»=أريد، «عايز»=أريد، «دير/ديري لي»=اعمل لي، «شنو»=ماذا، «كيفاش»=كيف، «وقتاش»=متى، «علاش»=لماذا، «برشة»=كثير جدًا، «توا»=الآن، «ماشي»=حسنًا، «حوس»=ابحث.
مرجع خليجي: «أبغى»=أريد، «شلون»=كيف، «وش»=ماذا، «وايد»=كثير، «الحين»=الآن، «زين»=جيد.
مرجع مصري: «عايز»=أريد، «إزاي»=كيف، «ليه»=لماذا، «فين»=أين، «دلوقتي»=الآن.
مرجع شامي: «بدي»=أريد، «شو»=ماذا، «وين»=أين، «هلق»=الآن، «منيح»=جيد.
مرجع مغاربي: «بغيت»=أريد، «فين»=أين، «دابا»=الآن، «بزاف»=كثير.
استخدم هذه كأرضية أساسية، وفي أي كلمة أخرى اعتمد على السياق الكامل بدل تعميم الفصحى.
افهم السياق كاملًا وتتبع حالة الأشياء زمنيًا ومكانيًا.
في الرياضيات والفيزياء والعلوم: احسب وتحقق من النتيجة قبل الإجابة، واعرض الخطوات عند الحاجة.
إذا طلب المستخدم عددًا محددًا من الكلمات، يجب أن يكون النص النهائي بعد مراجعة العدد مطابقًا للعدد المطلوب تمامًا.
إذا سأل المستخدم عن صانع التطبيق أو مطوره، قل: «صانع هذا التطبيق هو ${CREATOR_NAME}، وهو مبرمج يطوّر تطبيقات مثل هذا التطبيق.».
إذا سأل المستخدم سؤال قدرة مثل «تقدر تسوي فيديو؟» أو «هل تستطيع إنشاء فيديو؟» فأجب بوضوح «نعم، أقدر» ولا تبدأ التوليد حتى يطلب إنشاء فيديو فعليًا. إذا طلب إنشاء فيديو، فالتطبيق يستطيع توليد الفيديو وعرض ملف الفيديو نفسه داخل المحادثة تلقائيًا، وليس كرابط للمستخدم. افهم جميع اللهجات العربية وسياقها، بما فيها الليبية والخليجية والمصرية والشامية والمغاربية والعراقية والسودانية واليمنية والحجازية وغيرها، ولا تعتمد على تطابق كلمة واحدة فقط لتحديد نية المستخدم.
إذا طلب إنشاء صورة، أخبره أن التطبيق يستطيع إنشاء الصور وسيعرض الصورة نفسها داخل المحادثة تلقائيًا. ممنوع كتابة رابط الصورة كنص عادي أبدًا.
إذا كان البحث متاحًا، استخدم Google Search وأعد روابط حقيقية قابلة للفتح فعليًا. عند طلب تطبيق أو لعبة أعد رابط Google Play الرسمي المباشر إن وُجد. لا تخترع روابط.
`;

app.use(express.json({ limit: '25mb' }));

// Simple in-memory rate limiter: protects the free/unlimited backend from a
// single IP flooding it with requests (default 40 requests/minute/IP).
const RATE_LIMIT_MAX = Number(process.env.RATE_LIMIT_MAX || 40);
const RATE_LIMIT_WINDOW_MS = 60 * 1000;
const rateBuckets = new Map();
app.use((req, res, next) => {
  const ip = req.ip || req.socket.remoteAddress || 'unknown';
  const now = Date.now();
  const bucket = rateBuckets.get(ip);
  if (!bucket || now - bucket.start > RATE_LIMIT_WINDOW_MS) {
    rateBuckets.set(ip, { start: now, count: 1 });
    return next();
  }
  bucket.count += 1;
  if (bucket.count > RATE_LIMIT_MAX) {
    return res.status(429).json({ error: 'طلبات كثيرة جدًا، حاول بعد قليل.' });
  }
  next();
});
setInterval(() => {
  const now = Date.now();
  for (const [ip, bucket] of rateBuckets) {
    if (now - bucket.start > RATE_LIMIT_WINDOW_MS) rateBuckets.delete(ip);
  }
}, 5 * 60 * 1000);

function tokenFor(user) {
  return jwt.sign({ id: user.id, email: user.email, name: user.name }, JWT_SECRET, { expiresIn: '30d' });
}
function auth(req, res, next) {
  const raw = String(req.headers.authorization || '');
  const token = raw.startsWith('Bearer ') ? raw.slice(7) : '';
  try { req.user = jwt.verify(token, JWT_SECRET); next(); }
  catch { res.status(401).json({ error: 'انتهت الجلسة. سجّل الدخول مرة أخرى.' }); }
}
function history(raw) {
  try {
    return JSON.parse(raw || '[]').slice(-18).map(x => ({
      role: x.role === 'assistant' ? 'model' : 'user',
      parts: [{ text: String(x.text || '') }]
    }));
  } catch { return []; }
}
function urls(x) {
  const out = new Set();
  const walk = v => {
    if (Array.isArray(v)) v.forEach(walk);
    else if (v && typeof v === 'object') Object.values(v).forEach(z => {
      if (typeof z === 'string' && /^https?:\/\//i.test(z)) out.add(z);
      walk(z);
    });
  };
  walk(x);
  return [...out].slice(0, 16);
}
function mime(file) { return file?.mimetype || 'application/octet-stream'; }
function countWords(text) { return String(text).trim().split(/\s+/u).filter(Boolean).length; }
function requestedWordCount(message) {
  const s = String(message);
  const patterns = [
    /(?:جملة|نص|إجابة|كلام)\s*(?:من|تتكون من)\s*(\d+)\s*كلم(?:ة|ات)/iu,
    /(?:exactly|exact)\s*(\d+)\s*words?/iu,
    /(?:بالضبط|فقط)\s*(\d+)\s*كلمة/iu,
  ];
  for (const p of patterns) { const m = s.match(p); if (m) return Number(m[1]); }
  return null;
}
async function repairWordCount(answer, original, target, providerCall) {
  if (!target || countWords(answer) === target) return answer;
  let current = answer;
  for (let i = 0; i < 2; i++) {
    current = await providerCall(`أعد صياغة إجابتك التالية لتصبح ${target} كلمة بالضبط، لا أكثر ولا أقل. حافظ على المعنى وأجب فقط بالنص النهائي دون شرح أو تعداد.\n\nالسؤال الأصلي: ${original}\n\nالإجابة: ${current}`);
    if (countWords(current) === target) return current.trim();
  }
  return current.trim();
}

app.get('/health', (_, res) => res.json({ ok: true, accounts: true, creator: CREATOR_NAME }));

app.post('/auth/register', async (req, res) => {
  const name = String(req.body?.name || '').trim();
  const email = String(req.body?.email || '').trim().toLowerCase();
  const password = String(req.body?.password || '');
  if (name.length < 2 || !/^\S+@\S+\.\S+$/u.test(email) || password.length < 8) {
    return res.status(400).json({ error: 'أدخل اسمًا وبريدًا صحيحين وكلمة مرور من 8 أحرف على الأقل.' });
  }
  try {
    const hash = await bcrypt.hash(password, 12);
    const info = db.prepare('INSERT INTO users(name,email,password_hash) VALUES(?,?,?)').run(name, email, hash);
    const user = { id: info.lastInsertRowid, name, email };
    res.status(201).json({ token: tokenFor(user), user });
  } catch (e) {
    res.status(409).json({ error: 'هذا البريد مستخدم بالفعل.' });
  }
});

app.post('/auth/login', async (req, res) => {
  const email = String(req.body?.email || '').trim().toLowerCase();
  const password = String(req.body?.password || '');
  const user = db.prepare('SELECT id,name,email,password_hash FROM users WHERE email=?').get(email);
  if (!user || !(await bcrypt.compare(password, user.password_hash))) return res.status(401).json({ error: 'البريد أو كلمة المرور غير صحيحة.' });
  db.prepare('UPDATE users SET last_seen=CURRENT_TIMESTAMP WHERE id=?').run(user.id);
  res.json({ token: tokenFor(user), user: { id: user.id, name: user.name, email: user.email } });
});

app.get('/auth/me', auth, (req, res) => {
  const user = db.prepare('SELECT id,name,email,created_at,last_seen FROM users WHERE id=?').get(req.user.id);
  if (!user) return res.status(404).json({ error: 'الحساب غير موجود.' });
  res.json({ user });
});

app.get('/usage', auth, (req, res) => {
  const total = db.prepare('SELECT COUNT(*) AS n FROM usage WHERE user_id=?').get(req.user.id).n;
  const today = db.prepare("SELECT COUNT(*) AS n FROM usage WHERE user_id=? AND date(created_at)=date('now')").get(req.user.id).n;
  const byProvider = db.prepare('SELECT provider, COUNT(*) AS n FROM usage WHERE user_id=? GROUP BY provider').all(req.user.id);
  const registeredUsers = db.prepare('SELECT COUNT(*) AS n FROM users').get().n;
  res.json({ total, today, byProvider, registeredUsers });
});

async function gemini(message, hist, web, file) {
  if (!process.env.GEMINI_API_KEY) throw Error('GEMINI_API_KEY missing');
  const parts = [{ text: message }];
  if (file) parts.push({ inline_data: { mime_type: mime(file), data: file.buffer.toString('base64') } });
  const body = { systemInstruction: { parts: [{ text: SYSTEM }] }, contents: [...hist, { role: 'user', parts }] };
  if (web) body.tools = [{ google_search: {} }];
  const r = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${GEMINI_MODEL}:generateContent?key=${encodeURIComponent(process.env.GEMINI_API_KEY)}`, {
    method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body)
  });
  const d = await r.json();
  if (!r.ok) throw Error(d?.error?.message || 'Gemini request failed');
  let text = (d?.candidates?.[0]?.content?.parts || []).map(x => x.text || '').join('').trim() || 'لم تصل إجابة.';
  return { reply: text, sources: urls(d), provider: 'gemini' };
}

async function groq(message, hist, file) {
  if (!process.env.GROQ_API_KEY) throw Error('GROQ_API_KEY missing');
  const image = file && /^image\//.test(file.mimetype || '');
  const base = [{ role: 'system', content: SYSTEM }, ...hist.map(x => ({ role: x.role === 'model' ? 'assistant' : 'user', content: x.parts?.[0]?.text || '' }))];
  if (image) base.push({ role: 'user', content: [{ type: 'text', text: message }, { type: 'image_url', image_url: { url: `data:${file.mimetype};base64,${file.buffer.toString('base64')}` } }] });
  else base.push({ role: 'user', content: message });
  let last;
  for (const model of [GROQ_MODEL, GROQ_FALLBACK_MODEL]) {
    try {
      const r = await fetch('https://api.groq.com/openai/v1/chat/completions', {
        method: 'POST', headers: { Authorization: `Bearer ${process.env.GROQ_API_KEY}`, 'Content-Type': 'application/json' },
        body: JSON.stringify({ model: image ? 'qwen/qwen3.8-27b' : model, messages: base, temperature: .15, reasoning_effort: 'medium' })
      });
      const d = await r.json();
      if (!r.ok) throw Error(d?.error?.message || `Groq request failed (${r.status})`);
      const text = String(d?.choices?.[0]?.message?.content || '').trim();
      if (text) return { reply: text, sources: [], provider: 'groq' };
      throw Error('Groq returned an empty response');
    } catch (e) { last = e; if (image) break; }
  }
  throw last || Error('Groq request failed');
}

app.post('/chat', auth, upload.single('file'), async (req, res) => {
  const message = String(req.body?.message || '').trim();
  if (!message && !req.file) return res.status(400).json({ error: 'message required' });
  const web = String(req.body?.web_search) === 'true';
  const hist = history(req.body?.history);
  const target = requestedWordCount(message);
  try {
    let out;
    try { out = await gemini(message || 'حلل الملف المرفق.', hist, web, req.file); }
    catch { out = await groq(message || 'حلل الملف المرفق.', hist, req.file); }
    if (target) {
      const repair = async prompt => {
        const x = await gemini(prompt, [], false, null).catch(() => groq(prompt, [], null));
        return x.reply;
      };
      out.reply = await repairWordCount(out.reply, message, target, repair);
    }
    db.prepare('INSERT INTO usage(user_id,provider,kind) VALUES(?,?,?)').run(req.user.id, out.provider || 'unknown', req.file ? 'file' : 'chat');
    res.json(out);
  } catch (e) { res.status(500).json({ error: e.message }); }
});


async function optimizeVideoPrompt(prompt) {
  const instruction = `حوّل طلب الفيديو التالي إلى Prompt إنجليزي احترافي جدًا ومحدد لمولد LTX 2.3 Pro.
- افهم المعنى من السياق حتى لو كتب المستخدم بأي لهجة عربية أو مزج بين لهجات ولغات: الليبية، الخليجية، السعودية، الكويتية، الإماراتية، القطرية، البحرينية، العمانية، المصرية، الشامية السورية واللبنانية والأردنية والفلسطينية، العراقية، اليمنية، السودانية، الحجازية، النجدية، المغربية، الجزائرية، التونسية، الموريتانية، وغيرها.
- لا تعتمد على تطابق كلمة واحدة فقط؛ فكّك المعنى المقصود، والفاعل، والمفعول، والزمن، والمكان، والحركة، ودرجة الواقعية من الجملة كاملة.
- حافظ حرفيًا على تفاصيل المستخدم المقصودة ولا تستبدل أسماء الأشخاص أو الأماكن أو الأشياء أو ألوانها أو أفعالها.
- اكتب Prompt واحدًا متصلًا بالإنجليزية، بصياغة سينمائية دقيقة، ويشمل الموضوع والحركة والكاميرا والإضاءة والعدسة والعمق والتفاصيل البصرية والصوت والجو العام عندما تكون ذات صلة.
- لا تخترع عناصر جوهرية غير موجودة في الطلب. يمكنك إضافة تفاصيل تقنية صغيرة فقط لتحسين الاتساق البصري عندما لا تغيّر المعنى.
- إذا لم يحدد المستخدم حركة كاميرا، اختر حركة بسيطة وطبيعية مناسبة للمشهد بدل حركة مبالغ فيها.
- إذا طلب المستخدم فيديو واقعيًا، استخدم وصفًا فوتوغرافيًا/سينمائيًا واقعيًا؛ وإذا طلب كرتونًا أو أنمي أو لعبة أو أسلوبًا فنيًا، حافظ على ذلك الأسلوب.
- اجعل الناتج أقل من 200 كلمة، ولا تضف شرحًا أو عنوانًا أو اقتباسات.

طلب المستخدم:
${String(prompt || '').trim()}`;
  try {
    const x = await gemini(instruction, [], false, null);
    if (x.reply?.trim()) return x.reply.trim();
  } catch {}
  try {
    const x = await groq(instruction, [], null);
    if (x.reply?.trim()) return x.reply.trim();
  } catch {}
  return String(prompt || '').trim();
}

function pickVideoAspectRatio(prompt) {
  const s = String(prompt || '').toLowerCase();
  if (/(عمودي|رأسي|طولي|ستوري|ريلز|رييلز|تيك ?توك|9\s*[:x×]\s*16|portrait|vertical|reel|tiktok|story)/iu.test(s)) return '9:16';
  return '16:9';
}

function pickCameraMotion(prompt) {
  const s = String(prompt || '').toLowerCase();
  if (/(زووم\s*إن|تقريب|اقتراب\s*الكاميرا|dolly\s*in|zoom\s*in)/iu.test(s)) return 'dolly_in';
  if (/(زووم\s*أوت|ابتعاد\s*الكاميرا|dolly\s*out|zoom\s*out)/iu.test(s)) return 'dolly_out';
  if (/(يسار|إلى اليسار|dolly\s*left|pan\s*left)/iu.test(s)) return 'dolly_left';
  if (/(يمين|إلى اليمين|dolly\s*right|pan\s*right)/iu.test(s)) return 'dolly_right';
  if (/(ترتفع|للأعلى|إلى فوق|jib\s*up|crane\s*up)/iu.test(s)) return 'jib_up';
  if (/(تنخفض|للأسفل|إلى تحت|jib\s*down|crane\s*down)/iu.test(s)) return 'jib_down';
  if (/(تركيز\s*على|فوكس|focus\s*shift|rack\s*focus)/iu.test(s)) return 'focus_shift';
  if (/(ثابتة|ثابت|بدون حركة|static|locked\s*off)/iu.test(s)) return 'static';
  return 'none';
}

function parseVideoDuration(text) {
  const s = String(text || '').toLowerCase().trim();
  if (!s) return null;
  let total = 0;
  const hour = s.match(/(\d+(?:\.\d+)?)\s*(?:h|hr|hrs|hour|hours|ساعة|ساعات|ساعه|ساعةً)/iu);
  const minute = s.match(/(\d+(?:\.\d+)?)\s*(?:m|min|mins|minute|minutes|دقيقة|دقائق|دقيقه)/iu);
  const second = s.match(/(\d+(?:\.\d+)?)\s*(?:s|sec|secs|second|seconds|ثانية|ثواني|ثانيه)/iu);
  if (hour) total += Number(hour[1]) * 3600;
  if (minute) total += Number(minute[1]) * 60;
  if (second) total += Number(second[1]);
  if (!total && /(نصف\s+ساعة|نص\s+ساعة|half\s+an?\s+hour)/iu.test(s)) total = 1800;
  if (!total && /(ساعة\s+كاملة|لمدة\s+ساعة|مدة\s+ساعة|ساعة\s+واحدة|one\s+hour|an?\s+hour)/iu.test(s)) total = 3600;
  if (!total && /(دقيقة\s+واحدة|دقيقة\s+كاملة|لمدة\s+دقيقة|مدة\s+دقيقة|one\s+minute|a\s+minute)/iu.test(s)) total = 60;
  if (!total && /(ثانية\s+واحدة|ثانية\s+كاملة|one\s+second|a\s+second)/iu.test(s)) total = 1;
  return total > 0 ? Math.min(3600, Math.round(total)) : null;
}

const videoJobs = new Map();

function createVideoJob(userId, prompt, imageFile) {
  const id = `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 10)}`;
  const requested = parseVideoDuration(prompt);
  const job = {
    id,
    userId,
    prompt,
    imageFile: imageFile ? { buffer: Buffer.from(imageFile.buffer), mimetype: imageFile.mimetype || 'image/png' } : null,
    status: 'queued',
    progress: 0,
    requestedDuration: requested,
    duration: requested || null,
    quality: 'LoreMotion live maximum / model tier',
    videoUrl: null,
    error: null,
    createdAt: Date.now(),
  };
  videoJobs.set(id, job);
  return job;
}

const loreMotionBrowser = new LoreMotionBrowser();
const loreMotion = new LoreMotionClient(loreMotionBrowser);

async function runVideoJob(job) {
  job.status = 'running';
  try {
    const optimizedPrompt = await optimizeVideoPrompt(job.prompt);
    const model = /minimax|h3/i.test(job.prompt) ? 'minimax-h3' : 'ltx-2.5';
    const requestedDuration = job.requestedDuration || undefined;
    const imagePath = job.imageFile ? await (async () => {
      const temp = path.join(os.tmpdir(), `ai-assistant-${job.id}${path.extname(job.imageFile.mimetype || '') || '.png'}`);
      await fs.promises.writeFile(temp, job.imageFile.buffer);
      job.tempImagePath = temp;
      return temp;
    })() : undefined;

    const result = await loreMotion.generate({
      prompt: optimizedPrompt,
      model,
      aspectRatio: pickVideoAspectRatio(job.prompt),
      durationSeconds: requestedDuration,
      imagePath,
      timeoutMs: Number(process.env.LOREMOTION_GENERATION_TIMEOUT_MS || 900000),
    });

    job.requestedDuration = result.requested;
    job.duration = result.actual;
    job.totalSeconds = result.actual;
    job.completedSeconds = result.actual;
    job.progress = 100;
    job.capped = Boolean(result.capped);
    job.cappedFrom = result.capped ? result.requested : null;
    job.quality = `LoreMotion ${result.model} • live max ${result.max}s • ${result.aspectRatio}`;
    job.videoUrl = result.videoUrl || null;
    job.shareUrl = result.shareUrl || null;
    if (!job.videoUrl && job.shareUrl) {
      throw new Error('اكتمل الفيديو في LoreMotion لكن لم يمكن استخراج ملف MP4 مباشرة.');
    }
    job.status = 'succeeded';
    db.prepare('INSERT INTO usage(user_id,provider,kind) VALUES(?,?,?)').run(job.userId, `loremotion-${result.model}`, 'video');
  } catch (e) {
    job.error = e?.message || 'فشل توليد الفيديو.';
    job.status = 'failed';
  } finally {
    if (job.tempImagePath) await fs.promises.rm(job.tempImagePath, { force: true }).catch(() => {});
    job.imageFile = null;
  }
}

app.post('/video/generate', auth, upload.single('image'), async (req, res) => {
  const prompt = String(req.body?.prompt || '').trim();
  if (!prompt) return res.status(400).json({ error: 'اكتب وصف الفيديو أولًا.' });
  try {
    const job = createVideoJob(req.user.id, prompt, req.file);
    void runVideoJob(job).then(() => setTimeout(() => videoJobs.delete(job.id), 6 * 60 * 60 * 1000));
    res.status(202).json({ job_id: job.id, status: job.status, duration: job.duration, requested_duration: job.requestedDuration, quality: job.quality, provider: 'loremotion' });
  } catch (e) {
    res.status(500).json({ error: e.message || 'فشل بدء توليد الفيديو.' });
  }
});

app.get('/video/status/:id', auth, async (req, res) => {
  const job = videoJobs.get(String(req.params.id || ''));
  if (!job || job.userId !== req.user.id) return res.status(404).json({ error: 'لم يتم العثور على مهمة الفيديو.' });
  const body = {
    job_id: job.id,
    status: job.status,
    progress: job.progress,
    duration: job.duration || 0,
    requested_duration: job.requestedDuration || null,
    quality: job.quality,
    completed_seconds: job.completedSeconds || 0,
    total_seconds: job.totalSeconds || job.duration || 0,
    provider: 'loremotion',
    capped: Boolean(job.capped),
    capped_from: job.cappedFrom || null,
  };
  if (job.status === 'succeeded') {
    body.video_url = job.videoUrl;
    body.share_url = job.shareUrl || null;
  }
  if (job.status === 'failed') body.error = job.error;
  res.json(body);
});

app.get('/video/config', auth, async (_req, res) => {
  res.json({
    provider: 'loremotion',
    session_mode: loreMotionConfig.sessionMode,
    base_url: loreMotionConfig.baseUrl,
    note: loreMotionConfig.sessionMode === 'persistent'
      ? 'LoreMotion uses the persistent browser profile for the signed-in session.'
      : 'Anonymous mode is limited by LoreMotion account/session policy; use persistent mode for an authenticated free account.',
  });
});

app.listen(PORT, () => console.log(`AI Assistant backend listening on ${PORT}`));
