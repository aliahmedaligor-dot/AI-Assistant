import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import { spawn } from 'node:child_process';
import ffmpegStatic from 'ffmpeg-static';
import { composeVideo, probeMedia } from './video_pipeline.js';

const ffmpeg = process.env.FFMPEG_PATH || ffmpegStatic || 'ffmpeg';
function run(args) {
  return new Promise((resolve, reject) => {
    const p = spawn(ffmpeg, args, { stdio: 'ignore' });
    p.on('error', reject);
    p.on('close', code => code === 0 ? resolve() : reject(new Error(`ffmpeg exit ${code}`)));
  });
}

test('multi-segment pipeline creates one continuous MP4', async () => {
  const dir = await fs.mkdtemp(path.join(os.tmpdir(), 'ai-assistant-video-test-'));
  try {
    const a = path.join(dir, 'a.mp4');
    const b = path.join(dir, 'b.mp4');
    const out = path.join(dir, 'final.mp4');
    await run(['-y', '-f', 'lavfi', '-i', 'color=c=blue:s=320x180:r=24', '-f', 'lavfi', '-i', 'anullsrc=r=48000:cl=stereo', '-t', '2', '-shortest', '-c:v', 'libx264', '-pix_fmt', 'yuv420p', '-c:a', 'aac', a]);
    await run(['-y', '-f', 'lavfi', '-i', 'color=c=red:s=320x180:r=24', '-f', 'lavfi', '-i', 'anullsrc=r=48000:cl=stereo', '-t', '2', '-shortest', '-c:v', 'libx264', '-pix_fmt', 'yuv420p', '-c:a', 'aac', b]);
    const result = await composeVideo([a, b], out, 3.6, 0.2);
    assert.ok(result.duration > 3.2 && result.duration <= 3.7);
    const finalInfo = await probeMedia(out);
    assert.ok(finalInfo.duration > 3.2);
    assert.equal(finalInfo.hasAudio, true);
  } finally {
    await fs.rm(dir, { recursive: true, force: true });
  }
});
