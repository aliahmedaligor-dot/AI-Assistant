import 'dotenv/config';
import fs from 'node:fs/promises';
import path from 'node:path';
import { chromium } from 'playwright';

const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
const bool = (value, fallback = false) => value == null ? fallback : /^(1|true|yes|on)$/i.test(String(value));

const config = {
  baseUrl: (process.env.LOREMOTION_BASE_URL || 'https://loremotion.com').replace(/\/$/, ''),
  sessionMode: (process.env.LOREMOTION_SESSION_MODE || 'anonymous').toLowerCase() === 'persistent' ? 'persistent' : 'anonymous',
  profileDir: path.resolve(process.env.LOREMOTION_PROFILE_DIR || '.loremotion-profile'),
  downloadDir: path.resolve(process.env.LOREMOTION_DOWNLOAD_DIR || 'downloads'),
  headless: bool(process.env.LOREMOTION_HEADLESS, true),
  browserChannel: (process.env.LOREMOTION_BROWSER_CHANNEL || '').trim(),
  executablePath: (process.env.LOREMOTION_EXECUTABLE_PATH || process.env.PLAYWRIGHT_CHROMIUM_EXECUTABLE_PATH || '').trim() || null,
  timeoutMs: Number(process.env.LOREMOTION_TIMEOUT_MS || 30000),
  generationTimeoutMs: Number(process.env.LOREMOTION_GENERATION_TIMEOUT_MS || 900000),
};

const selectorDefaults = {
  prompt: [
    'textarea[placeholder*="prompt" i]',
    'textarea[placeholder*="describe" i]',
    'textarea[placeholder*="scene" i]',
    'textarea',
    '[contenteditable="true"][role="textbox"]',
  ],
  file: ['input[type="file"]'],
  generate: ['button:has-text("Generate")', '[role="button"]:has-text("Generate")'],
  duration: ['input[type="range"]', 'select[name*="duration" i]', '[aria-label*="duration" i]'],
};

function escapeRegex(value) {
  return String(value).replace(/[.*+?^${}()|[\\]\\]/g, '\\$&');
}

function selectors(name) {
  let overrides = {};
  try { overrides = JSON.parse(process.env.LOREMOTION_SELECTORS_JSON || '{}'); } catch {}
  return [...(Array.isArray(overrides?.[name]) ? overrides[name] : []), ...(selectorDefaults[name] || [])];
}

export class LoreMotionBrowser {
  constructor() {
    this.browser = null;
    this.context = null;
    this.lock = Promise.resolve();
  }

  async withLock(fn) {
    const previous = this.lock;
    let release;
    this.lock = new Promise((resolve) => { release = resolve; });
    await previous;
    try { return await fn(); } finally { release(); }
  }

  async getContext() {
    if (this.context) return this.context;
    await fs.mkdir(config.downloadDir, { recursive: true });
    if (config.sessionMode === 'persistent') {
      await fs.mkdir(config.profileDir, { recursive: true });
      const launch = {
        headless: config.headless,
        acceptDownloads: true,
        viewport: { width: 1440, height: 1000 },
        args: ['--no-sandbox', '--disable-dev-shm-usage', '--disable-gpu'],
      };
      if (config.executablePath) launch.executablePath = config.executablePath;
      else if (config.browserChannel) launch.channel = config.browserChannel;
      this.context = await chromium.launchPersistentContext(config.profileDir, launch);
    } else {
      const launch = {
        headless: config.headless,
        args: ['--no-sandbox', '--disable-dev-shm-usage', '--disable-gpu'],
      };
      if (config.executablePath) launch.executablePath = config.executablePath;
      else if (config.browserChannel) launch.channel = config.browserChannel;
      this.browser = await chromium.launch(launch);
      this.context = await this.browser.newContext({ acceptDownloads: true, viewport: { width: 1440, height: 1000 } });
    }
    this.context.setDefaultTimeout(config.timeoutMs);
    return this.context;
  }

  async newPage(pathname = '/generate/') {
    const context = await this.getContext();
    const page = await context.newPage();
    await page.goto(`${config.baseUrl}${pathname}`, { waitUntil: 'domcontentloaded', timeout: 60000 });
    await page.waitForTimeout(1200);
    return page;
  }

  async close() {
    await this.context?.close().catch(() => {});
    await this.browser?.close().catch(() => {});
    this.context = null;
    this.browser = null;
  }
}

async function firstVisible(page, list) {
  for (const selector of list) {
    try {
      const loc = page.locator(selector).first();
      if (await loc.count() && await loc.isVisible()) return loc;
    } catch {}
  }
  return null;
}

async function clickChoice(page, labels) {
  for (const label of labels) {
    const rx = label instanceof RegExp ? label : new RegExp(escapeRegex(label), 'i');
    for (const role of ['button', 'radio', 'option', 'tab']) {
      try {
        const loc = page.getByRole(role, { name: rx }).first();
        if (await loc.count() && await loc.isVisible()) { await loc.click(); return true; }
      } catch {}
    }
    for (const selector of ['button', '[role="button"]', '[role="option"]', '[role="radio"]', 'label']) {
      try {
        const loc = page.locator(selector).filter({ hasText: rx }).first();
        if (await loc.count() && await loc.isVisible()) { await loc.click(); return true; }
      } catch {}
    }
  }
  return false;
}

function modelLabels(model) {
  return model === 'minimax-h3' ? [/MiniMax\s*H3/i, /H3/i] : [/LTX(?:-Video)?\s*2\.5/i, /LTX\s*2\.5/i, /LTX/i];
}

function aspectLabels(aspect) {
  return [new RegExp(`^\\s*${aspect.replace(':', '\\s*:\\s*')}\\s*$`, 'i'), new RegExp(aspect.replace(':', '.*'), 'i')];
}

async function chooseTextControl(page, name, labels) {
  const direct = await firstVisible(page, selectors(name));
  if (direct) {
    try {
      const tag = await direct.evaluate((el) => el.tagName.toLowerCase());
      if (tag === 'select') {
        const options = await direct.locator('option').allTextContents();
        for (const label of labels) {
          const rx = label instanceof RegExp ? label : new RegExp(escapeRegex(label), 'i');
          const found = options.find((x) => rx.test(x));
          if (found) { await direct.selectOption({ label: found }); return true; }
        }
      }
    } catch {}
  }
  return clickChoice(page, labels);
}

async function chooseModel(page, model) {
  if (await chooseTextControl(page, 'model', modelLabels(model))) return;
  const combo = page.locator('select, [role="combobox"]').filter({ hasText: /LTX|MiniMax|H3|Model/i }).first();
  if (await combo.count()) { try { await combo.click(); if (await clickChoice(page, modelLabels(model))) return; } catch {} }
  throw new Error(`لم أستطع اختيار نموذج ${model} من واجهة LoreMotion الحالية.`);
}

async function chooseAspect(page, aspect) {
  const labels = aspectLabels(aspect);
  if (await chooseTextControl(page, 'aspect', labels)) return;
  const combos = page.locator('select, [role="combobox"]');
  for (let i = 0; i < await combos.count(); i++) {
    const c = combos.nth(i);
    try {
      if (/16:9|9:16|1:1|4:3/.test(await c.innerText())) { await c.click(); if (await clickChoice(page, labels)) return; }
    } catch {}
  }
  throw new Error(`لم أستطع اختيار نسبة ${aspect} من واجهة LoreMotion الحالية.`);
}

async function durationRange(page) {
  const ranges = page.locator('input[type="range"]');
  let best = null;
  let score = -1;
  for (let i = 0; i < await ranges.count(); i++) {
    const r = ranges.nth(i);
    if (!await r.isVisible().catch(() => false)) continue;
    const meta = await r.evaluate((el) => {
      const parent = el.closest('label,[role="group"],div') || el.parentElement;
      return {
        min: el.min,
        max: el.max,
        value: el.value,
        hint: `${el.getAttribute('name') || ''} ${el.getAttribute('aria-label') || ''} ${(parent?.innerText || '')}`,
      };
    });
    let current = /duration|length|seconds?|\bsec\b/i.test(meta.hint) ? 10 : 0;
    const max = Number(meta.max);
    if (Number.isFinite(max) && max > 0 && max <= 60) current += 3;
    if (current > score) { score = current; best = { locator: r, ...meta, maxNumber: Number.isFinite(max) ? max : null, minNumber: Number(meta.min) || 0 }; }
  }
  return best;
}

async function setDuration(page, requestedSeconds) {
  const meta = await durationRange(page);
  if (!meta) throw new Error('واجهة LoreMotion لم تعرض منزلق مدة يمكن قراءته.');
  const max = meta.maxNumber ?? 10;
  const min = meta.minNumber ?? 1;
  const actual = Math.max(min, Math.min(max, Math.round(requestedSeconds)));
  await meta.locator.evaluate((el, value) => {
    const setter = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value')?.set;
    if (!setter) throw new Error('Native range setter unavailable');
    setter.call(el, String(value));
    el.dispatchEvent(new Event('input', { bubbles: true }));
    el.dispatchEvent(new Event('change', { bubbles: true }));
  }, actual);
  const readBack = Number(await meta.locator.inputValue());
  if (!Number.isFinite(readBack) || readBack !== actual) throw new Error(`لم تثبت مدة الفيديو ${actual} ثانية في LoreMotion.`);
  return { requested: Number(requestedSeconds), actual, min, max, capped: actual !== Number(requestedSeconds) };
}

async function fillPrompt(page, prompt) {
  const loc = await firstVisible(page, selectors('prompt'));
  if (!loc) throw new Error('لم أجد حقل وصف الفيديو في LoreMotion.');
  await loc.fill(prompt);
}

async function uploadImage(page, imagePath) {
  const resolved = path.resolve(imagePath);
  await fs.access(resolved);
  let input = await firstVisible(page, selectors('file'));
  if (!input) { await clickChoice(page, [/image.?to.?video/i, /upload/i, /reference image/i]); input = await firstVisible(page, selectors('file')); }
  if (!input) throw new Error('لم أجد زر/حقل رفع الصورة في LoreMotion.');
  await input.setInputFiles(resolved);
}

async function snapshotMedia(page) {
  return page.evaluate(() => {
    const absolute = (u) => { try { return new URL(u, location.href).href; } catch { return u; } };
    const videos = [...document.querySelectorAll('video')].flatMap((v) => [v.currentSrc, v.src, v.querySelector('source')?.src]).filter(Boolean).map(absolute);
    const links = [...document.querySelectorAll('a[href]')].map((a) => absolute(a.getAttribute('href')));
    return {
      videoUrls: [...new Set(videos)],
      mp4Urls: [...new Set([...videos, ...links.filter((x) => /\.mp4(?:\?|$)/i.test(x))])],
      shareUrls: [...new Set(links.filter((x) => /\/v\/[A-Za-z0-9_-]+/.test(x)))],
    };
  });
}

async function hasTurnstile(page) {
  return page.evaluate(() => {
    const hidden = [...document.querySelectorAll('input[name="cf-turnstile-response"]')];
    if (!hidden.length) return false;
    const solved = hidden.some((x) => String(x.value || '').trim());
    const visible = [...document.querySelectorAll('iframe[src*="challenges.cloudflare.com"],.cf-turnstile,[data-sitekey]')].some((el) => {
      const r = el.getBoundingClientRect(); const s = getComputedStyle(el);
      return r.width > 0 && r.height > 0 && s.display !== 'none' && s.visibility !== 'hidden';
    });
    return !solved && visible;
  }).catch(() => false);
}

async function clickGenerate(page) {
  if (await hasTurnstile(page)) throw new Error('LoreMotion طلب التحقق من Cloudflare. أكمل التحقق في جلسة المتصفح أو استخدم جلسة LoreMotion مسجلة الدخول.');
  let button = null;
  try {
    const semantic = page.getByRole('button', { name: /generate/i }).first();
    if (await semantic.count() && await semantic.isVisible()) button = semantic;
  } catch {}
  button ||= await firstVisible(page, selectors('generate'));
  if (!button) throw new Error('لم أجد زر Generate في LoreMotion.');
  for (let i = 0; i < 20 && await button.isDisabled().catch(() => false); i++) await sleep(250);
  if (await button.isDisabled().catch(() => false)) throw new Error('زر Generate بقي معطلًا.');
  await button.click();
}

async function waitForResult(page, before, timeoutMs) {
  const deadline = Date.now() + timeoutMs;
  while (Date.now() < deadline) {
    if (await hasTurnstile(page)) throw new Error('ظهر تحقق Cloudflare أثناء التوليد.');
    const current = await snapshotMedia(page);
    const newUrl = current.mp4Urls.find((u) => !before.mp4Urls.includes(u)) || current.videoUrls.find((u) => !before.videoUrls.includes(u));
    const newShare = current.shareUrls.find((u) => !before.shareUrls.includes(u));
    if (newUrl || newShare) return { videoUrl: newUrl || null, shareUrl: newShare || null };
    const body = (await page.locator('body').innerText().catch(() => '')).toLowerCase();
    if (/generation failed|render failed|something went wrong|error generating/.test(body)) throw new Error('LoreMotion أعلن فشل عملية التوليد.');
    await sleep(1800);
  }
  throw new Error('انتهت مهلة انتظار فيديو LoreMotion.');
}

export class LoreMotionClient {
  constructor(browser) { this.browser = browser; }

  async generate({ prompt, model = 'ltx-2.5', aspectRatio = '16:9', durationSeconds, imagePath, timeoutMs = config.generationTimeoutMs }) {
    return this.browser.withLock(async () => {
      const page = await this.browser.newPage('/generate/');
      try {
        const before = await snapshotMedia(page);
        await chooseModel(page, model);
        await fillPrompt(page, prompt);
        if (imagePath) await uploadImage(page, imagePath);
        await chooseAspect(page, aspectRatio);
        const range = await durationRange(page);
        const desired = Number.isFinite(Number(durationSeconds)) ? Number(durationSeconds) : (range?.maxNumber ?? 10);
        const duration = await setDuration(page, desired);
        await clickGenerate(page);
        const result = await waitForResult(page, before, timeoutMs);
        return { model, aspectRatio, ...duration, ...result, pageUrl: page.url(), sessionMode: config.sessionMode };
      } finally {
        await page.close().catch(() => {});
      }
    });
  }

  async downloadVideo(videoUrl, filename = `loremotion-${Date.now()}.mp4`) {
    const context = await this.browser.getContext();
    const response = await context.request.get(videoUrl);
    if (!response.ok()) throw new Error(`تعذر تنزيل فيديو LoreMotion: HTTP ${response.status()}`);
    const safe = String(filename).replace(/[^A-Za-z0-9._-]/g, '_').replace(/\.mp4$/i, '') + '.mp4';
    const output = path.join(config.downloadDir, safe);
    await fs.writeFile(output, await response.body());
    return output;
  }
}

export const loreMotionConfig = config;
