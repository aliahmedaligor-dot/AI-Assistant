# AI Assistant secure backend

The backend keeps Gemini/Groq keys server-side and adds account authentication plus real per-user usage data.

1. Copy `.env.example` to `.env`.
2. Set a strong `JWT_SECRET` and your provider keys.
3. Run `npm install`.
4. Run `npm start`.
5. Put the backend URL into the app settings, then create an account.

The app uses `/auth/register`, `/auth/login`, `/auth/me`, `/usage`, and authenticated `/chat`.
