# AI Assistant secure backend

The backend keeps Gemini/Groq keys server-side and adds account authentication plus real per-user usage data.

1. Copy `.env.example` to `.env`.
2. Set a strong `JWT_SECRET` and your provider keys.
3. Run `npm install`.
4. Run `npm start`.
5. Put the backend URL into the app settings, then create an account.

The app uses `/auth/register`, `/auth/login`, `/auth/me`, `/usage`, and authenticated `/chat`.


## LoreMotion video generation

The `/video/generate` endpoint now uses a Playwright bridge to the public LoreMotion website instead of requiring the old Replicate/LTX API token. This is an unofficial UI integration, not a LoreMotion developer API. The bridge does not bypass ads, Cloudflare, sign-in, or site limits. LoreMotion currently advertises free unlimited LTX-Video 2.5 and MiniMax H3 with model/tier-specific duration limits; the integration reads the live duration slider and uses the maximum currently exposed to the session, rather than hard-coding 10 seconds.

For persistent/free-account use, set `LOREMOTION_SESSION_MODE=persistent`, authenticate a dedicated LoreMotion browser profile once on an interactive machine, and securely place/import that profile on the backend host. Never commit the profile or passwords/cookies to Git. Anonymous mode is useful for testing but is subject to LoreMotion's anonymous/session limits.

Backend prerequisites: Node.js 20+, `npm install`, and a Playwright-compatible Chromium/Chrome executable. Run `npm run check` to validate JavaScript syntax.


### Long-video continuity and video recognition

The backend can split a requested long video into multiple LoreMotion segments, extract the last frame from each segment, and use that frame as the reference for the next segment. It then normalizes and merges the segments with a short visual/audio crossfade and trims the final MP4 to the requested duration when possible. The app downloads the final MP4 locally, so it remains playable in the chat even when the provider URL expires.

The pipeline requires `ffmpeg` and `ffprobe` on the backend host. Set `LOREMOTION_SESSION_MODE=persistent` for an authenticated session when the LoreMotion anonymous session is insufficient. The integration never attempts to solve or bypass Cloudflare challenges.

The backend also exposes authenticated `POST /video/analyze`; the app automatically sends the most recent generated video to this endpoint when the user asks things like «شن فيه الفيديو؟» or «حلل الفيديو». The analyzer samples frames from the video and uses Gemini vision first, with a Groq vision fallback when available.

The Android build itself does not run Node/Playwright. For video generation, the APK must point to a reachable deployed instance of this backend and the user must be authenticated there. No fake local video is generated when the backend is unavailable.
