# AI Assistant secure backend

The backend keeps Gemini/Groq keys server-side and adds account authentication plus real per-user usage data.

1. Copy `.env.example` to `.env`.
2. Set a strong `JWT_SECRET` and your provider keys.
3. Run `npm install`.
4. Run `npm start`.
5. Put the backend URL into the app settings, then create an account.

The app uses `/auth/register`, `/auth/login`, `/auth/me`, `/usage`, and authenticated `/chat`.


## LoreMotion video generation

The `/video/generate` endpoint now uses a Playwright bridge to the public LoreMotion website instead of requiring the old Replicate/LTX API token. This is an unofficial UI integration, not a LoreMotion developer API. The bridge does not bypass ads, Cloudflare, sign-in, or site limits. LoreMotion currently advertises free unlimited LTX-Video 2.5 and MiniMax H3 with model/tier-specific duration limits; the integration reads the live duration slider and uses the maximum currently exposed to the session, rather than hard-coding 10 seconds.

For persistent/free-account use, set `LOREMOTION_SESSION_MODE=persistent`, authenticate a dedicated LoreMotion browser profile once on an interactive machine, and securely place/import that profile on the backend host. Never commit the profile or passwords/cookies to Git. Anonymous mode is useful for testing but is subject to LoreMotion's anonymous/session limits.

Backend prerequisites: Node.js 20+, `npm install`, and a Playwright-compatible Chromium/Chrome executable. Run `npm run check` to validate JavaScript syntax.
