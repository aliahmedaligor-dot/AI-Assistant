# AI Assistant secure backend

The backend keeps Gemini/Groq keys server-side and adds account authentication plus per-user usage data.

## Start

1. Copy `.env.example` to `.env`.
2. Set a strong `JWT_SECRET` and provider keys.
3. Run `npm install`.
4. Run `npm run check` and `npm test`.
5. Run `npm start`.

## Video generation

`/video/generate` uses a Playwright bridge to the public LoreMotion website. This is an unofficial UI integration, not a LoreMotion developer API. It does not bypass Cloudflare, sign-in, ads, or site limits. LoreMotion exposes short per-clip limits; the backend reads the live limit from the page.

For requests longer than one LoreMotion clip, AI Assistant automatically creates multiple continuation segments and assembles them into one final MP4. Each continuation uses the previous segment's last frame as a visual reference, the prompt enforces identity/scene/camera continuity, and FFmpeg adds a short video/audio crossfade. The app gives the user the finished MP4 instead of the individual segments.

Durations can be written in Arabic or English (for example `30 ثانية`, `2 دقيقة`, `1 ساعة`). The default target is 30 seconds when no duration is specified. The maximum configured target is 1 hour by default. Very long outputs can take substantially longer because LoreMotion still renders short clips one at a time.

Free LoreMotion models are currently advertised as unlimited; exact duration and quality depend on the model/tier and the live generator UI.

For persistent/free-account use, set `LOREMOTION_SESSION_MODE=persistent`, authenticate a dedicated LoreMotion browser profile once on an interactive machine, and securely place/import that profile on the backend host. Never commit the profile or passwords/cookies to Git. Anonymous mode remains subject to LoreMotion's anonymous/session policy.

Backend prerequisites: Node.js 20+. `ffmpeg-static` and `ffprobe-static` are bundled for the long-video assembly pipeline; `FFMPEG_PATH` and `FFPROBE_PATH` may override them.
