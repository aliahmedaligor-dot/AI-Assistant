import fs from 'node:fs/promises';
import path from 'node:path';
import { spawn } from 'node:child_process';
import ffmpegStatic from 'ffmpeg-static';
import ffprobeStatic from 'ffprobe-static';

const FFMPEG = process.env.FFMPEG_PATH || ffmpegStatic || 'ffmpeg';
const FFPROBE = process.env.FFPROBE_PATH || ffprobeStatic?.path || 'ffprobe';

function run(binary, args, { timeoutMs = 20 * 60 * 1000 } = {}) {
  return new Promise((resolve, reject) => {
    const child = spawn(binary, args, { stdio: ['ignore', 'pipe', 'pipe'] });
    const stdout = [];
    const stderr = [];
    const timer = setTimeout(() => {
      child.kill('SIGKILL');
      reject(new Error(`الأداة الخارجية تجاوزت المهلة: ${path.basename(binary)}`));
    }, timeoutMs);
    child.stdout?.on('data', chunk => stdout.push(Buffer.from(chunk)));
    child.stderr?.on('data', chunk => stderr.push(Buffer.from(chunk)));
    child.on('error', err => {
      clearTimeout(timer);
      reject(err);
    });
    child.on('close', code => {
      clearTimeout(timer);
      const out = Buffer.concat(stdout).toString('utf8');
      const err = Buffer.concat(stderr).toString('utf8');
      if (code === 0) return resolve({ stdout: out, stderr: err });
      const tail = err.trim().split(/\r?\n/).slice(-8).join('\n');
      reject(new Error(`FFmpeg/FFprobe فشل (${code}): ${tail || 'unknown error'}`));
    });
  });
}

export async function probeMedia(file) {
  const { stdout } = await run(FFPROBE, [
    '-v', 'error',
    '-show_entries', 'format=duration',
    '-show_entries', 'stream=codec_type',
    '-of', 'json',
    file,
  ]);
  const parsed = JSON.parse(stdout || '{}');
  const duration = Number(parsed?.format?.duration || 0);
  const hasAudio = Array.isArray(parsed?.streams) && parsed.streams.some(s => s?.codec_type === 'audio');
  return { duration: Number.isFinite(duration) ? duration : 0, hasAudio };
}

export async function extractLastFrame(inputFile, outputFile) {
  await fs.mkdir(path.dirname(outputFile), { recursive: true });
  await run(FFMPEG, [
    '-y', '-sseof', '-0.15', '-i', inputFile,
    '-frames:v', '1', '-q:v', '2',
    outputFile,
  ], { timeoutMs: 120000 });
  return outputFile;
}

export async function composeVideo(files, outputFile, targetSeconds, transitionSeconds = 0.35) {
  if (!Array.isArray(files) || files.length === 0) throw new Error('لا توجد مقاطع فيديو لتركيبها.');
  await fs.mkdir(path.dirname(outputFile), { recursive: true });

  const media = [];
  for (const file of files) {
    const info = await probeMedia(file);
    if (!info.duration || info.duration < 0.25) throw new Error(`المقطع غير صالح أو مدته غير مقروءة: ${file}`);
    media.push(info);
  }

  const transition = Math.max(0, Math.min(0.8, Number(transitionSeconds) || 0.35));
  const effectiveTransition = media.length > 1 ? transition : 0;
  const inputs = files.flatMap(file => ['-i', file]);
  const filters = [];

  media.forEach((info, i) => {
    filters.push(`[${i}:v]setpts=PTS-STARTPTS,settb=AVTB,fps=30,format=yuv420p,setsar=1[v${i}]`);
  });

  let currentVideo = 'v0';
  let currentDuration = media[0].duration;
  for (let i = 1; i < media.length; i++) {
    const next = `v${i}`;
    const out = `vx${i}`;
    const offset = Math.max(0, currentDuration - effectiveTransition);
    filters.push(`[${currentVideo}][${next}]xfade=transition=fade:duration=${effectiveTransition.toFixed(3)}:offset=${offset.toFixed(3)}[${out}]`);
    currentVideo = out;
    currentDuration += media[i].duration - effectiveTransition;
  }

  media.forEach((info, i) => {
    if (info.hasAudio) {
      filters.push(`[${i}:a]aformat=sample_rates=48000:channel_layouts=stereo,asetpts=PTS-STARTPTS[a${i}]`);
    } else {
      filters.push(`anullsrc=r=48000:cl=stereo:d=${Math.max(0.3, media[i].duration).toFixed(3)}[a${i}]`);
    }
  });

  let currentAudio = 'a0';
  for (let i = 1; i < media.length; i++) {
    const next = `a${i}`;
    const out = `ax${i}`;
    filters.push(`[${currentAudio}][${next}]acrossfade=d=${effectiveTransition.toFixed(3)}:c1=tri:c2=tri[${out}]`);
    currentAudio = out;
  }

  const args = [
    '-y',
    ...inputs,
    '-filter_complex', filters.join(';'),
    '-map', `[${currentVideo}]`,
    '-map', `[${currentAudio}]`,
    '-c:v', 'libx264',
    '-preset', process.env.VIDEO_FFMPEG_PRESET || 'medium',
    '-crf', process.env.VIDEO_FFMPEG_CRF || '18',
    '-pix_fmt', 'yuv420p',
    '-c:a', 'aac',
    '-b:a', '192k',
    '-movflags', '+faststart',
  ];
  if (Number.isFinite(Number(targetSeconds)) && Number(targetSeconds) > 0) {
    args.push('-t', Number(targetSeconds).toFixed(3));
  }
  args.push(outputFile);

  await run(FFMPEG, args, { timeoutMs: Math.max(20 * 60 * 1000, files.length * 3 * 60 * 1000) });
  const finalInfo = await probeMedia(outputFile);
  if (!finalInfo.duration || finalInfo.duration < 0.5) throw new Error('فشل إنشاء ملف الفيديو النهائي.');
  return { ...finalInfo, requested: Number(targetSeconds) || null };
}
