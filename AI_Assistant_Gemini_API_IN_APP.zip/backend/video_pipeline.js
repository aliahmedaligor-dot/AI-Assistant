import fs from 'node:fs/promises';
import path from 'node:path';
import { spawn } from 'node:child_process';

const CROSSFADE_SECONDS = 0.35;

function run(bin, args, options = {}) {
  return new Promise((resolve, reject) => {
    const child = spawn(bin, args, { stdio: ['ignore', 'pipe', 'pipe'], ...options });
    let stdout = '';
    let stderr = '';
    child.stdout.on('data', (chunk) => { stdout += chunk.toString(); });
    child.stderr.on('data', (chunk) => { stderr += chunk.toString(); });
    child.on('error', reject);
    child.on('close', (code) => {
      if (code === 0) return resolve({ stdout, stderr });
      reject(new Error(`${bin} exited with code ${code}: ${stderr.trim().slice(-2000)}`));
    });
  });
}

async function ffprobeJson(filePath) {
  const { stdout } = await run('ffprobe', [
    '-v', 'error',
    '-show_streams',
    '-show_format',
    '-of', 'json',
    filePath,
  ]);
  return JSON.parse(stdout);
}

export async function probeVideo(filePath) {
  const d = await ffprobeJson(filePath);
  const video = (d.streams || []).find((s) => s.codec_type === 'video');
  const audio = (d.streams || []).find((s) => s.codec_type === 'audio');
  const duration = Number(d.format?.duration || video?.duration || 0);
  if (!video || !Number.isFinite(duration) || duration <= 0) {
    throw new Error('ملف الفيديو الناتج غير صالح أو لا يحتوي على مدة قابلة للقراءة.');
  }
  return {
    duration,
    width: Number(video.width || 0),
    height: Number(video.height || 0),
    hasAudio: Boolean(audio),
    videoCodec: video.codec_name || '',
    audioCodec: audio?.codec_name || '',
  };
}

function targetSize(aspectRatio) {
  if (aspectRatio === '9:16') return { width: 720, height: 1280 };
  if (aspectRatio === '1:1') return { width: 1080, height: 1080 };
  return { width: 1280, height: 720 };
}

export async function extractLastFrame(videoPath, outPath) {
  const info = await probeVideo(videoPath);
  const timestamp = Math.max(0, info.duration - 0.08);
  await run('ffmpeg', [
    '-y', '-ss', String(timestamp), '-i', videoPath,
    '-frames:v', '1',
    '-vf', 'scale=1280:-2:force_original_aspect_ratio=decrease',
    '-q:v', '3', outPath,
  ]);
  const stat = await fs.stat(outPath);
  if (stat.size < 500) throw new Error('تعذر استخراج آخر إطار من الفيديو.');
  return outPath;
}

async function normalizeSegment(input, output, aspectRatio) {
  const info = await probeVideo(input);
  const { width, height } = targetSize(aspectRatio);
  const vf = `scale=${width}:${height}:force_original_aspect_ratio=decrease,pad=${width}:${height}:(ow-iw)/2:(oh-ih)/2:color=black,fps=24,format=yuv420p`;
  if (info.hasAudio) {
    await run('ffmpeg', [
      '-y', '-i', input,
      '-vf', vf,
      '-c:v', 'libx264', '-preset', 'veryfast', '-crf', '20', '-pix_fmt', 'yuv420p',
      '-c:a', 'aac', '-ar', '48000', '-ac', '2', '-b:a', '160k',
      '-movflags', '+faststart', output,
    ]);
  } else {
    await run('ffmpeg', [
      '-y', '-i', input,
      '-f', 'lavfi', '-i', 'anullsrc=r=48000:cl=stereo',
      '-vf', vf,
      '-map', '0:v:0', '-map', '1:a:0',
      '-c:v', 'libx264', '-preset', 'veryfast', '-crf', '20', '-pix_fmt', 'yuv420p',
      '-c:a', 'aac', '-ar', '48000', '-ac', '2', '-b:a', '160k',
      '-shortest', '-t', String(info.duration),
      '-movflags', '+faststart', output,
    ]);
  }
  return probeVideo(output);
}

function buildCrossfadeFilter(count, durations) {
  const parts = [];
  for (let i = 0; i < count; i++) {
    parts.push(`[${i}:v]setpts=PTS-STARTPTS[v${i}]`);
    parts.push(`[${i}:a]aresample=async=1:first_pts=0[a${i}]`);
  }
  let currentVideo = 'v0';
  let currentAudio = 'a0';
  let elapsed = durations[0];
  for (let i = 1; i < count; i++) {
    const offset = Math.max(0, elapsed - CROSSFADE_SECONDS);
    const nextVideo = `vx${i}`;
    const nextAudio = `ax${i}`;
    parts.push(`[${currentVideo}][v${i}]xfade=transition=fade:duration=${CROSSFADE_SECONDS}:offset=${offset.toFixed(3)}[${nextVideo}]`);
    parts.push(`[${currentAudio}][a${i}]acrossfade=d=${CROSSFADE_SECONDS}:c1=tri:c2=tri[${nextAudio}]`);
    currentVideo = nextVideo;
    currentAudio = nextAudio;
    elapsed += durations[i] - CROSSFADE_SECONDS;
  }
  return { filter: parts.join(';'), video: currentVideo, audio: currentAudio };
}

async function mergeWithCrossfade(files, output) {
  const infos = await Promise.all(files.map(probeVideo));
  const durations = infos.map((x) => x.duration);
  const { filter, video, audio } = buildCrossfadeFilter(files.length, durations);
  const args = ['-y'];
  for (const file of files) args.push('-i', file);
  args.push(
    '-filter_complex', filter,
    '-map', `[${video}]`, '-map', `[${audio}]`,
    '-c:v', 'libx264', '-preset', 'veryfast', '-crf', '20',
    '-c:a', 'aac', '-b:a', '160k', '-ar', '48000', '-ac', '2',
    '-movflags', '+faststart', output,
  );
  await run('ffmpeg', args);
  return probeVideo(output);
}

async function mergeByConcat(files, output) {
  const listPath = `${output}.txt`;
  const lines = files.map((file) => `file '${path.resolve(file).replaceAll("'", "'\\''")}'`).join('\n');
  await fs.writeFile(listPath, `${lines}\n`, 'utf8');
  try {
    await run('ffmpeg', [
      '-y', '-f', 'concat', '-safe', '0', '-i', listPath,
      '-c', 'copy', '-movflags', '+faststart', output,
    ]);
    return probeVideo(output);
  } finally {
    await fs.rm(listPath, { force: true });
  }
}

export async function mergeVideoSegments(files, output, aspectRatio = '16:9') {
  if (!files.length) throw new Error('لا توجد مقاطع فيديو لدمجها.');
  if (files.length === 1) {
    await fs.copyFile(files[0], output);
    return probeVideo(output);
  }

  const normalizedDir = `${output}.parts`;
  await fs.mkdir(normalizedDir, { recursive: true });
  const normalized = [];
  try {
    for (let i = 0; i < files.length; i++) {
      const out = path.join(normalizedDir, `part-${String(i).padStart(3, '0')}.mp4`);
      await normalizeSegment(files[i], out, aspectRatio);
      normalized.push(out);
    }
    try {
      return await mergeWithCrossfade(normalized, output);
    } catch (crossfadeError) {
      await fs.rm(output, { force: true }).catch(() => {});
      return await mergeByConcat(normalized, output).catch((concatError) => {
        throw new Error(`تعذر دمج المقاطع. Crossfade: ${crossfadeError.message}; Concat: ${concatError.message}`);
      });
    }
  } finally {
    await fs.rm(normalizedDir, { recursive: true, force: true }).catch(() => {});
  }
}

export async function trimVideo(input, output, seconds) {
  const info = await probeVideo(input);
  if (!Number.isFinite(seconds) || seconds <= 0 || info.duration <= seconds + 0.05) {
    await fs.copyFile(input, output);
    return info;
  }
  await run('ffmpeg', [
    '-y', '-i', input,
    '-t', String(seconds),
    '-c:v', 'libx264', '-preset', 'veryfast', '-crf', '20',
    '-c:a', 'aac', '-b:a', '160k', '-ar', '48000', '-ac', '2',
    '-movflags', '+faststart', output,
  ]);
  return probeVideo(output);
}
