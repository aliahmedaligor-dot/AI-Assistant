import 'dart:convert';
import 'dart:io';
import 'dart:math' as math;

import 'package:dio/dio.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter_tts/flutter_tts.dart';
import 'package:gal/gal.dart';
import 'package:http/http.dart' as http;
import 'package:image_picker/image_picker.dart';
import 'package:path_provider/path_provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:speech_to_text/speech_to_text.dart' as stt;
import 'package:url_launcher/url_launcher.dart';

void main() => runApp(const AiApp());

ThemeData appTheme(Brightness b) => ThemeData(
      useMaterial3: true,
      brightness: b,
      colorScheme: ColorScheme.fromSeed(
        seedColor: const Color(0xFF7C4DFF),
        brightness: b,
      ),
      scaffoldBackgroundColor:
          b == Brightness.dark ? const Color(0xFF090A10) : const Color(0xFFF8F7FC),
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: b == Brightness.dark ? const Color(0xFF141620) : Colors.white,
        contentPadding: const EdgeInsets.symmetric(horizontal: 18, vertical: 15),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(22),
          borderSide: BorderSide.none,
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(22),
          borderSide: BorderSide.none,
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(22),
          borderSide: BorderSide(color: Color(0xFF7C4DFF), width: 1.2),
        ),
      ),
      cardTheme: CardThemeData(
        elevation: 0,
        margin: EdgeInsets.zero,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
      ),
      appBarTheme: AppBarTheme(
        centerTitle: false,
        surfaceTintColor: Colors.transparent,
        titleSpacing: 4,
      ),
    );

class AiApp extends StatelessWidget {
  const AiApp({super.key});

  @override
  Widget build(BuildContext context) => MaterialApp(
        debugShowCheckedModeBanner: false,
        title: 'AI Assistant',
        theme: appTheme(Brightness.light),
        darkTheme: appTheme(Brightness.dark),
        themeMode: ThemeMode.system,
        home: const ChatPage(),
      );
}

class Msg {
  final String text;
  final bool user;
  final String? file;
  final String? image;
  final List<String> sources;

  Msg(this.text, this.user, {this.file, this.image, this.sources = const []});

  Map<String, dynamic> toJson() => {
        'text': text,
        'user': user,
        'file': file,
        'image': image,
        'sources': sources,
      };

  factory Msg.fromJson(Map<String, dynamic> x) => Msg(
        '${x['text'] ?? ''}',
        x['user'] == true,
        file: x['file']?.toString(),
        image: x['image']?.toString(),
        sources: (x['sources'] as List? ?? const []).map((e) => '$e').toList(),
      );
}

class ChatSession {
  final String id;
  String title;
  final List<Msg> messages;

  ChatSession({required this.id, required this.title, List<Msg>? messages})
      : messages = messages ?? <Msg>[];

  Map<String, dynamic> toJson() => {
        'id': id,
        'title': title,
        'messages': messages.map((m) => m.toJson()).toList(),
      };

  factory ChatSession.fromJson(Map<String, dynamic> x) => ChatSession(
        id: '${x['id']}',
        title: '${x['title'] ?? 'محادثة جديدة'}',
        messages: (x['messages'] as List? ?? const [])
            .map((e) => Msg.fromJson(Map<String, dynamic>.from(e as Map)))
            .toList(),
      );
}

class Reply {
  final String text;
  final List<String> sources;
  Reply(this.text, this.sources);
}

class MathEngine {
  static String? solve(String raw) {
    var s = raw
        .replaceAll('×', '*')
        .replaceAll('÷', '/')
        .replaceAll('−', '-')
        .replaceAll('٫', '.')
        .replaceAll('٬', '')
        .replaceAll(RegExp(r'\s+'), '');
    if (!RegExp(r'^[0-9+\-*/^().]+$').hasMatch(s) ||
        !RegExp(r'[+\-*/]').hasMatch(s)) return null;
    try {
      final value = _eval(_rpn(_tokens(s)));
      final exact = value.d == 1 ? '${value.n}' : '${value.n}/${value.d}';
      final decimal = _decimal(value);
      return 'الناتج الدقيق: $exact\nالناتج العشري: $decimal\n\n'
          'خطوات الحل:\n'
          '1) أطبّق الأقواس أولًا إن وُجدت.\n'
          '2) أطبّق الضرب والقسمة من اليسار إلى اليمين.\n'
          '3) أطبّق الجمع والطرح من اليسار إلى اليمين.\n'
          '4) أراجع الحساب باستخدام الكسور بدل التقريب المبكر.';
    } catch (_) {
      return null;
    }
  }

  static String _decimal(_R x) {
    final v = x.n / x.d;
    if (!v.isFinite) return 'غير معرّف';
    final s = v.toStringAsFixed(12);
    return s.replaceFirst(RegExp(r'0+$'), '').replaceFirst(RegExp(r'\.$'), '');
  }

  static List<String> _tokens(String s) {
    final out = <String>[];
    var i = 0;
    while (i < s.length) {
      final c = s[i];
      if ('+-*/^()'.contains(c)) {
        if (c == '-' && (out.isEmpty || '+-*/^('.contains(out.last))) out.add('0');
        out.add(c);
        i++;
        continue;
      }
      var j = i;
      var dots = 0;
      while (j < s.length && RegExp(r'[0-9.]').hasMatch(s[j])) {
        if (s[j] == '.') dots++;
        if (dots > 1) throw const FormatException();
        j++;
      }
      if (j == i) throw const FormatException();
      out.add(s.substring(i, j));
      i = j;
    }
    return out;
  }

  static List<String> _rpn(List<String> tokens) {
    const priority = {'+': 1, '-': 1, '*': 2, '/': 2, '^': 3};
    final output = <String>[];
    final ops = <String>[];
    for (final token in tokens) {
      if (double.tryParse(token) != null) {
        output.add(token);
      } else if (priority.containsKey(token)) {
        while (ops.isNotEmpty &&
            priority.containsKey(ops.last) &&
            priority[ops.last]! > priority[token]! || (priority[ops.last] == priority[token] && token != '^')) {
          output.add(ops.removeLast());
        }
        ops.add(token);
      } else if (token == '(') {
        ops.add(token);
      } else if (token == ')') {
        while (ops.isNotEmpty && ops.last != '(') output.add(ops.removeLast());
        if (ops.isEmpty) throw const FormatException();
        ops.removeLast();
      } else {
        throw const FormatException();
      }
    }
    while (ops.isNotEmpty) {
      if (ops.last == '(') throw const FormatException();
      output.add(ops.removeLast());
    }
    return output;
  }

  static _R _pow(_R a, _R b) {
    if (b.d != 1 || b.n.abs() > 1000) throw const FormatException();
    final e = b.n;
    if (e == 0) return _R(1, 1);
    if (e > 0) return _R(math.pow(a.n, e).toInt(), math.pow(a.d, e).toInt()).norm();
    if (a.n == 0) throw const FormatException();
    final k = -e;
    return _R(math.pow(a.d, k).toInt(), math.pow(a.n, k).toInt()).norm();
  }

  static _R _eval(List<String> rpn) {
    final stack = <_R>[];
    for (final token in rpn) {
      final n = double.tryParse(token);
      if (n != null) {
        stack.add(_R.fromString(token));
      } else {
        if (stack.length < 2) throw const FormatException();
        final b = stack.removeLast();
        final a = stack.removeLast();
        stack.add(switch (token) {
          '+' => a + b,
          '-' => a - b,
          '*' => a * b,
          '/' => a / b,
          '^' => _pow(a, b),
          _ => throw const FormatException(),
        });
      }
    }
    if (stack.length != 1) throw const FormatException();
    return stack.single;
  }
}

class _R {
  final int n;
  final int d;
  _R(this.n, this.d);

  factory _R.fromString(String s) {
    if (!s.contains('.')) return _R(int.parse(s), 1);
    final p = s.split('.');
    final den = math.pow(10, p[1].length).toInt();
    final num = int.parse(p[0]) * den + int.parse(p[1]);
    return _R(num, den).norm();
  }

  _R norm() {
    var a = n.abs();
    var b = d.abs();
    while (b != 0) {
      final t = a % b;
      a = b;
      b = t;
    }
    final g = a == 0 ? 1 : a;
    final nn = n ~/ g;
    final dd = d ~/ g;
    return dd < 0 ? _R(-nn, -dd) : _R(nn, dd);
  }

  _R operator +(_R x) => _R(n * x.d + x.n * d, d * x.d).norm();
  _R operator -(_R x) => _R(n * x.d - x.n * d, d * x.d).norm();
  _R operator *(_R x) => _R(n * x.n, d * x.d).norm();
  _R operator /(_R x) {
    if (x.n == 0) throw const FormatException();
    return _R(n * x.d, d * x.n).norm();
  }
}


String prettyMath(String text) {
  // Gemini/Groq may return LaTeX such as $\\angle ABC=60^\\circ$.
  // This app is intentionally text-first, so convert common LaTeX notation
  // to readable Unicode instead of exposing raw dollar signs to the user.
  final pattern = RegExp(r'\$\$([\s\S]*?)\$\$|\$([^$\n]+)\$');
  var out = text.replaceAllMapped(pattern, (m) {
    final value = m.group(1) ?? m.group(2) ?? '';
    return _prettyMathChunk(value);
  });

  // Also clean up a few common un-delimited snippets.
  out = out
      .replaceAll(r'\circ', '°')
      .replaceAll(r'\degree', '°')
      .replaceAll(r'\angle', '∠')
      .replaceAll(r'\triangle', '△')
      .replaceAll(r'\parallel', '∥')
      .replaceAll(r'\perp', '⊥')
      .replaceAll(r'\times', '×')
      .replaceAll(r'\cdot', '·')
      .replaceAll(r'\div', '÷')
      .replaceAll(r'\pm', '±')
      .replaceAll(r'\leq', '≤')
      .replaceAll(r'\geq', '≥')
      .replaceAll(r'\neq', '≠')
      .replaceAll(r'\pi', 'π')
      .replaceAll(r'\theta', 'θ')
      .replaceAll(r'\alpha', 'α')
      .replaceAll(r'\beta', 'β')
      .replaceAll(r'\gamma', 'γ')
      .replaceAll(r'\Delta', 'Δ')
      .replaceAll(r'\sum', 'Σ')
      .replaceAll(r'\infty', '∞');
  return out;
}

String _prettyMathChunk(String value) {
  var s = value.trim();
  s = s
      .replaceAll(r'\left', '')
      .replaceAll(r'\right', '')
      .replaceAll(r'\angle', '∠')
      .replaceAll(r'\triangle', '△')
      .replaceAll(r'\parallel', '∥')
      .replaceAll(r'\perp', '⊥')
      .replaceAll(r'\circ', '°')
      .replaceAll(r'\degree', '°')
      .replaceAll(r'\times', '×')
      .replaceAll(r'\cdot', '·')
      .replaceAll(r'\div', '÷')
      .replaceAll(r'\pm', '±')
      .replaceAll(r'\leq', '≤')
      .replaceAll(r'\geq', '≥')
      .replaceAll(r'\neq', '≠')
      .replaceAll(r'\pi', 'π')
      .replaceAll(r'\theta', 'θ')
      .replaceAll(r'\alpha', 'α')
      .replaceAll(r'\beta', 'β')
      .replaceAll(r'\gamma', 'γ')
      .replaceAll(r'\Delta', 'Δ')
      .replaceAll(r'\sum', 'Σ')
      .replaceAll(r'\infty', '∞');

  // Convert common fractions such as \frac{a}{b} to readable text.
  final frac = RegExp(r'\\frac\{([^{}]+)\}\{([^{}]+)\}');
  while (frac.hasMatch(s)) {
    s = s.replaceAllMapped(frac, (m) => '(${m.group(1)})/(${m.group(2)})');
  }
  s = s.replaceAll(RegExp(r'\\text\{([^{}]*)\}'), r'$1');
  s = s.replaceAll(r'^{2}', '²').replaceAll('^2', '²');
  s = s.replaceAll(r'^{3}', '³').replaceAll('^3', '³');
  s = s.replaceAll(r'^\circ', '°').replaceAll(r'^\degree', '°');
  s = s.replaceAll(RegExp(r'\_\{([^{}]+)\}'), r'_($1)');
  s = s.replaceAll('{', '').replaceAll('}', '');
  return s;
}

class Api {
  String? gemini;
  String? groq;
  String? backend;
  final http.Client httpClient = http.Client();
  final Dio dio = Dio(BaseOptions(connectTimeout: const Duration(seconds: 20), receiveTimeout: const Duration(seconds: 120)));

  Future<Reply> ask(String q, List<Msg> history, bool web, String? file) async {
    if (file == null) {
      final math = MathEngine.solve(q);
      if (math != null) return Reply(math, const []);
    }
    if ((backend ?? '').isNotEmpty) return _backend(q, history, web, file);
    if ((gemini ?? '').isNotEmpty) return _gemini(q, history, web, file);
    if ((groq ?? '').isNotEmpty) return _groq(q, history);
    throw Exception('أضف مفتاح Gemini أو Groq أو رابط Backend من الإعدادات.');
  }

  Future<Reply> _backend(String q, List<Msg> history, bool web, String? file) async {
    final request = http.MultipartRequest(
      'POST',
      Uri.parse('${backend!.replaceAll(RegExp(r'/$'), '')}/chat'),
    );
    request.fields['message'] = q;
    request.fields['web_search'] = '$web';
    request.fields['history'] = jsonEncode(history
        .take(18)
        .map((m) => {'role': m.user ? 'user' : 'assistant', 'text': m.text})
        .toList());
    if (file != null) request.files.add(await http.MultipartFile.fromPath('file', file));
    final response = await request.send().timeout(const Duration(seconds: 120));
    final raw = await response.stream.bytesToString();
    final data = jsonDecode(raw);
    if (response.statusCode < 200 || response.statusCode > 299) {
      throw Exception(data['error'] ?? 'Backend error');
    }
    return Reply(
      '${data['reply'] ?? ''}',
      (data['sources'] as List? ?? const []).map((e) => '$e').where(_isUrl).toList(),
    );
  }

  Future<Reply> _gemini(String q, List<Msg> history, bool web, String? file) async {
    final contents = <Map<String, dynamic>>[];
    for (final m in history.take(18)) {
      contents.add({'role': m.user ? 'user' : 'model', 'parts': [{'text': m.text}]});
    }
    final parts = <Map<String, dynamic>>[{'text': q}];
    if (file != null) {
      final bytes = await File(file).readAsBytes();
      if (bytes.length > 18 * 1024 * 1024) throw Exception('الملف أكبر من 18MB.');
      parts.add({'inline_data': {'mime_type': _mime(file), 'data': base64Encode(bytes)}});
    }
    contents.add({'role': 'user', 'parts': parts});
    final body = <String, dynamic>{
      'systemInstruction': {'parts': [{'text': _system}]},
      'contents': contents,
      'generationConfig': {'temperature': 0.15},
    };
    if (web) body['tools'] = [{'google_search': {}}];
    final uri = Uri.parse(
      'https://generativelanguage.googleapis.com/v1beta/models/gemini-3.8-flash:generateContent?key=${Uri.encodeComponent(gemini!)}',
    );
    final response = await httpClient
        .post(uri, headers: {'Content-Type': 'application/json'}, body: jsonEncode(body))
        .timeout(const Duration(seconds: 120));
    final data = jsonDecode(response.body);
    if (response.statusCode < 200 || response.statusCode > 299) {
      throw Exception(data['error']?['message'] ?? 'Gemini error');
    }
    final candidates = data['candidates'] as List? ?? const [];
    final partsOut = candidates.isEmpty
        ? const []
        : (candidates.first['content']?['parts'] as List? ?? const []);
    final text = partsOut.map((e) => e['text'] ?? '').join();
    return Reply(text.isEmpty ? 'لم تصل إجابة.' : text, _urls(data));
  }

  Future<Reply> _groq(String q, List<Msg> history) async {
    final messages = <Map<String, String>>[
      {'role': 'system', 'content': _system},
      ...history.take(18).map((m) => {
            'role': m.user ? 'user' : 'assistant',
            'content': m.text,
          }),
      {'role': 'user', 'content': q},
    ];
    final response = await httpClient.post(
      Uri.parse('https://api.groq.com/openai/v1/chat/completions'),
      headers: {'Authorization': 'Bearer $groq', 'Content-Type': 'application/json'},
      body: jsonEncode({'model': 'llama-3.3-70b-versatile', 'messages': messages, 'temperature': .15}),
    );
    final data = jsonDecode(response.body);
    if (response.statusCode < 200 || response.statusCode > 299) {
      throw Exception(data['error']?['message'] ?? 'Groq error');
    }
    return Reply('${data['choices']?[0]?['message']?['content'] ?? ''}', const []);
  }

  Future<String> generateImage(String prompt) async {
    final clean = prompt.trim();
    if (clean.isEmpty) throw Exception('اكتب وصفًا للصورة أولًا.');
    final seed = math.Random().nextInt(999999999);
    final url = 'https://image.pollinations.ai/prompt/${Uri.encodeComponent(clean)}'
        '?width=1024&height=1024&nologo=true&enhance=true&seed=$seed';
    final directory = await getApplicationDocumentsDirectory();
    final path = '${directory.path}/ai_image_${DateTime.now().millisecondsSinceEpoch}.jpg';
    await dio.download(url, path, options: Options(responseType: ResponseType.bytes));
    return path;
  }

  static String _mime(String path) {
    final p = path.toLowerCase();
    if (p.endsWith('.pdf')) return 'application/pdf';
    if (p.endsWith('.png')) return 'image/png';
    if (p.endsWith('.webp')) return 'image/webp';
    if (p.endsWith('.gif')) return 'image/gif';
    if (p.endsWith('.txt')) return 'text/plain';
    if (p.endsWith('.csv')) return 'text/csv';
    if (p.endsWith('.json')) return 'application/json';
    if (p.endsWith('.html') || p.endsWith('.htm')) return 'text/html';
    return 'image/jpeg';
  }

  static bool _isUrl(String value) => value.startsWith('https://') || value.startsWith('http://');

  static List<String> _urls(dynamic root) {
    final found = <String>{};
    void walk(dynamic value) {
      if (value is Map) {
        for (final entry in value.entries) {
          if (entry.value is String && _isUrl(entry.value as String)) found.add(entry.value as String);
          walk(entry.value);
        }
      } else if (value is List) {
        for (final item in value) walk(item);
      }
    }
    walk(root);
    return found.take(16).toList();
  }

  static const _system = '''
أنت AI Assistant عربي متقدم جدًا، هدفك تقديم إجابات دقيقة وعملية ومفهومة.
- افهم السؤال كاملًا قبل الإجابة، وتتبع السياق والمعلومات التي ذكرها المستخدم سابقًا في نفس المحادثة.
- أجب بلغة المستخدم، والعربية هي الافتراضية، ولا تغيّر معنى السؤال لمجرد تبسيطه.
- الرياضيات: تعامل معها كآلة حاسبة دقيقة لا كمسألة تخمين. طبّق ترتيب العمليات، الأقواس، الإشارات، والكسور، وراجع الناتج قبل عرضه. عند المسائل الهندسية استخدم رموزًا طبيعية واضحة مثل ∠ABC و60° و△ABC وπ و√ و× و÷. ممنوع عرض LaTeX بين $...$ أو $$...$$، وممنوع وضع $ حول الأرقام أو المعادلات. إذا كانت المسألة معقدة، اعرض خطوات الحساب الفعلية لا كلامًا عامًا.
- إذا كانت المسألة رقمية بحتة، افحصها حسابيًا أولًا قبل إعطاء شرح لغوي. إذا كان هناك أكثر من تفسير، اذكر الافتراض بدل اختراع معلومة.
- الهندسة: ميّز بين الزاوية، القوس، المثلث، الضلع، المحيط، المساحة، التشابه، التطابق، والدائرة، واستخدم الوحدات والدرجات ° بشكل صحيح.
- المنطق والاستدلال: تتبع الحالة الزمنية والمكانية لكل جسم. لا تفترض أن جسمًا فوق جسم انتقل معه عندما نُقل الجسم السفلي، إلا إذا نص السؤال على ذلك. اشرح سلسلة الاستنتاج باختصار واضح.
- البحث والروابط: عندما يكون Web Search متاحًا أو يطلب المستخدم معلومات حديثة/رابطًا، استخدم البحث. أعطِ روابط حقيقية قابلة للفتح فقط، ولا تخترع روابط. عند طلب تطبيق، ابحث عن صفحة Google Play الرسمية إن وجدت؛ وعند طلب خدمة أو شركة، أعطِ الموقع الرسمي. يمكن استخدام Google وGoogle Play والمواقع الرسمية والمصادر الموثوقة حسب السؤال.
- عند البحث، لا تكتفِ بذكر اسم المصدر: اعرض الروابط التي أعادها البحث عندما تكون مفيدة، وميّز بين المصدر الرسمي والمصدر الإخباري/التوثيقي.
- الملفات والصور: حلل المرفق فعليًا، واستخرج الجداول والنصوص والأرقام والأخطاء المهمة قدر الإمكان. إذا كان الملف كبيرًا أو جزء منه غير قابل للقراءة، اذكر ذلك بدل التخمين.
- البرمجة: أعطِ حلولًا قابلة للتطبيق، وانتبه للنسخ والتوافق والأخطاء الشائعة.
- كن صريحًا بشأن حدود الأدوات أو المعلومات. لا تدّعِ تنفيذ عملية لم تنفذها.
- لا تكرر السؤال بلا داعٍ. إذا كانت المهمة واضحة، نفذها مباشرة.
''';
}

class ChatPage extends StatefulWidget {
  const ChatPage({super.key});
  @override
  State<ChatPage> createState() => _ChatPageState();
}

class _ChatPageState extends State<ChatPage> {
  final api = Api();
  final input = TextEditingController();
  final scroll = ScrollController();
  final picker = ImagePicker();
  final speech = stt.SpeechToText();
  final tts = FlutterTts();
  final sessions = <ChatSession>[];

  int active = 0;
  bool busy = false;
  bool web = true; // Web search is ON by default.
  bool listening = false;
  String heard = '';
  String? file;

  ChatSession get chat => sessions[active];

  @override
  void initState() {
    super.initState();
    _load();
    tts.setLanguage('ar');
    tts.setSpeechRate(.48);
    tts.setVolume(1.0);
  }

  @override
  void dispose() {
    input.dispose();
    scroll.dispose();
    tts.stop();
    super.dispose();
  }

  Future<void> _load() async {
    final prefs = await SharedPreferences.getInstance();
    api.gemini = prefs.getString('gemini');
    api.groq = prefs.getString('groq');
    api.backend = prefs.getString('backend');
    web = prefs.getBool('web_search') ?? true;
    final raw = prefs.getString('chats');
    if (raw != null) {
      try {
        sessions.addAll((jsonDecode(raw) as List).map((e) => ChatSession.fromJson(Map<String, dynamic>.from(e))));
      } catch (_) {}
    }
    if (sessions.isEmpty) _newChat(save: false);
    if (mounted) setState(() {});
  }

  Future<void> _save() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('chats', jsonEncode(sessions.map((c) => c.toJson()).toList()));
    await prefs.setBool('web_search', web);
  }

  void _newChat({bool save = true}) {
    final id = DateTime.now().microsecondsSinceEpoch.toString();
    sessions.insert(0, ChatSession(id: id, title: 'محادثة جديدة'));
    active = 0;
    input.clear();
    file = null;
    if (save) _save();
    if (mounted) setState(() {});
  }

  void _selectChat(int index) {
    setState(() {
      active = index;
      input.clear();
      file = null;
    });
    Navigator.of(context).pop();
    _jump();
  }

  Future<void> _deleteChat(int index) async {
    if (sessions.length == 1) {
      sessions[0].title = 'محادثة جديدة';
      sessions[0].messages.clear();
      active = 0;
    } else {
      sessions.removeAt(index);
      if (active >= sessions.length) active = sessions.length - 1;
    }
    await _save();
    if (mounted) setState(() {});
  }

  void _jump() => WidgetsBinding.instance.addPostFrameCallback((_) {
        if (scroll.hasClients) {
          scroll.animateTo(
            scroll.position.maxScrollExtent,
            duration: const Duration(milliseconds: 250),
            curve: Curves.easeOut,
          );
        }
      });

  Future<void> send([String? preset]) async {
    if (busy) return;
    final q = (preset ?? input.text).trim();
    if (q.isEmpty && file == null) return;
    final attached = file;
    input.clear();
    file = null;
    final userText = q.isEmpty ? 'حلل الملف المرفق.' : q;
    final before = List<Msg>.from(chat.messages);
    setState(() {
      chat.messages.add(Msg(userText, true, file: attached));
      if (chat.title == 'محادثة جديدة') {
        chat.title = userText.replaceAll(RegExp(r'\s+'), ' ').trim();
        if (chat.title.length > 34) chat.title = '${chat.title.substring(0, 34)}…';
      }
      busy = true;
    });
    _jump();
    try {
      final reply = await api.ask(userText, before, web, attached);
      if (!mounted) return;
      setState(() => chat.messages.add(Msg(reply.text, false, sources: reply.sources)));
    } catch (e) {
      if (!mounted) return;
      setState(() => chat.messages.add(Msg('حدث خطأ: ${e.toString().replaceFirst('Exception: ', '')}', false)));
    } finally {
      if (mounted) setState(() => busy = false);
      await _save();
      _jump();
    }
  }

  Future<void> voice() async {
    if (listening) {
      await speech.stop();
      if (mounted) setState(() => listening = false);
      final text = heard.trim();
      heard = '';
      if (text.isNotEmpty) await send(text);
      return;
    }
    final available = await speech.initialize(
      onStatus: (status) {
        if (mounted && status == 'notListening') setState(() => listening = false);
      },
      onError: (error) {
        if (mounted) {
          setState(() => listening = false);
          ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('تعذر تشغيل الصوت: ${error.errorMsg}')));
        }
      },
    );
    if (!available) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('خدمة التعرف على الكلام غير متاحة على هذا الجهاز.')));
      return;
    }
    final locales = await speech.locales();
    final arabic = locales.where((x) => x.localeId.toLowerCase().startsWith('ar')).toList();
    if (mounted) setState(() => listening = true);
    await speech.listen(
      localeId: arabic.isEmpty ? null : arabic.first.localeId,
      listenOptions: const stt.SpeechListenOptions(
        partialResults: true,
        autoPunctuation: true,
        listenMode: stt.ListenMode.dictation,
      ),
      onResult: (result) {
        if (mounted) setState(() => heard = result.recognizedWords);
      },
    );
  }

  Future<void> pickFile() async {
    final result = await FilePicker.pickFile(type: FileType.any, withData: false);
    if (result?.path != null) setState(() => file = result!.path);
  }

  Future<void> pickImage(ImageSource source) async {
    final result = await picker.pickImage(source: source, imageQuality: 90, maxWidth: 2200);
    if (result != null) setState(() => file = result.path);
  }

  Future<void> draw() async {
    final controller = TextEditingController();
    final prompt = await showDialog<String>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('🎨 إنشاء صورة'),
        content: TextField(
          controller: controller,
          autofocus: true,
          maxLines: 5,
          decoration: const InputDecoration(hintText: 'صف الصورة بالتفصيل…'),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(dialogContext), child: const Text('إلغاء')),
          FilledButton(onPressed: () => Navigator.pop(dialogContext, controller.text.trim()), child: const Text('إنشاء')),
        ],
      ),
    );
    controller.dispose();
    if (prompt == null || prompt.isEmpty || busy) return;
    setState(() => busy = true);
    try {
      final path = await api.generateImage(prompt);
      final bytes = await File(path).readAsBytes();
      await Gal.putImageBytes(bytes, album: 'AI Assistant');
      chat.messages.add(Msg('تم إنشاء الصورة وحفظها في الاستوديو 🎨\n\nالوصف: $prompt', false, image: path));
    } catch (e) {
      chat.messages.add(Msg('تعذر إنشاء الصورة الآن: ${e.toString().replaceFirst('Exception: ', '')}', false));
    } finally {
      if (mounted) setState(() => busy = false);
      await _save();
      _jump();
    }
  }

  Future<void> settings() async {
    final gemini = TextEditingController(text: api.gemini ?? '');
    final groq = TextEditingController(text: api.groq ?? '');
    final backend = TextEditingController(text: api.backend ?? '');
    await showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      builder: (sheetContext) => Padding(
        padding: EdgeInsets.only(bottom: MediaQuery.of(sheetContext).viewInsets.bottom),
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(20),
          child: Column(
            children: [
              const Text('الإعدادات', style: TextStyle(fontSize: 26, fontWeight: FontWeight.w900)),
              const SizedBox(height: 6),
              const Text('البحث على الويب مفعّل تلقائيًا عند تشغيل التطبيق.'),
              TextField(controller: gemini, obscureText: true, decoration: const InputDecoration(labelText: 'Gemini API Key')),
              const SizedBox(height: 10),
              TextField(controller: groq, obscureText: true, decoration: const InputDecoration(labelText: 'Groq API Key')),
              const SizedBox(height: 10),
              TextField(controller: backend, decoration: const InputDecoration(labelText: 'Backend URL')),
              const SizedBox(height: 14),
              FilledButton.icon(
                onPressed: () async {
                  api.gemini = gemini.text.trim();
                  api.groq = groq.text.trim();
                  api.backend = backend.text.trim();
                  final prefs = await SharedPreferences.getInstance();
                  await prefs.setString('gemini', api.gemini ?? '');
                  await prefs.setString('groq', api.groq ?? '');
                  await prefs.setString('backend', api.backend ?? '');
                  if (sheetContext.mounted) Navigator.pop(sheetContext);
                  if (mounted) setState(() {});
                },
                icon: const Icon(Icons.save_outlined),
                label: const Text('حفظ الإعدادات'),
              ),
            ],
          ),
        ),
      ),
    );
    gemini.dispose();
    groq.dispose();
    backend.dispose();
  }

  Future<void> speak(String text) async {
    await tts.stop();
    await tts.speak(prettyMath(text));
  }

  void toggleWeb() async {
    setState(() => web = !web);
    await _save();
  }

  @override
  Widget build(BuildContext context) => Directionality(
        textDirection: TextDirection.rtl,
        child: Scaffold(
          drawer: _drawer(),
          appBar: AppBar(
            elevation: 0,
            scrolledUnderElevation: 0,
            backgroundColor: Theme.of(context).scaffoldBackgroundColor.withValues(alpha: .92),
            leading: Builder(builder: (c) => IconButton(onPressed: () => Scaffold.of(c).openDrawer(), icon: const Icon(Icons.menu_rounded))),
            title: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('AI Assistant', style: TextStyle(fontWeight: FontWeight.w900)),
                Text(chat.title, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 11)),
              ],
            ),
            actions: [
              IconButton(onPressed: toggleWeb, tooltip: 'البحث', icon: Icon(web ? Icons.travel_explore : Icons.language)),
              IconButton(onPressed: draw, tooltip: 'إنشاء صورة', icon: const Icon(Icons.image_outlined)),
              IconButton(onPressed: settings, tooltip: 'الإعدادات', icon: const Icon(Icons.tune_rounded)),
            ],
          ),
          body: Column(
            children: [
              if (web)
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
                  color: Theme.of(context).colorScheme.primaryContainer,
                  child: const Row(children: [Icon(Icons.public, size: 17), SizedBox(width: 7), Expanded(child: Text('البحث والروابط مفعّلة تلقائيًا — يمكن للمساعد إحضار مصادر من الويب.'))]),
                ),
              Expanded(
                child: chat.messages.isEmpty
                    ? _home()
                    : ListView.builder(
                        controller: scroll,
                        padding: const EdgeInsets.fromLTRB(12, 12, 12, 18),
                        itemCount: chat.messages.length + (busy ? 1 : 0),
                        itemBuilder: (context, i) => i < chat.messages.length
                            ? _bubble(chat.messages[i])
                            : _bubble(Msg('أفكر…', false)),
                      ),
              ),
              _composer(),
            ],
          ),
        ),
      );

  Widget _drawer() => Drawer(
        child: SafeArea(
          child: Column(
            children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(12, 10, 12, 8),
                child: Row(
                  children: [
                    Container(
                      width: 44,
                      height: 44,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(14),
                        gradient: const LinearGradient(colors: [Color(0xFF7C4DFF), Color(0xFF00BCD4)]),
                      ),
                      child: const Icon(Icons.auto_awesome, color: Colors.white),
                    ),
                    const SizedBox(width: 10),
                    const Expanded(child: Text('محادثاتك', style: TextStyle(fontSize: 21, fontWeight: FontWeight.w900))),
                    IconButton(onPressed: () { _newChat(); Navigator.of(context).pop(); }, icon: const Icon(Icons.edit_square)),
                  ],
                ),
              ),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 12),
                child: FilledButton.icon(
                  onPressed: () { _newChat(); Navigator.of(context).pop(); },
                  style: FilledButton.styleFrom(minimumSize: const Size(double.infinity, 48)),
                  icon: const Icon(Icons.add_rounded),
                  label: const Text('محادثة جديدة'),
                ),
              ),
              const SizedBox(height: 12),
              const Divider(height: 1),
              Expanded(
                child: ListView.builder(
                  itemCount: sessions.length,
                  itemBuilder: (context, i) {
                    final selected = i == active;
                    return ListTile(
                      selected: selected,
                      leading: Icon(selected ? Icons.chat_bubble : Icons.chat_bubble_outline),
                      title: Text(sessions[i].title, maxLines: 2, overflow: TextOverflow.ellipsis),
                      onTap: () => _selectChat(i),
                      trailing: PopupMenuButton<String>(
                        onSelected: (v) {
                          if (v == 'delete') _deleteChat(i);
                        },
                        itemBuilder: (_) => const [PopupMenuItem(value: 'delete', child: Text('حذف المحادثة'))],
                      ),
                    );
                  },
                ),
              ),
              const Divider(height: 1),
              ListTile(leading: const Icon(Icons.tune), title: const Text('الإعدادات'), onTap: settings),
            ],
          ),
        ),
      );

  Widget _home() => ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Container(
            padding: const EdgeInsets.all(26),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(32),
              gradient: LinearGradient(
                colors: [
                  Theme.of(context).colorScheme.primaryContainer,
                  Theme.of(context).colorScheme.surfaceContainerHighest,
                ],
              ),
            ),
            child: const Column(
              children: [
                Icon(Icons.auto_awesome, size: 58),
                SizedBox(height: 12),
                Text('مساعدك الذكي', style: TextStyle(fontSize: 30, fontWeight: FontWeight.w900)),
                SizedBox(height: 8),
                Text('رياضيات • بحث وروابط • صوت • ملفات • صور • محادثات متعددة', textAlign: TextAlign.center),
              ],
            ),
          ),
          const SizedBox(height: 18),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: [
              ActionChip(label: const Text('🧮 اختبار رياضيات'), onPressed: () => send('4747+4847-3747÷3737×3737+373÷3737')),
              ActionChip(label: const Text('🧠 اختبار استدلال'), onPressed: () => send('أنا في غرفتي الآن. وضعت كتاباً على الطاولة، ثم وضعت فوق الكتاب تفاحة حمراء، وفوق التفاحة وضعت كوباً فارغاً. بعد ذلك، قمت بنقل الكتاب بعناية ووضعته داخل الخزانة، ثم أخذت الكوب الفارغ ووضعته في المطبخ. أين توجد التفاحة الحمراء الآن؟ اشرح لي خطوة بخطوة كيف توصلت لمكانها.')),
              ActionChip(label: const Text('🎨 صمّم صورة'), onPressed: draw),
              ActionChip(label: const Text('🌐 ابحث عن رابط'), onPressed: () {
                setState(() => web = true);
                input.text = 'ابحث لي عن الرابط الرسمي المناسب لهذا الشيء واذكر مصادر موثوقة.';
              }),
              ActionChip(label: const Text('📎 حلل ملف'), onPressed: pickFile),
            ],
          ),
        ],
      );

  Widget _bubble(Msg message) {
    final scheme = Theme.of(context).colorScheme;
    return Align(
      alignment: message.user ? Alignment.centerRight : Alignment.centerLeft,
      child: Container(
        margin: const EdgeInsets.symmetric(vertical: 5),
        padding: const EdgeInsets.all(14),
        constraints: const BoxConstraints(maxWidth: 520),
        decoration: BoxDecoration(
          gradient: message.user
              ? const LinearGradient(begin: Alignment.topRight, end: Alignment.bottomLeft, colors: [Color(0xFF7C4DFF), Color(0xFF5E35B1)])
              : null,
          color: message.user ? null : scheme.surfaceContainerHighest,
          borderRadius: BorderRadius.circular(24),
          border: message.user ? null : Border.all(color: scheme.outlineVariant.withValues(alpha: .35)),
          boxShadow: [BoxShadow(blurRadius: 18, spreadRadius: -10, color: Colors.black.withValues(alpha: .30))],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            if (message.file != null) ...[
              Row(children: [
                Icon(Icons.attach_file, size: 17, color: message.user ? scheme.onPrimary : scheme.primary),
                const SizedBox(width: 5),
                Expanded(child: Text(File(message.file!).uri.pathSegments.last, overflow: TextOverflow.ellipsis)),
              ]),
              const SizedBox(height: 6),
            ],
            if (message.image != null)
              Padding(
                padding: const EdgeInsets.only(bottom: 9),
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(17),
                  child: Image.file(File(message.image!), height: 290, width: 390, fit: BoxFit.cover),
                ),
              ),
            if (!message.user)
              Padding(
                padding: const EdgeInsets.only(bottom: 6),
                child: Row(
                  children: [
                    Icon(Icons.auto_awesome, size: 16, color: scheme.primary),
                    const SizedBox(width: 5),
                    Text('AI Assistant', style: TextStyle(fontSize: 12, fontWeight: FontWeight.w800, color: scheme.primary)),
                  ],
                ),
              ),
            SelectableText(
              prettyMath(message.text),
              style: TextStyle(fontSize: 16, height: 1.52, color: message.user ? scheme.onPrimary : null),
            ),
            if (!message.user && message.sources.isNotEmpty) ...[
              const SizedBox(height: 10),
              Text('🔗 المصادر والروابط', style: TextStyle(fontWeight: FontWeight.w800, color: scheme.primary)),
              const SizedBox(height: 4),
              ...message.sources.map((url) => InkWell(
                    onTap: () async {
                      final uri = Uri.tryParse(url);
                      if (uri != null) await launchUrl(uri, mode: LaunchMode.externalApplication);
                    },
                    child: Padding(
                      padding: const EdgeInsets.symmetric(vertical: 4),
                      child: Text(
                        url,
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(color: scheme.primary, decoration: TextDecoration.underline),
                      ),
                    ),
                  )),
            ],
            if (!message.user)
              Row(
                children: [
                  IconButton(onPressed: () => speak(message.text), tooltip: 'استماع', icon: const Icon(Icons.volume_up_outlined)),
                  IconButton(
                    onPressed: () async {
                      await tts.stop();
                      if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('تم إيقاف الصوت.')));
                    },
                    tooltip: 'إيقاف الصوت',
                    icon: const Icon(Icons.stop_circle_outlined),
                  ),
                ],
              ),
          ],
        ),
      ),
    );
  }

  Widget _composer() => SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(8, 5, 8, 9),
          child: Column(
            children: [
              if (listening || heard.isNotEmpty)
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.all(10),
                  margin: const EdgeInsets.only(bottom: 6),
                  decoration: BoxDecoration(
                    color: Theme.of(context).colorScheme.primaryContainer,
                    borderRadius: BorderRadius.circular(16),
                  ),
                  child: Text('🎙️ $heard'),
                ),
              if (file != null)
                Container(
                  margin: const EdgeInsets.only(bottom: 5),
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                  decoration: BoxDecoration(
                    color: Theme.of(context).colorScheme.surfaceContainerHighest,
                    borderRadius: BorderRadius.circular(16),
                  ),
                  child: Row(children: [
                    const Icon(Icons.attach_file),
                    Expanded(child: Text(File(file!).uri.pathSegments.last, overflow: TextOverflow.ellipsis)),
                    IconButton(onPressed: () => setState(() => file = null), icon: const Icon(Icons.close)),
                  ]),
                ),
              Row(
                children: [
                  PopupMenuButton<String>(
                    onSelected: (value) {
                      switch (value) {
                        case 'file':
                          pickFile();
                        case 'image':
                          pickImage(ImageSource.gallery);
                        case 'camera':
                          pickImage(ImageSource.camera);
                        case 'draw':
                          draw();
                      }
                    },
                    itemBuilder: (_) => const [
                      PopupMenuItem(value: 'file', child: Text('📎 تحليل ملف')),
                      PopupMenuItem(value: 'image', child: Text('🖼️ تحليل صورة')),
                      PopupMenuItem(value: 'camera', child: Text('📷 تصوير وتحليل')),
                      PopupMenuItem(value: 'draw', child: Text('🎨 إنشاء صورة')),
                    ],
                    child: const Padding(padding: EdgeInsets.all(10), child: Icon(Icons.add_circle_outline)),
                  ),
                  Expanded(
                    child: TextField(
                      controller: input,
                      minLines: 1,
                      maxLines: 5,
                      onSubmitted: (_) => send(),
                      decoration: const InputDecoration(hintText: 'اسألني أي شيء…'),
                    ),
                  ),
                  IconButton(
                    onPressed: voice,
                    tooltip: listening ? 'إرسال الكلام' : 'تحدث',
                    icon: Icon(listening ? Icons.stop_circle : Icons.mic_none, color: listening ? Colors.red : null),
                  ),
                  IconButton.filled(
                    onPressed: busy ? null : () => send(),
                    tooltip: 'إرسال',
                    icon: const Icon(Icons.arrow_upward_rounded),
                  ),
                ],
              ),
            ],
          ),
        ),
      );
}
