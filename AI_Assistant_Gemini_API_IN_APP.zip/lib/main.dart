
import 'dart:convert';
import 'dart:math' as math;
import 'dart:typed_data';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_tts/flutter_tts.dart';
import 'package:http/http.dart' as http;
import 'package:image_picker/image_picker.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:speech_to_text/speech_to_text.dart' as stt;
import 'package:url_launcher/url_launcher.dart';

const violet=Color(0xFF7C5CFC), cyan=Color(0xFF21D4FD), ink=Color(0xFF0B1020);

class ChatMessage{
  final String role,text; final String? imageData; final List<String> sources;
  ChatMessage(this.role,this.text,{this.imageData,this.sources=const []});
  Map<String,dynamic> toJson()=>{'role':role,'text':text,'imageData':imageData,'sources':sources};
  factory ChatMessage.fromJson(Map<String,dynamic> j)=>ChatMessage(j['role']??'assistant',j['text']??'',imageData:j['imageData'],sources:List<String>.from(j['sources']??const []));
}
class AiReply{final String text;final List<String> sources;AiReply(this.text,{this.sources=const []});}

class ApiClient{
  String geminiKey='',groqKey='',backendUrl='';
  String geminiModel='gemini-3.8-flash',groqModel='llama-3.3-70b-versatile';

  Future<AiReply> ask({required String prompt,required List<ChatMessage> history,bool web=false,String? base64,String mime='image/jpeg',String deviceContext=''}) async{
    final p=deviceContext.isEmpty?prompt:'$prompt\n\n[معلومات الجهاز]\n$deviceContext';
    if(backendUrl.trim().isNotEmpty){
      try{
        final r=await http.post(Uri.parse('${backendUrl.trim().replaceAll(RegExp(r'/$'), '')}/chat'),headers:{'Content-Type':'application/json'},body:jsonEncode({'message':p,'webSearch':web,'imageBase64':base64,'mimeType':mime,'history':history.take(16).map((m)=>{'role':m.role,'text':m.text}).toList()})).timeout(const Duration(seconds:90));
        if(r.statusCode>=200&&r.statusCode<300){final j=jsonDecode(r.body);return AiReply(j['text']??j['reply']??'',sources:List<String>.from(j['sources']??const []));}
      }catch(_){}
    }
    if(geminiKey.trim().isNotEmpty){try{return await _gemini(p,history,web,base64,mime);}catch(_){}} 
    if(groqKey.trim().isNotEmpty&&base64==null)return _groq(p,history);
    throw Exception('لا يوجد اتصال AI صالح. ضع Gemini API Key أو Groq API Key أو رابط Backend.');
  }

  Future<AiReply> _gemini(String prompt,List<ChatMessage> history,bool web,String? b64,String mime) async{
    final contents=<Map<String,dynamic>>[];
    for(final m in history.take(16)){contents.add({'role':m.role=='assistant'?'model':'user','parts':[{'text':m.text}]});}
    final parts=<Map<String,dynamic>>[{'text':prompt}];
    if(b64!=null)parts.add({'inline_data':{'mime_type':mime,'data':b64}});
    contents.add({'role':'user','parts':parts});
    final body=<String,dynamic>{
      'systemInstruction':{'parts':[{'text':"أنت AI Assistant عربي متقدم. أجب بلغة المستخدم بدقة. حل الرياضيات خطوة بخطوة وتحقق من النتيجة. عند سؤال المستخدم عن هاتفه استخدم معلومات الجهاز المرسلة فقط. عند تفعيل البحث استخدم المصادر الحديثة وقدّم روابط واضحة. لا تخترع حقائق أو روابط. يمكنك تحليل الصور والملفات والوسائط."}]},
      'contents':contents,'generationConfig':{'temperature':0.35,'maxOutputTokens':4096}
    };
    if(web)body['tools']=[{'google_search':{}}];
    final r=await http.post(Uri.parse('https://generativelanguage.googleapis.com/v1beta/models/$geminiModel:generateContent'),headers:{'Content-Type':'application/json','x-goog-api-key':geminiKey.trim()},body:jsonEncode(body)).timeout(const Duration(seconds:100));
    if(r.statusCode<200||r.statusCode>=300)throw Exception('Gemini ${r.statusCode}');
    final j=jsonDecode(r.body);
    final out=j['candidates']?[0]?['content']?['parts'] as List? ?? const [];
    final text=out.whereType<Map>().map((p)=>p['text']).whereType<String>().join('\n').trim();
    if(text.isEmpty)throw Exception('Gemini returned empty text');
    final urls=<String>{};
    void walk(dynamic x){if(x is Map){final u=x['url'];if(u is String&&u.startsWith('http'))urls.add(u);x.values.forEach(walk);}else if(x is List)x.forEach(walk);}
    walk(j); return AiReply(text,sources:urls.take(12).toList());
  }

  Future<AiReply> _groq(String prompt,List<ChatMessage> history) async{
    final msgs=<Map<String,String>>[{'role':'system','content':'أنت مساعد عربي دقيق. حل الرياضيات خطوة بخطوة ولا تخترع روابط.'}];
    for(final m in history.take(16)){msgs.add({'role':m.role=='assistant'?'assistant':'user','content':m.text});}
    msgs.add({'role':'user','content':prompt});
    final r=await http.post(Uri.parse('https://api.groq.com/openai/v1/chat/completions'),headers:{'Content-Type':'application/json','Authorization':'Bearer ${groqKey.trim()}'},body:jsonEncode({'model':groqModel,'messages':msgs,'temperature':0.35,'max_completion_tokens':4096})).timeout(const Duration(seconds:70));
    if(r.statusCode<200||r.statusCode>=300)throw Exception('Groq ${r.statusCode}');
    final j=jsonDecode(r.body);final text=j['choices']?[0]?['message']?['content'];
    if(text is! String||text.trim().isEmpty)throw Exception('Groq empty response');return AiReply(text.trim());
  }

  Future<String?> generateImage(String prompt) async{
    if(geminiKey.trim().isEmpty)throw Exception('ضع Gemini API Key أولاً.');
    final body={'contents':[{'parts':[{'text':prompt}]}],'generationConfig':{'responseModalities':['TEXT','IMAGE'],'imageConfig':{'imageSize':'2K','aspectRatio':'1:1'}}};
    final r=await http.post(Uri.parse('https://generativelanguage.googleapis.com/v1beta/models/gemini-3.1-flash-image:generateContent'),headers:{'Content-Type':'application/json','x-goog-api-key':geminiKey.trim()},body:jsonEncode(body)).timeout(const Duration(seconds:120));
    if(r.statusCode<200||r.statusCode>=300)throw Exception('Image API ${r.statusCode}');
    final j=jsonDecode(r.body);final parts=j['candidates']?[0]?['content']?['parts'] as List? ?? const [];
    for(final p in parts){if(p is Map&&p['inlineData']?['data'] is String)return p['inlineData']['data'];if(p is Map&&p['inline_data']?['data'] is String)return p['inline_data']['data'];}
    throw Exception('لم تصل صورة من Gemini.');
  }
}

void main()=>runApp(const AiApp());
class AiApp extends StatefulWidget{const AiApp({super.key});@override State<AiApp> createState()=>_AiAppState();}
class _AiAppState extends State<AiApp>{
  ThemeMode mode=ThemeMode.dark;
  @override Widget build(BuildContext context)=>MaterialApp(debugShowCheckedModeBanner:false,title:'AI Assistant',themeMode:mode,theme:ThemeData(useMaterial3:true,colorSchemeSeed:violet,brightness:Brightness.light),darkTheme:ThemeData(useMaterial3:true,colorSchemeSeed:violet,brightness:Brightness.dark,scaffoldBackgroundColor:ink),home:ChatPage(client:ApiClient(),mode:mode,onMode:(m)=>setState(()=>mode=m)));
}

class ChatPage extends StatefulWidget{
  final ApiClient client;final ThemeMode mode;final ValueChanged<ThemeMode> onMode;
  const ChatPage({super.key,required this.client,required this.mode,required this.onMode});
  @override State<ChatPage> createState()=>_ChatPageState();
}
class _ChatPageState extends State<ChatPage>{
  final input=TextEditingController(),scroll=ScrollController(),speech=stt.SpeechToText(),tts=FlutterTts(),picker=ImagePicker(),messages=<ChatMessage>[];
  bool loading=false,web=false,listening=false;XFile? attachment;Uint8List? attachmentBytes;String attachmentMime='image/jpeg',deviceContext='';
  @override void initState(){super.initState();_load();_loadDevice();}
  @override void dispose(){input.dispose();scroll.dispose();tts.stop();super.dispose();}
  Future<void> _load()async{
    final p=await SharedPreferences.getInstance();
    final r=p.getStringList('chat_v2')??[];
    widget.client.geminiKey=p.getString('gemini')??'';
    widget.client.groqKey=p.getString('groq')??'';
    widget.client.backendUrl=p.getString('backend')??'';
    messages.addAll(r.map((e)=>ChatMessage.fromJson(jsonDecode(e))));
    if(mounted)setState((){});
  }
  Future<void> _save()async{final p=await SharedPreferences.getInstance();await p.setStringList('chat_v2',messages.take(100).map((e)=>jsonEncode(e.toJson())).toList());}
  Future<void> _loadDevice()async{try{final d=await DeviceInfoPlugin().androidInfo;deviceContext='الشركة: ${d.manufacturer}\nالموديل: ${d.model}\nAndroid: ${d.version.release}\nSDK: ${d.version.sdkInt}';if(mounted)setState((){});}catch(_){}}
  void _jump()=>Future.delayed(const Duration(milliseconds:80),(){if(scroll.hasClients)scroll.animateTo(scroll.position.maxScrollExtent,duration:const Duration(milliseconds:220),curve:Curves.easeOut);});
  void _toast(String s)=>ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(s),behavior:SnackBarBehavior.floating));

  Future<void> _send([String? preset])async{
    final q=(preset??input.text).trim();if(q.isEmpty&&attachmentBytes==null)return;input.clear();
    final text=q.isEmpty?'حلّل الملف المرفق.':q;final old=List<ChatMessage>.from(messages);
    setState((){messages.add(ChatMessage('user',text,imageData:attachmentBytes==null?null:base64Encode(attachmentBytes!)));loading=true;});_jump();
    try{
      final reply=await widget.client.ask(prompt:text,history:old,web:web,base64:attachmentBytes==null?null:base64Encode(attachmentBytes!),mime:attachmentMime,deviceContext:deviceContext);
      final idx=messages.length;messages.add(ChatMessage('assistant','',sources:reply.sources));
      final chars=reply.text.runes.toList(),step=math.max(1,(chars.length/180).ceil());
      for(int i=0;i<chars.length;i+=step){final end=math.min(chars.length,i+step);messages[idx]=ChatMessage('assistant',String.fromCharCodes(chars.sublist(0,end)),sources:reply.sources);if(mounted)setState((){});await Future.delayed(const Duration(milliseconds:18));_jump();}
      messages[idx]=ChatMessage('assistant',reply.text,sources:reply.sources);attachment=null;attachmentBytes=null;await _save();
    }catch(e){messages.add(ChatMessage('assistant','حدث خطأ: ${e.toString().replaceFirst('Exception: ','')}'));}finally{if(mounted)setState(()=>loading=false);_jump();}
  }

  Future<void> _pickImage({bool camera=false})async{final x=await picker.pickImage(source:camera?ImageSource.camera:ImageSource.gallery,maxWidth:1800,maxHeight:1800,imageQuality:82);if(x==null)return;final b=await x.readAsBytes();if(b.length>18*1024*1024){_toast('الصورة كبيرة جداً.');return;}setState((){attachment=x;attachmentBytes=b;attachmentMime='image/jpeg';});}
  Future<void> _pickFile()async{final f=await FilePicker.pickFile();if(f==null)return;final b=await f.readAsBytes();if(b.length>18*1024*1024){_toast('الملف أكبر من 18MB.');return;}final ext=(f.extension??'').toLowerCase();final map={'pdf':'application/pdf','txt':'text/plain','json':'application/json','csv':'text/csv','mp3':'audio/mpeg','wav':'audio/wav','m4a':'audio/mp4','mp4':'video/mp4','mov':'video/quicktime','webm':'video/webm'};setState((){attachment=null;attachmentBytes=b;attachmentMime=map[ext]??'application/octet-stream';});_toast('تم إرفاق ${f.name}');}
  Future<void> _mic()async{if(listening){await speech.stop();setState(()=>listening=false);return;}if(!await speech.initialize()){_toast('التعرف على الصوت غير متاح.');return;}setState(()=>listening=true);await speech.listen(onResult:(r){input.text=r.recognizedWords;input.selection=TextSelection.collapsed(offset:input.text.length);setState((){});},listenOptions:stt.SpeechListenOptions(partialResults:true,localeId:'ar-SA',pauseFor:const Duration(seconds:3),listenFor:const Duration(seconds:45)));}
  Future<void> _speak(String t)async{await tts.setLanguage('ar-SA');await tts.setSpeechRate(.48);await tts.speak(t);}

  Future<void> _settings()async{
    final g=TextEditingController(text:widget.client.geminiKey),q=TextEditingController(text:widget.client.groqKey),b=TextEditingController(text:widget.client.backendUrl);
    await showModalBottomSheet(context:context,isScrollControlled:true,builder:(c)=>Padding(padding:EdgeInsets.only(bottom:MediaQuery.of(c).viewInsets.bottom),child:SingleChildScrollView(padding:const EdgeInsets.all(22),child:Column(crossAxisAlignment:CrossAxisAlignment.stretch,children:[
      const Text('الإعدادات',style:TextStyle(fontSize:26,fontWeight:FontWeight.w900)),const SizedBox(height:8),
      const Text('للاختبار يمكن إدخال المفاتيح هنا. للنشر العام الأفضل استخدام Backend حتى لا تكون المفاتيح داخل APK.'),const SizedBox(height:16),
      TextField(controller:g,obscureText:true,decoration:const InputDecoration(labelText:'Gemini API Key',prefixIcon:Icon(Icons.auto_awesome))),const SizedBox(height:12),
      TextField(controller:q,obscureText:true,decoration:const InputDecoration(labelText:'Groq API Key — احتياطي',prefixIcon:Icon(Icons.bolt))),const SizedBox(height:12),
      TextField(controller:b,decoration:const InputDecoration(labelText:'Backend URL — اختياري',prefixIcon:Icon(Icons.cloud))),const SizedBox(height:16),
      FilledButton.icon(onPressed:()async{widget.client.geminiKey=g.text.trim();widget.client.groqKey=q.text.trim();widget.client.backendUrl=b.text.trim();final p=await SharedPreferences.getInstance();await p.setString('gemini',widget.client.geminiKey);await p.setString('groq',widget.client.groqKey);await p.setString('backend',widget.client.backendUrl);if(context.mounted)Navigator.pop(context);},icon:const Icon(Icons.save),label:const Text('حفظ')),
      const SizedBox(height:8),OutlinedButton.icon(onPressed:()=>widget.onMode(widget.mode==ThemeMode.dark?ThemeMode.light:ThemeMode.dark),icon:const Icon(Icons.brightness_6),label:const Text('تبديل المظهر'))
    ]))));
  }

  @override Widget build(BuildContext context){
    final cs=Theme.of(context).colorScheme;
    return Scaffold(appBar:AppBar(title:Row(children:[Container(width:40,height:40,decoration:BoxDecoration(gradient:const LinearGradient(colors:[violet,cyan]),borderRadius:BorderRadius.circular(13)),child:const Icon(Icons.auto_awesome,color:Colors.white)),const SizedBox(width:10),const Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text('AI Assistant',style:TextStyle(fontWeight:FontWeight.w900)),Text('Gemini • Groq • Web',style:TextStyle(fontSize:11))])]),actions:[IconButton(onPressed:()=>setState(()=>web=!web),icon:Icon(web?Icons.public:Icons.public_off,color:web?cyan:null)),IconButton(onPressed:_settings,icon:const Icon(Icons.tune_rounded))]),
      body:Column(children:[if(messages.isEmpty)_hero(cs),Expanded(child:ListView.builder(controller:scroll,padding:const EdgeInsets.fromLTRB(14,8,14,18),itemCount:messages.length,itemBuilder:(c,i)=>_bubble(messages[i]))),if(attachmentBytes!=null)_attachmentBar(),_composer(cs)]));
  }

  Widget _hero(ColorScheme cs) {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(18),
      child: Column(
        children: [
          const SizedBox(height: 18),
          Container(
            width: 92, height: 92,
            decoration: BoxDecoration(
              gradient: const LinearGradient(colors: [violet, cyan]),
              borderRadius: BorderRadius.circular(30),
            ),
            child: const Icon(Icons.auto_awesome, size: 48, color: Colors.white),
          ),
          const SizedBox(height: 18),
          const Text('مساعدك الذكي المتعدد',
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 30, fontWeight: FontWeight.w900)),
          const SizedBox(height: 8),
          Text('اسأل، ابحث، حل الرياضيات، حلّل صورة أو ملف، وتكلم بصوتك.',
              textAlign: TextAlign.center,
              style: TextStyle(color: cs.onSurfaceVariant, fontSize: 15)),
          const SizedBox(height: 24),
          Wrap(
            spacing: 10, runSpacing: 10,
            alignment: WrapAlignment.center,
            children: [
              ActionChip(label: const Text('🧮 حل رياضيات'),
                  onPressed: () => _send('حل هذه المسألة خطوة بخطوة: ')),
              ActionChip(label: const Text('🌐 بحث وروابط'),
                  onPressed: () => _send('ابحث في الويب عن أحدث المعلومات حول ')),
              ActionChip(label: const Text('📱 هاتفي'),
                  onPressed: () => _send('ما معلومات هاتفي وما الذي تعنيه؟')),
              ActionChip(label: const Text('💡 فكرة'),
                  onPressed: () => _send('اقترح لي فكرة مشروع ذكي')),
            ],
          ),
        ],
      ),
    );
  }

  Widget _bubble(ChatMessage m){
    final user=m.role=='user';
    return Align(alignment:user?Alignment.centerRight:Alignment.centerLeft,child:Container(constraints:const BoxConstraints(maxWidth:680),margin:const EdgeInsets.symmetric(vertical:6),padding:const EdgeInsets.all(15),decoration:BoxDecoration(color:user?Theme.of(context).colorScheme.primaryContainer:Theme.of(context).colorScheme.surfaceContainerHighest,borderRadius:BorderRadius.only(topLeft:const Radius.circular(22),topRight:const Radius.circular(22),bottomLeft:Radius.circular(user?22:5),bottomRight:Radius.circular(user?5:22))),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
      if(m.imageData!=null)Padding(padding:const EdgeInsets.only(bottom:10),child:ClipRRect(borderRadius:BorderRadius.circular(14),child:Image.memory(base64Decode(m.imageData!),height:160,width:220,fit:BoxFit.cover))),
      SelectableText(m.text,style:const TextStyle(fontSize:15.5,height:1.5)),
      if(!user&&m.text.isNotEmpty)Row(mainAxisSize:MainAxisSize.min,children:[IconButton(onPressed:()=>_speak(m.text),icon:const Icon(Icons.volume_up_outlined,size:20)),IconButton(onPressed:(){Clipboard.setData(ClipboardData(text:m.text));_toast('تم النسخ');},icon:const Icon(Icons.copy,size:19))]),
      if(m.sources.isNotEmpty)Column(crossAxisAlignment:CrossAxisAlignment.start,children:[const SizedBox(height:5),const Text('المصادر:',style:TextStyle(fontWeight:FontWeight.w800)),...m.sources.take(8).map((u)=>InkWell(
              onTap:()async{
                final uri=Uri.tryParse(u);
                if(uri!=null && !await launchUrl(uri,mode:LaunchMode.externalApplication)) _toast('تعذر فتح الرابط');
              },
              child:Padding(
                padding:const EdgeInsets.symmetric(vertical:2),
                child:Text(u,maxLines:2,overflow:TextOverflow.ellipsis,
                  style:const TextStyle(color:cyan,fontSize:12,decoration:TextDecoration.underline)),
              ),
            ))])
    ])));
  }

  Widget _attachmentBar()=>Container(margin:const EdgeInsets.symmetric(horizontal:12,vertical:5),padding:const EdgeInsets.symmetric(horizontal:12,vertical:9),decoration:BoxDecoration(color:Theme.of(context).colorScheme.surfaceContainerHighest,borderRadius:BorderRadius.circular(16)),child:Row(children:[const Icon(Icons.attach_file),const SizedBox(width:8),const Expanded(child:Text('وسائط جاهزة للتحليل')),IconButton(onPressed:()=>setState((){attachment=null;attachmentBytes=null;}),icon:const Icon(Icons.close))]));

  Widget _composer(ColorScheme cs) {
    return SafeArea(
      top: false,
      child: Padding(
        padding: const EdgeInsets.fromLTRB(10, 4, 10, 10),
        child: Column(
          children: [
            if (web)
              const Align(
                alignment: Alignment.centerRight,
                child: Text('بحث الويب مفعّل • المصادر ستظهر مع الإجابة',
                    style: TextStyle(color: cyan, fontSize: 11)),
              ),
            Container(
              decoration: BoxDecoration(
                color: cs.surfaceContainerHighest,
                borderRadius: BorderRadius.circular(26),
                border: Border.all(color: cs.outlineVariant),
              ),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  PopupMenuButton<String>(
                    icon: const Icon(Icons.add_circle_outline),
                    onSelected: (v) {
                      if (v == 'gallery') _pickImage();
                      if (v == 'camera') _pickImage(camera: true);
                      if (v == 'file') _pickFile();
                      if (v == 'image') _generateImage();
                    },
                    itemBuilder: (c) => const [
                      PopupMenuItem(value: 'gallery', child: Text('صورة من المعرض')),
                      PopupMenuItem(value: 'camera', child: Text('التقاط صورة')),
                      PopupMenuItem(value: 'file', child: Text('ملف / PDF / صوت / فيديو')),
                      PopupMenuItem(value: 'image', child: Text('توليد صورة بالذكاء الاصطناعي')),
                    ],
                  ),
                  Expanded(
                    child: TextField(
                      controller: input,
                      minLines: 1, maxLines: 5,
                      textDirection: TextDirection.rtl,
                      decoration: const InputDecoration(
                        hintText: 'اكتب سؤالك هنا…',
                        border: InputBorder.none,
                        contentPadding: EdgeInsets.symmetric(vertical: 15),
                      ),
                    ),
                  ),
                  IconButton(
                    onPressed: _mic,
                    icon: Icon(listening ? Icons.stop_circle : Icons.mic_none,
                        color: listening ? Colors.red : null),
                  ),
                  Padding(
                    padding: const EdgeInsets.only(right: 5, bottom: 5),
                    child: CircleAvatar(
                      radius: 22,
                      backgroundColor: cs.primary,
                      child: IconButton(
                        onPressed: loading ? null : () => _send(),
                        icon: loading
                            ? const SizedBox(
                                width: 18, height: 18,
                                child: CircularProgressIndicator(
                                  strokeWidth: 2, color: Colors.white))
                            : const Icon(Icons.arrow_upward, color: Colors.white),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _generateImage()async{final p=input.text.trim();if(p.isEmpty){_toast('اكتب وصف الصورة أولاً.');return;}input.clear();setState(()=>loading=true);try{final b64=await widget.client.generateImage(p);messages.add(ChatMessage('assistant','تم إنشاء الصورة المطلوبة.',imageData:b64));await _save();}catch(e){_toast(e.toString().replaceFirst('Exception: ',''));}finally{if(mounted)setState(()=>loading=false);}}
}
