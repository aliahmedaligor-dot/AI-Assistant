import 'dart:convert';
import 'dart:io';
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:image_picker/image_picker.dart';
import 'package:path_provider/path_provider.dart';
import 'package:record/record.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:video_player/video_player.dart';

void main() => runApp(const App());

class App extends StatefulWidget {
  const App({super.key});
  @override State<App> createState() => _AppState();
}

class _AppState extends State<App> {
  ThemeMode themeMode = ThemeMode.system;
  @override void initState() { super.initState(); _loadTheme(); }
  Future<void> _loadTheme() async {
    final p = await SharedPreferences.getInstance();
    final v = p.getString('theme') ?? 'system';
    if (mounted) setState(() => themeMode = v == 'dark' ? ThemeMode.dark : v == 'light' ? ThemeMode.light : ThemeMode.system);
  }
  Future<void> setTheme(String v) async {
    final p = await SharedPreferences.getInstance(); await p.setString('theme', v);
    if (mounted) setState(() => themeMode = v == 'dark' ? ThemeMode.dark : v == 'light' ? ThemeMode.light : ThemeMode.system);
  }
  @override
  Widget build(BuildContext c) {
    final cs = Theme.of(c).colorScheme;
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        backgroundColor: cs.surface,
        appBar: AppBar(
          elevation: 0,
          scrolledUnderElevation: 0,
          centerTitle: false,
          titleSpacing: 18,
          title: Row(
            children: [
              Container(
                width: 44,
                height: 44,
                decoration: BoxDecoration(
                  gradient: const LinearGradient(
                    begin: Alignment.topRight,
                    end: Alignment.bottomLeft,
                    colors: [Color(0xFF7C4DFF), Color(0xFF536DFE), Color(0xFF00B8D4)],
                  ),
                  borderRadius: BorderRadius.circular(15),
                  boxShadow: [
                    BoxShadow(color: cs.primary.withOpacity(.20), blurRadius: 16, offset: const Offset(0, 7)),
                  ],
                ),
                child: const Icon(Icons.auto_awesome_rounded, color: Colors.white, size: 24),
              ),
              const SizedBox(width: 11),
              const Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('AI Assistant', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 18, letterSpacing: -.3)),
                  SizedBox(height: 1),
                  Text('مساعدك الذكي', style: TextStyle(fontSize: 11, fontWeight: FontWeight.w500)),
                ],
              ),
            ],
          ),
          actions: [
            IconButton(tooltip: 'محادثة جديدة', onPressed: () async { if (msgs.isEmpty) return; setState(() => msgs = []); await save(); }, icon: const Icon(Icons.add_comment_outlined)),
            IconButton(tooltip: 'الإعدادات', onPressed: settings, icon: const Icon(Icons.tune_rounded)),
            const SizedBox(width: 7),
          ],
        ),
        body: Column(
          children: [
            if (videoMode) _modeBanner(c, Icons.movie_creation_outlined, 'وضع تصميم الفيديو', 'اكتب وصف الفيديو الذي تريد إنشاءه.', cs.secondaryContainer, cs.onSecondaryContainer, () => setState(() => videoMode = false)),
            if (imageMode) _modeBanner(c, Icons.auto_awesome, 'وضع تصميم الصور', 'اكتب وصف الصورة أو أرفق صورة لتعديلها.', cs.primaryContainer, cs.onPrimaryContainer, () => setState(() => imageMode = false)),
            Expanded(
              child: msgs.isEmpty
                  ? _home()
                  : ListView.builder(
                      controller: scroll,
                      keyboardDismissBehavior: ScrollViewKeyboardDismissBehavior.onDrag,
                      padding: const EdgeInsets.fromLTRB(15, 8, 15, 16),
                      itemCount: msgs.length + (loading ? 1 : 0),
                      itemBuilder: (cc, i) => i < msgs.length
                          ? _bubble(msgs[i])
                          : _bubble(Msg(imageMode ? 'يصمم الصورة الآن…' : videoMode ? 'يصمم الفيديو الآن…' : 'يكتب الآن…', false)),
                    ),
            ),
            _composer(),
          ],
        ),
      ),
    );
  }

  Widget _modeBanner(BuildContext c, IconData icon, String title, String subtitle, Color bg, Color fg, VoidCallback close) => Container(
    width: double.infinity,
    margin: const EdgeInsets.fromLTRB(12, 2, 12, 4),
    padding: const EdgeInsets.fromLTRB(12, 8, 14, 8),
    decoration: BoxDecoration(color: bg, borderRadius: BorderRadius.circular(17)),
    child: Row(children: [
      Icon(icon, color: fg),
      const SizedBox(width: 10),
      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(title, style: TextStyle(fontWeight: FontWeight.w800, color: fg)), Text(subtitle, style: TextStyle(fontSize: 11.5, color: fg.withOpacity(.82)))])),
      IconButton(onPressed: close, icon: Icon(Icons.close_rounded, color: fg), visualDensity: VisualDensity.compact),
    ]),
  );

  Widget _home() {
    final cs = Theme.of(context).colorScheme;
    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 12),
      children: [
        Container(
          padding: const EdgeInsets.fromLTRB(22, 28, 22, 24),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(30),
            gradient: LinearGradient(
              begin: Alignment.topRight,
              end: Alignment.bottomLeft,
              colors: [cs.primaryContainer, cs.surfaceContainerHighest],
            ),
            border: Border.all(color: cs.outlineVariant.withOpacity(.55)),
          ),
          child: Column(children: [
            Container(
              width: 82,
              height: 82,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: const LinearGradient(colors: [Color(0xFF7C4DFF), Color(0xFF00B8D4)]),
                boxShadow: [BoxShadow(color: cs.primary.withOpacity(.22), blurRadius: 24, spreadRadius: 2)],
              ),
              child: const Icon(Icons.auto_awesome_rounded, color: Colors.white, size: 39),
            ),
            const SizedBox(height: 18),
            const Text('مرحباً بك 👋', style: TextStyle(fontSize: 29, fontWeight: FontWeight.w900, letterSpacing: -.5)),
            const SizedBox(height: 7),
            Text('أنا مساعدك الذكي. اسألني، أرسل صورة، أو أنشئ صوراً وفيديوهات بالذكاء الاصطناعي.', textAlign: TextAlign.center, style: TextStyle(color: cs.onSurfaceVariant, fontSize: 14.5, height: 1.5)),
            const SizedBox(height: 17),
            Wrap(alignment: WrapAlignment.center, spacing: 7, runSpacing: 7, children: [
              _miniPill(Icons.flash_on_rounded, 'سريع'),
              _miniPill(Icons.language_rounded, 'متعدد اللغات'),
              _miniPill(Icons.image_rounded, 'صور'),
              _miniPill(Icons.calculate_rounded, 'رياضيات'),
            ]),
          ]),
        ),
        const SizedBox(height: 25),
        Row(children: [
          const Expanded(child: Text('ابدأ من هنا', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 18))),
          Text('أفكار سريعة', style: TextStyle(color: cs.onSurfaceVariant, fontSize: 12)),
        ]),
        const SizedBox(height: 12),
        GridView.count(
          crossAxisCount: 2,
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          mainAxisSpacing: 10,
          crossAxisSpacing: 10,
          childAspectRatio: 1.18,
          children: [
            _quickCard(Icons.auto_awesome_rounded, 'تصميم صورة', 'أنشئ صورة من وصفك', () => setState(() { imageMode = true; videoMode = false; input.text = ''; })),
            _quickCard(Icons.movie_creation_outlined, 'تصميم فيديو', 'حوّل فكرتك إلى فيديو', () => setState(() { videoMode = true; imageMode = false; input.text = ''; })),
            _quickCard(Icons.calculate_outlined, 'حل الرياضيات', 'حل دقيق وسريع', () => ask('حل المسألة التالية خطوة بخطوة: ')),
            _quickCard(Icons.photo_camera_outlined, 'من صورة', 'حلل أو اشرح صورة', chooseImage),
          ],
        ),
        const SizedBox(height: 16),
        Container(
          padding: const EdgeInsets.all(15),
          decoration: BoxDecoration(color: cs.surfaceContainerLow, borderRadius: BorderRadius.circular(20), border: Border.all(color: cs.outlineVariant.withOpacity(.5))),
          child: Row(children: [
            Icon(Icons.tips_and_updates_outlined, color: cs.primary), const SizedBox(width: 11),
            Expanded(child: Text('نصيحة: كلما كان وصفك أو سؤالك أوضح، حصلت على نتيجة أدق.', style: TextStyle(fontSize: 12.5, height: 1.4, color: cs.onSurfaceVariant))),
          ]),
        ),
      ],
    );
  }

  Widget _miniPill(IconData icon, String text) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
    decoration: BoxDecoration(color: Theme.of(context).colorScheme.surface.withOpacity(.62), borderRadius: BorderRadius.circular(30)),
    child: Row(mainAxisSize: MainAxisSize.min, children: [Icon(icon, size: 14, color: Theme.of(context).colorScheme.primary), const SizedBox(width: 5), Text(text, style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w700))]),
  );

  Widget _quickCard(IconData icon, String title, String subtitle, VoidCallback onTap) {
    final cs = Theme.of(context).colorScheme;
    return Material(
      color: cs.surfaceContainerLow,
      borderRadius: BorderRadius.circular(20),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(20),
        child: Container(
          padding: const EdgeInsets.all(15),
          decoration: BoxDecoration(borderRadius: BorderRadius.circular(20), border: Border.all(color: cs.outlineVariant.withOpacity(.55))),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Container(width: 39, height: 39, decoration: BoxDecoration(color: cs.primaryContainer, borderRadius: BorderRadius.circular(13)), child: Icon(icon, color: cs.primary, size: 21)),
            const Spacer(),
            Text(title, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 14)),
            const SizedBox(height: 3),
            Text(subtitle, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(color: cs.onSurfaceVariant, fontSize: 11)),
          ]),
        ),
      ),
    );
  }

  Widget _bubble(Msg m) {
    final cs = Theme.of(context).colorScheme;
    final isUser = m.user;
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.end,
        mainAxisAlignment: isUser ? MainAxisAlignment.start : MainAxisAlignment.end,
        children: [
          if (!isUser) Container(width: 31, height: 31, margin: const EdgeInsets.only(left: 7, bottom: 2), decoration: BoxDecoration(gradient: const LinearGradient(colors: [Color(0xFF7C4DFF), Color(0xFF00B8D4)]), shape: BoxShape.circle), child: const Icon(Icons.auto_awesome_rounded, size: 16, color: Colors.white)),
          Flexible(
            child: Container(
              constraints: const BoxConstraints(maxWidth: 620),
              padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 12),
              decoration: BoxDecoration(
                gradient: isUser ? LinearGradient(begin: Alignment.topRight, end: Alignment.bottomLeft, colors: [cs.primary, Color.alphaBlend(Colors.white.withOpacity(.10), cs.primary)]) : null,
                color: isUser ? null : cs.surfaceContainerHighest,
                borderRadius: BorderRadius.only(topLeft: const Radius.circular(21), topRight: const Radius.circular(21), bottomLeft: Radius.circular(isUser ? 21 : 6), bottomRight: Radius.circular(isUser ? 6 : 21)),
                border: isUser ? null : Border.all(color: cs.outlineVariant.withOpacity(.42)),
                boxShadow: [BoxShadow(color: Colors.black.withOpacity(.035), blurRadius: 8, offset: const Offset(0, 3))],
              ),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                if (m.imagePath != null && File(m.imagePath!).existsSync() && m.imagePath!.toLowerCase().endsWith('.mp4')) ClipRRect(borderRadius: BorderRadius.circular(13), child: VideoBubble(path: m.imagePath!)),
                if (m.imagePath != null && File(m.imagePath!).existsSync() && !m.imagePath!.toLowerCase().endsWith('.mp4')) ClipRRect(borderRadius: BorderRadius.circular(13), child: Image.file(File(m.imagePath!), height: 250, width: 300, fit: BoxFit.cover)),
                if (m.imagePath != null) const SizedBox(height: 7),
                if (m.text.isNotEmpty) SelectableText(m.text, style: TextStyle(color: isUser ? cs.onPrimary : cs.onSurface, fontSize: 15.5, height: 1.5)),
              ]),
            ),
          ),
        ],
      ),
    );
  }

  Widget _composer() {
    final cs = Theme.of(context).colorScheme;
    return SafeArea(
      child: Padding(
        padding: const EdgeInsets.fromLTRB(10, 5, 10, 10),
        child: Column(children: [
          if (pendingImage != null) Container(width: double.infinity, margin: const EdgeInsets.only(bottom: 7), padding: const EdgeInsets.all(7), decoration: BoxDecoration(color: cs.surfaceContainerHighest, borderRadius: BorderRadius.circular(16), border: Border.all(color: cs.outlineVariant.withOpacity(.5))), child: Row(children: [ClipRRect(borderRadius: BorderRadius.circular(11), child: Image.file(File(pendingImage!), width: 52, height: 52, fit: BoxFit.cover)), const SizedBox(width: 9), const Expanded(child: Text('الصورة جاهزة للتحليل', style: TextStyle(fontWeight: FontWeight.w700))), IconButton(onPressed: () => setState(() => pendingImage = null), icon: const Icon(Icons.close_rounded))])),
          Container(
            padding: const EdgeInsets.fromLTRB(5, 5, 5, 5),
            decoration: BoxDecoration(color: cs.surfaceContainerHighest, borderRadius: BorderRadius.circular(29), border: Border.all(color: cs.outlineVariant.withOpacity(.55)), boxShadow: [BoxShadow(color: Colors.black.withOpacity(.04), blurRadius: 14, offset: const Offset(0, 4))]),
            child: Row(crossAxisAlignment: CrossAxisAlignment.end, children: [
              PopupMenuButton<String>(
                onSelected: (v) { if (v == 'gallery') chooseImage(); if (v == 'camera') takePhoto(); if (v == 'image') setState(() { imageMode = true; videoMode = false; }); if (v == 'video') setState(() { videoMode = true; imageMode = false; }); },
                itemBuilder: (cc) => const [PopupMenuItem(value: 'gallery', child: ListTile(leading: Icon(Icons.photo_library_outlined), title: Text('اختيار صورة'))), PopupMenuItem(value: 'camera', child: ListTile(leading: Icon(Icons.camera_alt_outlined), title: Text('الكاميرا'))), PopupMenuItem(value: 'image', child: ListTile(leading: Icon(Icons.auto_awesome_rounded), title: Text('تصميم / تعديل صورة'))), PopupMenuItem(value: 'video', child: ListTile(leading: Icon(Icons.movie_creation_outlined), title: Text('تصميم فيديو'))],
                child: const Padding(padding: EdgeInsets.all(11), child: Icon(Icons.add_circle_outline_rounded, size: 27)),
              ),
              Expanded(child: TextField(controller: input, minLines: 1, maxLines: 5, textInputAction: TextInputAction.newline, decoration: InputDecoration(hintText: imageMode ? 'صف الصورة التي تريدها…' : videoMode ? 'صف الفيديو الذي تريد إنشاءه…' : recording ? 'جاري التسجيل…' : 'اكتب رسالتك هنا…', filled: false, contentPadding: const EdgeInsets.symmetric(horizontal: 8, vertical: 12), border: InputBorder.none))),
              IconButton(onPressed: toggleRecording, tooltip: recording ? 'إيقاف التسجيل' : 'تسجيل صوت', icon: Icon(recording ? Icons.stop_circle_rounded : Icons.mic_none_rounded, color: recording ? Colors.redAccent : cs.onSurfaceVariant)),
              const SizedBox(width: 2),
              SizedBox(width: 48, height: 48, child: IconButton.filled(onPressed: loading ? null : send, style: IconButton.styleFrom(backgroundColor: cs.primary, foregroundColor: cs.onPrimary), icon: const Icon(Icons.arrow_upward_rounded))),
            ]),
          ),
          const SizedBox(height: 5),
          Text('قد يخطئ الذكاء الاصطناعي، تحقق من المعلومات المهمة.', style: TextStyle(fontSize: 9.5, color: cs.onSurfaceVariant.withOpacity(.72))),
        ]),
      ),
    );
  }
}
