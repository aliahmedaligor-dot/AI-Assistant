import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:image_picker/image_picker.dart';
import 'package:path_provider/path_provider.dart';
import 'package:record/record.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:video_player/video_player.dart';

void main() => runApp(const App());

class App extends StatefulWidget {
  const App({super.key});
  @override State<App> createState() => _AppState();
}

class _AppState extends State<App> {
  ThemeMode themeMode = ThemeMode.system;
  @override void initState() { super.initState(); _loadTheme(); }
  Future<void> _loadTheme() async {
    final p = await SharedPreferences.getInstance();
    final v = p.getString('theme') ?? 'system';
    if (mounted) setState(() => themeMode = v == 'dark' ? ThemeMode.dark : v == 'light' ? ThemeMode.light : ThemeMode.system);
  }
  Future<void> setTheme(String v) async {
    final p = await SharedPreferences.getInstance(); await p.setString('theme', v);
    if (mounted) setState(() => themeMode = v == 'dark' ? ThemeMode.dark : v == 'light' ? ThemeMode.light : ThemeMode.system);
  }
  @override Widget build(BuildContext c) => MaterialApp(
    debugShowCheckedModeBanner: false, title: 'AI Assistant', themeMode: themeMode,
    theme: ThemeData(useMaterial3: true, colorSchemeSeed: const Color(0xFF6750A4), brightness: Brightness.light),
    darkTheme: ThemeData(useMaterial3: true, colorSchemeSeed: const Color(0xFF9B7BFF), brightness: Brightness.dark),
    home: ChatPage(onThemeChanged: setTheme, themeMode: themeMode),
  );
}

class VideoBubble extends StatefulWidget {
  final String path; const VideoBubble({super.key, required this.path});
  @override State<VideoBubble> createState() => _VideoBubbleState();
}
class _VideoBubbleState extends State<VideoBubble> {
  late final VideoPlayerController c;
  @override void initState() { super.initState(); c = VideoPlayerController.file(File(widget.path))..initialize().then((_) { if (mounted) setState(() {}); }); }
  @override void dispose() { c.dispose(); super.dispose(); }
  @override Widget build(BuildContext context) => c.value.isInitialized ? Column(children: [AspectRatio(aspectRatio: c.value.aspectRatio, child: VideoPlayer(c)), Row(mainAxisAlignment: MainAxisAlignment.center, children: [IconButton(onPressed: () { setState(() { c.value.isPlaying ? c.pause() : c.play(); }); }, icon: Icon(c.value.isPlaying ? Icons.pause : Icons.play_arrow)), IconButton(onPressed: () => c.seekTo(Duration.zero), icon: const Icon(Icons.replay))])]) : const SizedBox(width: 300, height: 220, child: Center(child: CircularProgressIndicator()));
}

class Msg {
  final String text; final bool user; final String? imagePath; final bool generated;
  Msg(this.text, this.user, {this.imagePath, this.generated = false});
  Map<String, dynamic> json() => {'text': text, 'user': user, 'imagePath': imagePath, 'generated': generated};
  factory Msg.from(Map<String, dynamic> x) => Msg(x['text'] ?? '', x['user'] == true, imagePath: x['imagePath'], generated: x['generated'] == true);
}

class ChatPage extends StatefulWidget {
  final Future<void> Function(String) onThemeChanged; final ThemeMode themeMode;
  const ChatPage({super.key, required this.onThemeChanged, required this.themeMode});
  @override State<ChatPage> createState() => _ChatPageState();
}

class _ChatPageState extends State<ChatPage> {
  final input = TextEditingController(), scroll = ScrollController(), recorder = AudioRecorder();
  final picker = ImagePicker();
  List<Msg> msgs = [];
  bool loading = false, recording = false, webSearch = false, imageMode = false, videoMode = false;
  String? pendingImage;
  String geminiKey = '', language = 'العربية', imageSize = '1K', aspectRatio = '1:1';

  static const model = 'gemini-3.6-flash';
  static const fallbackModel = 'gemini-3.5-flash-lite';
  static const imageModel = 'gemini-3.1-flash-image';
  static const videoModel = 'veo-3.1-fast-generate-preview';

  Future<http.Response> _postWithRetry(Uri uri, Map<String, String> headers, String body, {Duration timeout = const Duration(seconds: 25), int attempts = 2}) async {
    Object? lastError;
    for (var i = 0; i < attempts; i++) {
      try {
        final r = await http.post(uri, headers: headers, body: body).timeout(timeout);
        if (r.statusCode != 429 && r.statusCode != 503) return r;
        lastError = Exception('HTTP ${r.statusCode}: ${r.body}');
      } catch (e) {
        lastError = e;
      }
      if (i + 1 < attempts) await Future.delayed(Duration(seconds: 2 * (i + 1)));
    }
    throw lastError ?? Exception('فشل الاتصال بـ Gemini.');
  }

  Future<http.Response> _getWithRetry(Uri uri, Map<String, String> headers, {Duration timeout = const Duration(seconds: 20), int attempts = 2}) async {
    Object? lastError;
    for (var i = 0; i < attempts; i++) {
      try {
        final r = await http.get(uri, headers: headers).timeout(timeout);
        if (r.statusCode != 429 && r.statusCode != 503) return r;
        lastError = Exception('HTTP ${r.statusCode}: ${r.body}');
      } catch (e) {
        lastError = e;
      }
      if (i + 1 < attempts) await Future.delayed(Duration(seconds: 2 * (i + 1)));
    }
    throw lastError ?? Exception('فشل الاتصال بـ Gemini.');
  }

  final languages = const ['العربية', 'English', 'Français', 'Español', 'Deutsch', 'Türkçe', 'فارسی', 'اردو', '中文', '日本語', 'Русский', 'Italiano', 'Português', 'हिन्दी'];

  @override void initState() { super.initState(); load(); }
  @override void dispose() { input.dispose(); scroll.dispose(); recorder.dispose(); super.dispose(); }

  Future<void> load() async {
    final p = await SharedPreferences.getInstance(), s = p.getString('msgs');
    setState(() {
      if (s != null) msgs = (jsonDecode(s) as List).map((x) => Msg.from(x)).toList();
      geminiKey = p.getString('geminiKey') ?? '';
      language = p.getString('language') ?? 'العربية';
      imageSize = p.getString('imageSize') ?? '1K';
      aspectRatio = p.getString('aspectRatio') ?? '1:1';
    });
  }
  Future<void> save() async { final p = await SharedPreferences.getInstance(); await p.setString('msgs', jsonEncode(msgs.map((x) => x.json()).toList())); }
  void jump() => WidgetsBinding.instance.addPostFrameCallback((_) { if (scroll.hasClients) scroll.animateTo(scroll.position.maxScrollExtent, duration: const Duration(milliseconds: 280), curve: Curves.easeOut); });
  void ask(String s) { input.text = s; send(); }

  Future<void> chooseImage() async { final x = await picker.pickImage(source: ImageSource.gallery, imageQuality: 88, maxWidth: 1800); if (x != null) setState(() => pendingImage = x.path); }
  Future<void> takePhoto() async { final x = await picker.pickImage(source: ImageSource.camera, imageQuality: 88, maxWidth: 1800); if (x != null) setState(() => pendingImage = x.path); }
  Future<void> toggleRecording() async {
    if (recording) {
      final path = await recorder.stop();
      setState(() => recording = false);
      if (path != null) await transcribeAudio(path);
      return;
    }
    if (!await recorder.hasPermission()) { if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('يلزم السماح بالميكروفون للتسجيل الصوتي.'))); return; }
    final dir = await getApplicationDocumentsDirectory();
    final path = '${dir.path}/voice_${DateTime.now().millisecondsSinceEpoch}.m4a';
    await recorder.start(const RecordConfig(encoder: AudioEncoder.aacLc, sampleRate: 16000, numChannels: 1), path: path);
    setState(() => recording = true);
  }

  Future<void> transcribeAudio(String path) async {
    if (geminiKey.isEmpty) { await setGeminiKey(); if (geminiKey.isEmpty) return; }
    setState(() => loading = true);
    try {
      final bytes = await File(path).readAsBytes();
      final uri = Uri.parse('https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent');
      final prompt = 'حوّل التسجيل الصوتي إلى نص فقط، بدون شرح. اكتب النص كما نُطق، وباللغة الأصلية للتسجيل.';
      final r = await _postWithRetry(uri, {'Content-Type': 'application/json', 'x-goog-api-key': geminiKey}, jsonEncode({'contents': [{'parts': [{'text': prompt}, {'inline_data': {'mime_type': 'audio/mp4', 'data': base64Encode(bytes)}}]}]}));
      final d = jsonDecode(r.body);
      if (r.statusCode < 200 || r.statusCode >= 300) throw Exception(d['error']?['message'] ?? 'HTTP ${r.statusCode}');
      final text = d['candidates']?[0]?['content']?['parts']?[0]?['text']?.toString().trim() ?? '';
      if (text.isEmpty) throw Exception('لم يتم التعرف على الكلام.');
      input.text = text;
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('تم تحويل الصوت إلى نص. اضغط إرسال.')));
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('تعذر تحويل الصوت إلى نص.\n$e')));
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  Future<void> setGeminiKey() async {
    final c = TextEditingController(text: geminiKey);
    final v = await showDialog<String>(context: context, builder: (ctx) => AlertDialog(
      title: const Text('مفتاح Gemini API'),
      content: TextField(controller: c, obscureText: true, autofocus: true, decoration: const InputDecoration(hintText: 'ألصق مفتاح Gemini هنا', border: OutlineInputBorder())),
      actions: [TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('إلغاء')), FilledButton(onPressed: () => Navigator.pop(ctx, c.text.trim()), child: const Text('حفظ'))],
    ));
    if (v != null) { final p = await SharedPreferences.getInstance(); await p.setString('geminiKey', v); setState(() => geminiKey = v); }
  }

  Future<void> settings() async {
    await showModalBottomSheet<void>(context: context, isScrollControlled: true, showDragHandle: true, builder: (ctx) => StatefulBuilder(builder: (ctx, setSheet) => SafeArea(
      child: Padding(padding: const EdgeInsets.fromLTRB(18, 4, 18, 24), child: ListView(shrinkWrap: true, children: [
        const Text('الإعدادات', style: TextStyle(fontSize: 24, fontWeight: FontWeight.w800)),
        const SizedBox(height: 16),
        ListTile(leading: const Icon(Icons.key_outlined), title: const Text('مفتاح Gemini API'), subtitle: Text(geminiKey.isEmpty ? 'غير مضاف' : 'محفوظ على هذا الجهاز'), trailing: const Icon(Icons.chevron_left), onTap: setGeminiKey),
        ListTile(leading: const Icon(Icons.translate), title: const Text('لغة الردود'), subtitle: Text(language), trailing: DropdownButton<String>(value: language, underline: const SizedBox(), items: languages.map((x) => DropdownMenuItem(value: x, child: Text(x))).toList(), onChanged: (v) async { if (v == null) return; final p = await SharedPreferences.getInstance(); await p.setString('language', v); setState(() => language = v); setSheet(() {}); })),
        ListTile(leading: const Icon(Icons.palette_outlined), title: const Text('المظهر'), subtitle: Text(widget.themeMode == ThemeMode.dark ? 'داكن' : widget.themeMode == ThemeMode.light ? 'فاتح' : 'حسب النظام'), trailing: DropdownButton<String>(value: widget.themeMode == ThemeMode.dark ? 'dark' : widget.themeMode == ThemeMode.light ? 'light' : 'system', underline: const SizedBox(), items: const [DropdownMenuItem(value: 'system', child: Text('النظام')), DropdownMenuItem(value: 'light', child: Text('فاتح')), DropdownMenuItem(value: 'dark', child: Text('داكن'))], onChanged: (v) { if (v != null) widget.onThemeChanged(v); setSheet(() {}); })),
        const Divider(),
        const ListTile(title: Text('إعدادات الصور', style: TextStyle(fontWeight: FontWeight.w800))),
        ListTile(leading: const Icon(Icons.aspect_ratio), title: const Text('نسبة الصورة'), trailing: DropdownButton<String>(value: aspectRatio, underline: const SizedBox(), items: const ['1:1', '16:9', '9:16', '4:3', '3:4', '3:2', '2:3'].map((x) => DropdownMenuItem(value: x, child: Text(x))).toList(), onChanged: (v) async { if (v == null) return; final p = await SharedPreferences.getInstance(); await p.setString('aspectRatio', v); setState(() => aspectRatio = v); setSheet(() {}); })),
        ListTile(leading: const Icon(Icons.high_quality), title: const Text('جودة الصورة'), subtitle: const Text('الأعلى قد يستهلك حصصًا/تكلفة أكبر'), trailing: DropdownButton<String>(value: imageSize, underline: const SizedBox(), items: const ['1K', '2K', '4K'].map((x) => DropdownMenuItem(value: x, child: Text(x))).toList(), onChanged: (v) async { if (v == null) return; final p = await SharedPreferences.getInstance(); await p.setString('imageSize', v); setState(() => imageSize = v); setSheet(() {}); })),
        const Divider(),
        ListTile(leading: Icon(webSearch ? Icons.travel_explore : Icons.public), title: const Text('المعلومات الحديثة'), subtitle: const Text('تفعيل خيار البحث عند توفره'), trailing: Switch(value: webSearch, onChanged: (v) => setState(() => webSearch = v))),
        ListTile(leading: const Icon(Icons.delete_sweep_outlined), title: const Text('مسح المحادثة'), onTap: () async { setState(() => msgs = []); await save(); if (ctx.mounted) Navigator.pop(ctx); }),
        ListTile(leading: const Icon(Icons.info_outline), title: const Text('عن التطبيق'), subtitle: const Text('AI Assistant — Gemini multimodal assistant')),
      ]),
    ))));
  }

  Future<void> send() async {
    final q = input.text.trim();
    if ((q.isEmpty && pendingImage == null) || loading) return;
    if (geminiKey.isEmpty) { await setGeminiKey(); if (geminiKey.isEmpty) return; }
    if (imageMode) { await generateImage(q); return; }
    if (videoMode) { await generateVideo(q); return; }
    final image = pendingImage; input.clear(); setState(() { msgs.add(Msg(q.isEmpty ? 'حلل هذه الصورة' : q, true, imagePath: image)); pendingImage = null; loading = true; }); await save(); jump();
    try {
      final parts = <Map<String, dynamic>>[{'text': q.isEmpty ? 'حلل هذه الصورة' : q}];
      final contextText = msgs.where((m) => m.text.isNotEmpty).toList().reversed.take(10).toList().reversed.map((m) => '${m.user ? 'المستخدم' : 'المساعد'}: ${m.text}').join('\n');
      parts.insert(0, {'text': 'أنت مساعد ذكي متعدد اللغات. أجب بلغة "$language". كن واضحًا ومفيدًا، وحل الرياضيات بدقة. إذا أرسلت صورة فحللها. لا تدّعي أنك بحثت في الإنترنت إذا لم تستخدم أداة بحث. سياق المحادثة:\n$contextText'});
      if (image != null) { final bytes = await File(image).readAsBytes(); final ext = image.toLowerCase().endsWith('.png') ? 'image/png' : image.toLowerCase().endsWith('.webp') ? 'image/webp' : 'image/jpeg'; parts.add({'inline_data': {'mime_type': ext, 'data': base64Encode(bytes)}}); }
      final body = jsonEncode({'contents': [{'parts': parts}]});
      http.Response r;
      try {
        final uri = Uri.parse('https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent');
        r = await _postWithRetry(uri, {'Content-Type': 'application/json', 'x-goog-api-key': geminiKey}, body);
      } catch (e) {
        // If Gemini 3.6 is temporarily overloaded, retry the same request on the lighter stable model.
        if (e.toString().contains('HTTP 503')) {
          final uri = Uri.parse('https://generativelanguage.googleapis.com/v1beta/models/$fallbackModel:generateContent');
          r = await _postWithRetry(uri, {'Content-Type': 'application/json', 'x-goog-api-key': geminiKey}, body, timeout: const Duration(seconds: 20), attempts: 2);
        } else {
          rethrow;
        }
      }
      final d = jsonDecode(r.body);
      final reply = r.statusCode >= 200 && r.statusCode < 300 ? (d['candidates']?[0]?['content']?['parts']?[0]?['text'] ?? 'لم تصل إجابة.') : 'خطأ من Gemini (${r.statusCode}): ${d['error']?['message'] ?? 'تحقق من مفتاح API.'}';
      msgs.add(Msg(reply, false));
    } catch (e) { msgs.add(Msg('تعذر الاتصال بـ Gemini.\n\nالتفاصيل: $e', false)); }
    setState(() => loading = false); await save(); jump();
  }

  Future<void> generateImage(String prompt) async {
    if (prompt.isEmpty && pendingImage == null) return;
    final source = pendingImage; input.clear(); setState(() { msgs.add(Msg(prompt.isEmpty ? 'عدّل هذه الصورة' : prompt, true, imagePath: source)); pendingImage = null; loading = true; }); await save(); jump();
    try {
      final inputBlocks = <Map<String, dynamic>>[];
      if (source != null) { final bytes = await File(source).readAsBytes(); final mime = source.toLowerCase().endsWith('.png') ? 'image/png' : 'image/jpeg'; inputBlocks.add({'type': 'image', 'mime_type': mime, 'data': base64Encode(bytes)}); }
      inputBlocks.add({'type': 'text', 'text': prompt.isEmpty ? 'عدّل الصورة المرفقة مع الحفاظ على العناصر المهمة.' : prompt});
      final r = await _postWithRetry(Uri.parse('https://generativelanguage.googleapis.com/v1beta/interactions'), {'Content-Type': 'application/json', 'x-goog-api-key': geminiKey}, jsonEncode({'model': imageModel, 'input': inputBlocks, 'response_format': {'type': 'image', 'aspect_ratio': aspectRatio, 'image_size': imageSize}}), timeout: const Duration(seconds: 180));
      final d = jsonDecode(r.body);
      if (r.statusCode < 200 || r.statusCode >= 300) throw Exception(d['error']?['message'] ?? 'HTTP ${r.statusCode}');
      String? data;
      for (final step in (d['steps'] as List? ?? [])) { for (final block in (step['content'] as List? ?? [])) { if (block['type'] == 'image' && block['data'] != null) data = block['data']; } }
      if (data == null) throw Exception('لم تصل صورة من Gemini.');
      final dir = await getApplicationDocumentsDirectory(); final path = '${dir.path}/generated_${DateTime.now().millisecondsSinceEpoch}.png'; await File(path).writeAsBytes(base64Decode(data!));
      msgs.add(Msg('تم إنشاء الصورة ✨', false, imagePath: path, generated: true));
    } catch (e) { msgs.add(Msg('تعذر إنشاء الصورة.\n\nالتفاصيل: $e', false)); }
    setState(() => loading = false); await save(); jump();
  }

  Future<void> generateVideo(String prompt) async {
    if (prompt.trim().isEmpty) return;
    final q = prompt.trim(); input.clear();
    setState(() { msgs.add(Msg(q, true)); videoMode = true; loading = true; }); await save(); jump();
    try {
      final r = await http.post(Uri.parse('https://generativelanguage.googleapis.com/v1beta/models/$videoModel:predictLongRunning'), headers: {'Content-Type': 'application/json', 'x-goog-api-key': geminiKey}, body: jsonEncode({'instances': [{'prompt': q}], 'parameters': {'aspectRatio': aspectRatio == '9:16' ? '9:16' : '16:9', 'resolution': imageSize == '4K' ? '4k' : imageSize == '2K' ? '1080p' : '720p'}})).timeout(const Duration(seconds: 60));
      var d = jsonDecode(r.body);
      if (r.statusCode < 200 || r.statusCode >= 300) throw Exception(d['error']?['message'] ?? 'HTTP ${r.statusCode}');
      var name = d['name']?.toString();
      if (name == null) throw Exception('لم تبدأ عملية إنشاء الفيديو.');
      for (var i = 0; i < 36; i++) {
        await Future.delayed(const Duration(seconds: 5));
        final status = await http.get(Uri.parse('https://generativelanguage.googleapis.com/v1beta/$name'), headers: {'x-goog-api-key': geminiKey}).timeout(const Duration(seconds: 30));
        d = jsonDecode(status.body);
        if (status.statusCode < 200 || status.statusCode >= 300) throw Exception(d['error']?['message'] ?? 'HTTP ${status.statusCode}');
        if (d['done'] == true) break;
      }
      final uri = d['response']?['generateVideoResponse']?['generatedSamples']?[0]?['video']?['uri']?.toString();
      if (uri == null || uri.isEmpty) throw Exception('انتهى الانتظار دون رابط فيديو.');
      final video = await http.get(Uri.parse(uri), headers: {'x-goog-api-key': geminiKey}).timeout(const Duration(seconds: 120));
      if (video.statusCode < 200 || video.statusCode >= 300) throw Exception('فشل تنزيل الفيديو (${video.statusCode}).');
      final dir = await getApplicationDocumentsDirectory();
      final path = '${dir.path}/generated_video_${DateTime.now().millisecondsSinceEpoch}.mp4';
      await File(path).writeAsBytes(video.bodyBytes);
      msgs.add(Msg('تم إنشاء الفيديو 🎬', false, imagePath: path, generated: true));
    } catch (e) { msgs.add(Msg('تعذر إنشاء الفيديو.\n\nالتفاصيل: $e', false)); }
    setState(() { loading = false; videoMode = false; }); await save(); jump();
  }

  @override Widget build(BuildContext c) => Directionality(textDirection: TextDirection.rtl, child: Scaffold(
    appBar: AppBar(
      title: Row(children: [Container(width: 42, height: 42, decoration: BoxDecoration(gradient: const LinearGradient(colors: [Color(0xFF6750A4), Color(0xFF9B7BFF)]), borderRadius: BorderRadius.circular(13)), child: const Icon(Icons.auto_awesome, color: Colors.white)), const SizedBox(width: 12), const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('AI Assistant', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 18)), Text('مساعدك الذكي', style: TextStyle(fontSize: 12))])]),
      actions: [IconButton(tooltip: 'الإعدادات', onPressed: settings, icon: const Icon(Icons.tune_rounded)), IconButton(tooltip: 'مفتاح Gemini', onPressed: setGeminiKey, icon: Icon(geminiKey.isEmpty ? Icons.key_off_outlined : Icons.key_outlined)), IconButton(tooltip: 'مسح', onPressed: msgs.isEmpty ? null : () async { setState(() => msgs = []); await save(); }, icon: const Icon(Icons.delete_sweep_outlined))],
    ),
    body: Column(children: [
      if (videoMode) Container(width: double.infinity, padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8), color: Theme.of(c).colorScheme.secondaryContainer, child: Row(children: [const Icon(Icons.movie_creation_outlined), const SizedBox(width: 8), const Expanded(child: Text('وضع تصميم الفيديو — اكتب وصف الفيديو.')), IconButton(onPressed: () => setState(() => videoMode = false), icon: const Icon(Icons.close))])),
      if (imageMode) Container(width: double.infinity, padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8), color: Theme.of(c).colorScheme.primaryContainer, child: Row(children: [const Icon(Icons.image_outlined), const SizedBox(width: 8), const Expanded(child: Text('وضع تصميم الصور — اكتب وصف الصورة أو أرفق صورة لتعديلها.')), IconButton(onPressed: () => setState(() => imageMode = false), icon: const Icon(Icons.close))])),
      Expanded(child: msgs.isEmpty ? _home() : ListView.builder(controller: scroll, padding: const EdgeInsets.fromLTRB(16, 8, 16, 18), itemCount: msgs.length + (loading ? 1 : 0), itemBuilder: (c, i) => i < msgs.length ? _bubble(msgs[i]) : _bubble(Msg(imageMode ? 'يصمم الصورة الآن…' : videoMode ? 'يصمم الفيديو الآن…' : 'يفكر الآن…', false)))),
      _composer()
    ]),
  ));

  Widget _home() => ListView(padding: const EdgeInsets.fromLTRB(20, 24, 20, 12), children: [
    Container(
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(borderRadius: BorderRadius.circular(28), gradient: LinearGradient(begin: Alignment.topRight, end: Alignment.bottomLeft, colors: [Theme.of(context).colorScheme.primaryContainer, Theme.of(context).colorScheme.surfaceContainerHighest])),
      child: Column(children: [
        Container(width: 68, height: 68, decoration: BoxDecoration(shape: BoxShape.circle, color: Theme.of(context).colorScheme.surface.withOpacity(.75)), child: Icon(Icons.auto_awesome, size: 34, color: Theme.of(context).colorScheme.primary)),
        const SizedBox(height: 16),
        const Text('أهلاً بك 👋', style: TextStyle(fontSize: 29, fontWeight: FontWeight.w800)),
        const SizedBox(height: 7),
        Text('اسألني بأي لغة، أرسل صورة، أو صمّم صورة جديدة بالذكاء الاصطناعي. أستطيع مساعدتك في الرياضيات والدراسة والبرمجة والأسئلة العامة.', textAlign: TextAlign.center, style: TextStyle(color: Theme.of(context).colorScheme.onSurfaceVariant, fontSize: 15, height: 1.4)),
      ]),
    ),
    const SizedBox(height: 22), const Text('ماذا تريد أن تفعل؟', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 16)), const SizedBox(height: 12),
    _card('🎬', 'تصميم فيديو', 'أنشئ فيديو قصير سينمائي مع صوت مناسب') , _card('🖼️', 'تصميم صورة', 'أنشئ صورة واقعية لمدينة مستقبلية عند الغروب'), _card('🧮', 'حل مسألة رياضيات', 'حل 125 × 48 خطوة بخطوة وتحقق من الناتج'), _card('📷', 'حل أو تعديل من صورة', 'حلل الصورة المرفقة واشرح ما فيها'), _card('🌍', 'تحدث بلغة أخرى', 'Answer this question in English: What can you do?')
  ]);

  Widget _card(String icon, String title, String q) => InkWell(onTap: () { if (title == 'تصميم صورة') { setState(() { imageMode = true; videoMode = false; input.text = q; }); } else if (title == 'تصميم فيديو') { setState(() { videoMode = true; imageMode = false; input.text = q; }); } else { ask(q); } }, borderRadius: BorderRadius.circular(18), child: Container(margin: const EdgeInsets.only(bottom: 10), padding: const EdgeInsets.all(15), decoration: BoxDecoration(color: Theme.of(context).colorScheme.surfaceContainerLow, borderRadius: BorderRadius.circular(18), border: Border.all(color: Theme.of(context).colorScheme.outlineVariant)), child: Row(children: [Text(icon, style: const TextStyle(fontSize: 25)), const SizedBox(width: 13), Expanded(child: Text(title, style: const TextStyle(fontWeight: FontWeight.w700))), const Icon(Icons.arrow_back_ios_new, size: 16)])));
  Widget _bubble(Msg m) => Padding(padding: const EdgeInsets.symmetric(vertical: 5), child: Row(crossAxisAlignment: CrossAxisAlignment.start, mainAxisAlignment: m.user ? MainAxisAlignment.start : MainAxisAlignment.end, children: [if (!m.user) Container(width: 34, height: 34, margin: const EdgeInsets.only(left: 8, top: 2), decoration: BoxDecoration(shape: BoxShape.circle, color: Theme.of(context).colorScheme.primaryContainer), child: Icon(Icons.auto_awesome, size: 18, color: Theme.of(context).colorScheme.primary)), Flexible(child: Container(padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 13), decoration: BoxDecoration(color: m.user ? Theme.of(context).colorScheme.primary : Theme.of(context).colorScheme.surfaceContainerHighest, borderRadius: BorderRadius.only(topLeft: const Radius.circular(20), topRight: const Radius.circular(20), bottomLeft: Radius.circular(m.user ? 20 : 5), bottomRight: Radius.circular(m.user ? 5 : 20))), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [if (m.imagePath != null && File(m.imagePath!).existsSync() && m.imagePath!.toLowerCase().endsWith('.mp4')) VideoBubble(path: m.imagePath!), if (m.imagePath != null && File(m.imagePath!).existsSync() && !m.imagePath!.toLowerCase().endsWith('.mp4')) ClipRRect(borderRadius: BorderRadius.circular(12), child: Image.file(File(m.imagePath!), height: 260, width: 300, fit: BoxFit.cover)), if (m.imagePath != null) const SizedBox(height: 7), if (m.text.isNotEmpty) SelectableText(m.text, style: TextStyle(color: m.user ? Theme.of(context).colorScheme.onPrimary : null, fontSize: 16, height: 1.45))])))]));

  Widget _composer() => SafeArea(child: Padding(padding: const EdgeInsets.fromLTRB(10, 7, 10, 10), child: Column(children: [
    if (pendingImage != null) Container(width: double.infinity, margin: const EdgeInsets.only(bottom: 7), padding: const EdgeInsets.all(8), decoration: BoxDecoration(color: Theme.of(context).colorScheme.surfaceContainerHighest, borderRadius: BorderRadius.circular(15)), child: Row(children: [ClipRRect(borderRadius: BorderRadius.circular(10), child: Image.file(File(pendingImage!), width: 55, height: 55, fit: BoxFit.cover)), const SizedBox(width: 10), const Expanded(child: Text('الصورة جاهزة')), IconButton(onPressed: () => setState(() => pendingImage = null), icon: const Icon(Icons.close))])),
    Row(crossAxisAlignment: CrossAxisAlignment.end, children: [
      PopupMenuButton<String>(onSelected: (v) { if (v == 'gallery') chooseImage(); if (v == 'camera') takePhoto(); if (v == 'image') setState(() { imageMode = true; videoMode = false; }); if (v == 'video') setState(() { videoMode = true; imageMode = false; }); }, itemBuilder: (c) => const [PopupMenuItem(value: 'gallery', child: ListTile(leading: Icon(Icons.photo_library_outlined), title: Text('اختيار صورة'))), PopupMenuItem(value: 'camera', child: ListTile(leading: Icon(Icons.camera_alt_outlined), title: Text('تصوير'))), PopupMenuItem(value: 'image', child: ListTile(leading: Icon(Icons.auto_awesome), title: Text('تصميم / تعديل صورة')))], child: const Padding(padding: EdgeInsets.all(12), child: Icon(Icons.add_circle_outline))),
      Expanded(child: TextField(controller: input, minLines: 1, maxLines: 5, decoration: InputDecoration(hintText: imageMode ? 'صف الصورة التي تريدها…' : videoMode ? 'صف الفيديو الذي تريد إنشاءه…' : recording ? 'جاري التسجيل…' : 'اسأل AI Assistant…', filled: true, fillColor: Theme.of(context).colorScheme.surfaceContainerHighest, contentPadding: const EdgeInsets.symmetric(horizontal: 18, vertical: 13), border: OutlineInputBorder(borderRadius: BorderRadius.circular(25), borderSide: BorderSide.none)))),
      const SizedBox(width: 5), IconButton(onPressed: toggleRecording, tooltip: recording ? 'إيقاف التسجيل' : 'تسجيل صوت', icon: Icon(recording ? Icons.stop_circle_outlined : Icons.mic_none_rounded, color: recording ? Colors.red : null)), const SizedBox(width: 2), SizedBox(width: 50, height: 50, child: IconButton.filled(onPressed: loading ? null : send, icon: const Icon(Icons.arrow_upward_rounded)))
    ])
  ])));
}
