import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:math' as math;

import 'package:flutter/services.dart';

import 'package:dio/dio.dart';
import 'package:file_picker/file_picker.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter_tts/flutter_tts.dart';
import 'package:gal/gal.dart';
import 'package:http/http.dart' as http;
import 'package:image_picker/image_picker.dart';
import 'package:syncfusion_flutter_pdf/pdf.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:path_provider/path_provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:speech_to_text/speech_to_text.dart' as stt;
import 'package:url_launcher/url_launcher.dart';
import 'package:video_player/video_player.dart';
import 'package:share_plus/share_plus.dart';

const _buildGeminiApiKey = String.fromEnvironment('GEMINI_API_KEY', defaultValue: '');
const _buildGroqApiKey = String.fromEnvironment('GROQ_API_KEY', defaultValue: '');

void main() => runApp(const AiApp());

const Map<String, (Color, Color)> _accentPresets = {
  'claude': (Color(0xFFCC785C), Color(0xFFAF5B3F)),
  'ocean': (Color(0xFF3B82C4), Color(0xFF2B5F8F)),
  'mono': (Color(0xFF2B2B2B), Color(0xFF000000)),
};
final ValueNotifier<String> accentPresetNotifier = ValueNotifier('claude');
Color get kAccent => (_accentPresets[accentPresetNotifier.value] ?? _accentPresets['claude']!).$1;
Color get kAccentDeep => (_accentPresets[accentPresetNotifier.value] ?? _accentPresets['claude']!).$2;

ThemeData appTheme(Brightness b) {
  final base = ThemeData(useMaterial3: true, brightness: b);
  return ThemeData(
      useMaterial3: true,
      brightness: b,
      textTheme: GoogleFonts.tajawalTextTheme(base.textTheme),
      colorScheme: ColorScheme.fromSeed(
        seedColor: kAccent,
        brightness: b,
      ),
      scaffoldBackgroundColor:
          b == Brightness.dark ? const Color(0xFF191712) : const Color(0xFFFAF8F5),
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: b == Brightness.dark ? const Color(0xFF232019) : Colors.white,
        contentPadding: const EdgeInsets.symmetric(horizontal: 18, vertical: 15),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(22),
          borderSide: BorderSide.none,
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(22),
          borderSide: BorderSide.none,
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(22),
          borderSide: BorderSide(color: kAccent, width: 1.2),
        ),
      ),
      cardTheme: CardThemeData(
        elevation: 0,
        margin: EdgeInsets.zero,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
      ),
      appBarTheme: AppBarTheme(
        centerTitle: false,
        surfaceTintColor: Colors.transparent,
        titleSpacing: 4,
      ),
    );
}

final ValueNotifier<ThemeMode> themeModeNotifier = ValueNotifier(ThemeMode.system);

class AiApp extends StatelessWidget {
  const AiApp({super.key});

  @override
  Widget build(BuildContext context) => ValueListenableBuilder<ThemeMode>(
        valueListenable: themeModeNotifier,
        builder: (_, mode, _) => ValueListenableBuilder<String>(
          valueListenable: accentPresetNotifier,
          builder: (_, _, _) => MaterialApp(
            debugShowCheckedModeBanner: false,
            title: 'AI Assistant',
            theme: appTheme(Brightness.light),
            darkTheme: appTheme(Brightness.dark),
            themeMode: mode,
            home: const ChatPage(),
          ),
        ),
      );
}

class _TypeReveal extends StatefulWidget {
  final String text;
  final Widget Function(String visible) builder;
  const _TypeReveal({required this.text, required this.builder});
  @override
  State<_TypeReveal> createState() => _TypeRevealState();
}

class _TypeRevealState extends State<_TypeReveal> {
  int _shown = 0;
  Timer? _timer;

  @override
  void initState() {
    super.initState();
    final total = widget.text.length;
    if (total == 0) return;
    final stepChars = (total / 60).ceil().clamp(1, 40);
    _timer = Timer.periodic(const Duration(milliseconds: 16), (t) {
      if (!mounted) { t.cancel(); return; }
      setState(() => _shown = (_shown + stepChars).clamp(0, total));
      if (_shown >= total) t.cancel();
    });
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => widget.builder(widget.text.substring(0, _shown));
}

class _FullscreenImage extends StatelessWidget {
  final String path;
  const _FullscreenImage({required this.path});

  @override
  Widget build(BuildContext context) => GestureDetector(
        onTap: () => Navigator.of(context).pop(),
        child: Scaffold(
          backgroundColor: Colors.black,
          body: SafeArea(
            child: Stack(
              children: [
                Center(child: InteractiveViewer(maxScale: 5, child: Image.file(File(path)))),
                Positioned(
                  top: 8,
                  right: 8,
                  child: IconButton(
                    icon: const Icon(Icons.close, color: Colors.white, size: 28),
                    onPressed: () => Navigator.of(context).pop(),
                  ),
                ),
              ],
            ),
          ),
        ),
      );
}

/// A message that has no Arabic-script characters should render strictly
/// LTR even though the app itself is RTL — otherwise the ambient RTL
/// paragraph direction can visually displace trailing punctuation (a
/// trailing "?" jumping to the start of an all-English reply, for example).
TextDirection _detectDirection(String text) {
  final hasArabic = RegExp(r'[\u0600-\u06FF\u0750-\u077F\u08A0-\u08FF]').hasMatch(text);
  return hasArabic ? TextDirection.rtl : TextDirection.ltr;
}

class Msg {
  final String text;
  final bool user;
  final String? file;
  final String? image;
  final String? video;
  final List<String> sources;
  final String? retryOf;
  final String? retryFile;

  Msg(this.text, this.user, {this.file, this.image, this.video, this.sources = const [], this.retryOf, this.retryFile});

  Map<String, dynamic> toJson() => {
        'text': text,
        'user': user,
        'file': file,
        'image': image,
        'video': video,
        'sources': sources,
      };

  factory Msg.fromJson(Map<String, dynamic> x) => Msg(
        '${x['text'] ?? ''}',
        x['user'] == true,
        file: x['file']?.toString(),
        image: x['image']?.toString(),
        video: x['video']?.toString(),
        sources: (x['sources'] as List? ?? const []).map((e) => '$e').toList(),
      );
}

class _InlineVideo extends StatefulWidget {
  final String path;
  const _InlineVideo({required this.path});
  @override
  State<_InlineVideo> createState() => _InlineVideoState();
}

class _InlineVideoState extends State<_InlineVideo> {
  late final VideoPlayerController _controller;
  @override
  void initState() {
    super.initState();
    final source = widget.path.toLowerCase().startsWith('http://') || widget.path.toLowerCase().startsWith('https://')
        ? VideoPlayerController.networkUrl(Uri.parse(widget.path))
        : VideoPlayerController.file(File(widget.path));
    _controller = source..initialize().then((_) { if (mounted) setState(() {}); });
  }
  @override
  void dispose() { _controller.dispose(); super.dispose(); }
  @override
  Widget build(BuildContext context) {
    if (!_controller.value.isInitialized) {
      return const Padding(padding: EdgeInsets.all(18), child: Center(child: CircularProgressIndicator()));
    }
    return Column(
      children: [
        ClipRRect(borderRadius: BorderRadius.circular(16), child: AspectRatio(aspectRatio: _controller.value.aspectRatio, child: VideoPlayer(_controller))),
        Row(children: [
          IconButton(onPressed: () => setState(() => _controller.value.isPlaying ? _controller.pause() : _controller.play()), icon: Icon(_controller.value.isPlaying ? Icons.pause : Icons.play_arrow)),
          Expanded(child: VideoProgressIndicator(_controller, allowScrubbing: true)),
          IconButton(onPressed: () => setState(() => _controller.setLooping(!_controller.value.isLooping)), icon: Icon(_controller.value.isLooping ? Icons.repeat_one : Icons.repeat)),
        ]),
      ],
    );
  }
}

class ChatSession {
  final String id;
  String title;
  final List<Msg> messages;

  ChatSession({required this.id, required this.title, List<Msg>? messages})
      : messages = messages ?? <Msg>[];

  Map<String, dynamic> toJson() => {
        'id': id,
        'title': title,
        'messages': messages.map((m) => m.toJson()).toList(),
      };

  factory ChatSession.fromJson(Map<String, dynamic> x) => ChatSession(
        id: '${x['id']}',
        title: '${x['title'] ?? 'محادثة جديدة'}',
        messages: (x['messages'] as List? ?? const [])
            .map((e) => Msg.fromJson(Map<String, dynamic>.from(e as Map)))
            .toList(),
      );
}

class Reply {
  final String text;
  final List<String> sources;
  Reply(this.text, this.sources);
}

class MathEngine {
  static String? solve(String raw) {
    var s = raw;
    const arabicDigits = '٠١٢٣٤٥٦٧٨٩';
    const easternDigits = '۰۱۲۳۴۵۶۷۸۹';
    for (var i = 0; i < 10; i++) {
      s = s.replaceAll(arabicDigits[i], '$i').replaceAll(easternDigits[i], '$i');
    }
    s = s
        .replaceAll('×', '*')
        .replaceAll('÷', '/')
        .replaceAll('−', '-')
        .replaceAll('٫', '.')
        .replaceAll('٬', '')
        .replaceAll(RegExp(r'\s+'), '');
    if (!RegExp(r'^[0-9+\-*/^().]+$').hasMatch(s) ||
        !RegExp(r'[+\-*/]').hasMatch(s)) {
      return null;
    }
    try {
      final value = _eval(_rpn(_tokens(s)));
      final exact = value.d == BigInt.one ? '${value.n}' : '${value.n}/${value.d}';
      final decimal = _decimal(value);
      return 'الناتج الدقيق: $exact\nالناتج العشري: $decimal\n\n'
          'خطوات الحل:\n'
          '1) أطبّق الأقواس أولًا إن وُجدت.\n'
          '2) أطبّق الضرب والقسمة من اليسار إلى اليمين.\n'
          '3) أطبّق الجمع والطرح من اليسار إلى اليمين.\n'
          '4) أراجع الحساب باستخدام الكسور بدل التقريب المبكر.';
    } catch (_) {
      return null;
    }
  }

  static String _decimal(_R x) {
    if (x.d == BigInt.zero) return 'غير معرّف';
    final v = x.n / x.d;
    if (!v.isFinite) return 'غير معرّف';
    final s = v.toStringAsFixed(12);
    return s.replaceFirst(RegExp(r'0+$'), '').replaceFirst(RegExp(r'\.$'), '');
  }

  static List<String> _tokens(String s) {
    final out = <String>[];
    var i = 0;
    while (i < s.length) {
      final c = s[i];
      if ('+-*/^()'.contains(c)) {
        if (c == '-' && (out.isEmpty || '+-*/^('.contains(out.last))) out.add('0');
        out.add(c);
        i++;
        continue;
      }
      var j = i;
      var dots = 0;
      while (j < s.length && RegExp(r'[0-9.]').hasMatch(s[j])) {
        if (s[j] == '.') dots++;
        if (dots > 1) throw const FormatException();
        j++;
      }
      if (j == i) throw const FormatException();
      out.add(s.substring(i, j));
      i = j;
    }
    return out;
  }

  static List<String> _rpn(List<String> tokens) {
    const priority = {'+': 1, '-': 1, '*': 2, '/': 2, '^': 3};
    final output = <String>[];
    final ops = <String>[];
    for (final token in tokens) {
      if (double.tryParse(token) != null) {
        output.add(token);
      } else if (priority.containsKey(token)) {
        while (ops.isNotEmpty &&
            priority.containsKey(ops.last) &&
            (priority[ops.last]! > priority[token]! ||
                (priority[ops.last] == priority[token] && token != '^'))) {
          output.add(ops.removeLast());
        }
        ops.add(token);
      } else if (token == '(') {
        ops.add(token);
      } else if (token == ')') {
        while (ops.isNotEmpty && ops.last != '(') {
          output.add(ops.removeLast());
        }
        if (ops.isEmpty) throw const FormatException();
        ops.removeLast();
      } else {
        throw const FormatException();
      }
    }
    while (ops.isNotEmpty) {
      if (ops.last == '(') throw const FormatException();
      output.add(ops.removeLast());
    }
    return output;
  }

  static _R _pow(_R a, _R b) {
    if (b.d != BigInt.one || b.n.abs() > BigInt.from(1000)) throw const FormatException();
    final e = b.n.toInt();
    if (e == 0) return _R(BigInt.one, BigInt.one);
    if (e > 0) return _R(a.n.pow(e), a.d.pow(e)).norm();
    if (a.n == BigInt.zero) throw const FormatException();
    final k = -e;
    return _R(a.d.pow(k), a.n.pow(k)).norm();
  }

  static _R _eval(List<String> rpn) {
    final stack = <_R>[];
    for (final token in rpn) {
      final n = double.tryParse(token);
      if (n != null) {
        stack.add(_R.fromString(token));
      } else {
        if (stack.length < 2) throw const FormatException();
        final b = stack.removeLast();
        final a = stack.removeLast();
        stack.add(switch (token) {
          '+' => a + b,
          '-' => a - b,
          '*' => a * b,
          '/' => a / b,
          '^' => _pow(a, b),
          _ => throw const FormatException(),
        });
      }
    }
    if (stack.length != 1) throw const FormatException();
    return stack.single;
  }
}

class _R {
  final BigInt n;
  final BigInt d;
  _R(this.n, this.d);

  factory _R.fromString(String s) {
    if (!s.contains('.')) return _R(BigInt.parse(s), BigInt.one);
    final p = s.split('.');
    final den = BigInt.from(10).pow(p[1].length);
    final whole = p[0].isEmpty || p[0] == '-' ? '0' : p[0];
    final negative = whole.startsWith('-');
    final fracPart = BigInt.parse(p[1].isEmpty ? '0' : p[1]);
    var num = BigInt.parse(whole).abs() * den + fracPart;
    if (negative) num = -num;
    return _R(num, den).norm();
  }

  _R norm() {
    if (d == BigInt.zero) throw const FormatException();
    var a = n.abs();
    var b = d.abs();
    while (b != BigInt.zero) {
      final t = a % b;
      a = b;
      b = t;
    }
    final g = a == BigInt.zero ? BigInt.one : a;
    final nn = n ~/ g;
    final dd = d ~/ g;
    return dd < BigInt.zero ? _R(-nn, -dd) : _R(nn, dd);
  }

  _R operator +(_R x) => _R(n * x.d + x.n * d, d * x.d).norm();
  _R operator -(_R x) => _R(n * x.d - x.n * d, d * x.d).norm();
  _R operator *(_R x) => _R(n * x.n, d * x.d).norm();
  _R operator /(_R x) {
    if (x.n == BigInt.zero) throw const FormatException();
    return _R(n * x.d, d * x.n).norm();
  }
}


/// Extracts text locally from a PDF's real text layer — entirely on-device,
/// no network call and no API key involved. Returns null (rather than
/// throwing) for a scanned/image-only PDF, an encrypted PDF, or a corrupt
/// file, so callers can fall back to an honest "needs Gemini/OCR" message.
Future<String?> extractPdfText(String path) async {
  PdfDocument? document;
  try {
    final bytes = await File(path).readAsBytes();
    document = PdfDocument(inputBytes: bytes);
    final text = PdfTextExtractor(document).extractText();
    return text;
  } catch (_) {
    return null;
  } finally {
    document?.dispose();
  }
}

String prettyMath(String text) {
  // Gemini/Groq may return LaTeX such as $\\angle ABC=60^\\circ$.
  // This app is intentionally text-first, so convert common LaTeX notation
  // to readable Unicode instead of exposing raw dollar signs to the user.
  final pattern = RegExp(r'\$\$([\s\S]*?)\$\$|\$([^$\n]+)\$');
  var out = text.replaceAllMapped(pattern, (m) {
    final value = m.group(1) ?? m.group(2) ?? '';
    return _prettyMathChunk(value);
  });

  // Also clean up a few common un-delimited snippets.
  out = out
      .replaceAll(RegExp(r'^\s*#{1,6}\s*', multiLine: true), '')
      .replaceAll(RegExp(r'^\s*[-*]\s+', multiLine: true), '• ')
      .replaceAll(r'\circ', '°')
      .replaceAll(r'\degree', '°')
      .replaceAll(r'\angle', '∠')
      .replaceAll(r'\triangle', '△')
      .replaceAll(r'\parallel', '∥')
      .replaceAll(r'\perp', '⊥')
      .replaceAll(r'\times', '×')
      .replaceAll(r'\cdot', '·')
      .replaceAll(r'\div', '÷')
      .replaceAll(r'\pm', '±')
      .replaceAll(r'\leq', '≤')
      .replaceAll(r'\geq', '≥')
      .replaceAll(r'\neq', '≠')
      .replaceAll(r'\pi', 'π')
      .replaceAll(r'\theta', 'θ')
      .replaceAll(r'\alpha', 'α')
      .replaceAll(r'\beta', 'β')
      .replaceAll(r'\gamma', 'γ')
      .replaceAll(r'\Delta', 'Δ')
      .replaceAll(r'\sum', 'Σ')
      .replaceAll(r'\infty', '∞');
  return out;
}

/// Turns **bold**, [text](url) markdown links, and bare https:// URLs into
/// real tappable spans instead of raw text, so links behave like a normal
/// chat app (tap to open) rather than being shown as plain unclickable text.
List<InlineSpan> richSpans(String raw, {required Color linkColor, TextStyle? bold}) {
  final pattern = RegExp(
    r'\*\*(?<bold>[^*]+)\*\*|\[(?<linktext>[^\]]+)\]\((?<linkurl>https?://[^\s\)]+)\)|(?<bareurl>/?https?://[^\s\)\]\}>"\u201d،]+)|(?<dev>علي أحمد قرباج|Ali Ahmed Gorbaj)',
  );
  final spans = <InlineSpan>[];
  var last = 0;

  void addPlain(String s) {
    if (s.isNotEmpty) spans.add(TextSpan(text: s));
  }

  void addLink(String label, String url) {
    spans.add(TextSpan(
      text: label,
      style: TextStyle(color: linkColor, decoration: TextDecoration.underline, fontWeight: FontWeight.w700),
      recognizer: TapGestureRecognizer()
        ..onTap = () async {
          final uri = Uri.tryParse(url);
          if (uri != null) await launchUrl(uri, mode: LaunchMode.externalApplication);
        },
    ));
  }

  for (final m in pattern.allMatches(raw)) {
    addPlain(raw.substring(last, m.start));
    final boldText = m.namedGroup('bold');
    final linkText = m.namedGroup('linktext');
    final linkUrl = m.namedGroup('linkurl');
    final bareRaw = m.namedGroup('bareurl');
    final devName = m.namedGroup('dev');
    if (boldText != null) {
      spans.add(TextSpan(text: boldText, style: bold ?? const TextStyle(fontWeight: FontWeight.w800)));
    } else if (linkText != null && linkUrl != null) {
      addLink(linkText, linkUrl);
    } else if (devName != null) {
      spans.add(TextSpan(text: devName, style: TextStyle(color: kAccent, fontWeight: FontWeight.w800)));
    } else if (bareRaw != null) {
      var url = bareRaw.replaceFirst(RegExp('^/'), '');
      var trailing = '';
      while (url.isNotEmpty && '.,!؟:؛)'.contains(url[url.length - 1])) {
        trailing = url[url.length - 1] + trailing;
        url = url.substring(0, url.length - 1);
      }
      addLink(url, url);
      addPlain(trailing);
    }
    last = m.end;
  }
  addPlain(raw.substring(last));
  return spans;
}

String _prettyMathChunk(String value) {
  var s = value.trim();
  s = s
      .replaceAll(r'\left', '')
      .replaceAll(r'\right', '')
      .replaceAll(r'\angle', '∠')
      .replaceAll(r'\triangle', '△')
      .replaceAll(r'\parallel', '∥')
      .replaceAll(r'\perp', '⊥')
      .replaceAll(r'\circ', '°')
      .replaceAll(r'\degree', '°')
      .replaceAll(r'\times', '×')
      .replaceAll(r'\cdot', '·')
      .replaceAll(r'\div', '÷')
      .replaceAll(r'\pm', '±')
      .replaceAll(r'\leq', '≤')
      .replaceAll(r'\geq', '≥')
      .replaceAll(r'\neq', '≠')
      .replaceAll(r'\pi', 'π')
      .replaceAll(r'\theta', 'θ')
      .replaceAll(r'\alpha', 'α')
      .replaceAll(r'\beta', 'β')
      .replaceAll(r'\gamma', 'γ')
      .replaceAll(r'\Delta', 'Δ')
      .replaceAll(r'\sum', 'Σ')
      .replaceAll(r'\infty', '∞');

  // Convert common fractions such as \frac{a}{b} to readable text.
  final frac = RegExp(r'\\frac\{([^{}]+)\}\{([^{}]+)\}');
  while (frac.hasMatch(s)) {
    s = s.replaceAllMapped(frac, (m) => '(${m.group(1)})/(${m.group(2)})');
  }
  s = s.replaceAll(RegExp(r'\\text\{([^{}]*)\}'), r'$1');
  s = s.replaceAll(r'^{2}', '²').replaceAll('^2', '²');
  s = s.replaceAll(r'^{3}', '³').replaceAll('^3', '³');
  s = s.replaceAll(r'^\circ', '°').replaceAll(r'^\degree', '°');
  s = s.replaceAll(RegExp(r'\_\{([^{}]+)\}'), r'_($1)');
  s = s.replaceAll('{', '').replaceAll('}', '');
  return s;
}


/// Wraps either an exact BigInt fraction (_R) or, once an irrational
/// operation (sqrt/trig/log/non-integer power/...) is unavoidable, a plain
/// double. Staying exact as long as possible is what lets AdvancedMathEngine
/// handle huge integer arithmetic (18+ digit numbers) without the precision
/// loss that plain `double` arithmetic suffers past 2^53.
class _Val {
  final _R? _r;
  final double _d;
  const _Val.exact(_R r) : _r = r, _d = 0;
  const _Val.approx(double d) : _r = null, _d = d;
  bool get isExact => _r != null;
  _R get r => _r!;
  double toDouble() => _r != null ? (_r.n.toDouble() / _r.d.toDouble()) : _d;
  bool get isFinite => _r != null ? true : _d.isFinite;
}

_Val _vAdd(_Val a, _Val b) => (a.isExact && b.isExact) ? _Val.exact(a.r + b.r) : _Val.approx(a.toDouble() + b.toDouble());
_Val _vSub(_Val a, _Val b) => (a.isExact && b.isExact) ? _Val.exact(a.r - b.r) : _Val.approx(a.toDouble() - b.toDouble());
_Val _vMul(_Val a, _Val b) => (a.isExact && b.isExact) ? _Val.exact(a.r * b.r) : _Val.approx(a.toDouble() * b.toDouble());
_Val _vNeg(_Val a) => a.isExact ? _Val.exact(_R(-a.r.n, a.r.d)) : _Val.approx(-a.toDouble());

_Val _vDiv(_Val a, _Val b) {
  if (a.isExact && b.isExact) {
    if (b.r.n == BigInt.zero) throw const FormatException();
    return _Val.exact(a.r / b.r);
  }
  final bd = b.toDouble();
  if (bd == 0) throw const FormatException();
  return _Val.approx(a.toDouble() / bd);
}

_R _vIntPow(_R base, BigInt exponent) {
  var result = _R(BigInt.one, BigInt.one);
  var b = base;
  var n = exponent;
  while (n > BigInt.zero) {
    if (n.isOdd) result = result * b;
    b = b * b;
    n = n >> 1;
  }
  return result.norm();
}

_Val _vPow(_Val base, _Val exp) {
  if (base.isExact && exp.isExact && exp.r.d == BigInt.one && exp.r.n.abs() <= BigInt.from(1000)) {
    final e = exp.r.n;
    if (e >= BigInt.zero) return _Val.exact(_vIntPow(base.r, e));
    if (base.r.n == BigInt.zero) throw const FormatException();
    final positive = _vIntPow(base.r, -e);
    return _Val.exact(_R(positive.d, positive.n).norm());
  }
  return _Val.approx(math.pow(base.toDouble(), exp.toDouble()).toDouble());
}

_Val _vFactorial(_Val v) {
  if (v.isExact && v.r.d == BigInt.one && v.r.n >= BigInt.zero && v.r.n <= BigInt.from(6000)) {
    var result = BigInt.one;
    var i = BigInt.two;
    final n = v.r.n;
    while (i <= n) {
      result *= i;
      i += BigInt.one;
    }
    return _Val.exact(_R(result, BigInt.one));
  }
  final d = v.toDouble();
  if (d < 0 || d.roundToDouble() != d || d > 170) throw const FormatException();
  var result = 1.0;
  for (var i = 2; i <= d.toInt(); i++) {
    result *= i;
  }
  return _Val.approx(result);
}

/// Exact decimal expansion of n/d via long division (no double involved),
/// so even a huge exact fraction gets a trustworthy "≈" preview.
String _exactDecimalPreview(BigInt n, BigInt d, int places) {
  final neg = (n.sign * d.sign) < 0;
  n = n.abs();
  d = d.abs();
  final whole = n ~/ d;
  var rem = n % d;
  final buf = StringBuffer(whole.toString());
  if (rem != BigInt.zero) {
    buf.write('.');
    for (var i = 0; i < places && rem != BigInt.zero; i++) {
      rem *= BigInt.from(10);
      buf.write((rem ~/ d).toString());
      rem = rem % d;
    }
  }
  final out = buf.toString();
  return neg ? '-$out' : out;
}


class SmartMathEngine {
  static String? solve(String raw) {
    var s = raw.trim();
    if (s.isEmpty) return null;
    final normalized = _normalizeArabicMath(s);
    if (normalized == null) return null;
    s = normalized;
    final converted = _unitConversion(s);
    if (converted != null) return converted;

    final eq = s.split('=');
    if (eq.length == 2 && RegExp(r'(^|[^A-Za-z])x([^A-Za-z]|$)').hasMatch(eq.join('='))) {
      final equation = _solveEquation(eq[0], eq[1]);
      if (equation != null) return equation;
    }
    return null;
  }

  static String _normalizeArabicMath(String s) {
    const digitsA = '٠١٢٣٤٥٦٧٨٩';
    const digitsE = '۰۱۲۳۴۵۶۷۸۹';
    for (var i = 0; i < 10; i++) {
      s = s.replaceAll(digitsA[i], '$i').replaceAll(digitsE[i], '$i');
    }
    s = s.replaceAll('٪', '%').replaceAll('٫', '.').replaceAll('٬', '')
        .replaceAll('×', '*').replaceAll('÷', '/').replaceAll('−', '-').replaceAll('س', 'x');
    s = ' $s ';
    for (final pair in const {
      'زائد': '+', 'جمع': '+', 'ناقص': '-', 'طرح': '-',
      'ضرب': '*', 'اضرب': '*', 'قسمة': '/', 'اقسم': '/',
      'جذر': 'sqrt', 'باي': 'pi', 'فاي': 'phi',
    }.entries) {
      s = s.replaceAll(' ${pair.key} ', ' ${pair.value} ');
    }
    s = s.trim();

    s = s.replaceFirst(RegExp(r'^(احسب|احسبي|حل|حللي|احسبلي|كم يساوي|ما ناتج|الناتج هو)\s*', caseSensitive: false), '');
    s = s.replaceAll(RegExp(r'\s+'), ' ').trim();
    // "20% من 150" -> "150*20%" while avoiding word-problem text.
    final pct = RegExp(r'^(?:كم\s+)?(\d+(?:\.\d+)?)\s*%\s*(?:من|of)\s*(\d+(?:\.\d+)?)$', caseSensitive: false);
    final m = pct.firstMatch(s);
    if (m != null) return '${m.group(2)}*${m.group(1)}%';

    if (RegExp(r'^[0-9a-zA-Z_+\-*/^().,%!\s]+$').hasMatch(s) && RegExp(r'[0-9)]').hasMatch(s)) {
      try {
        final value = _ExpressionParser(s).parse();
        if (value.isFinite) {
          final result = value.isExact
              ? (value.r.d == BigInt.one
                  ? 'الناتج: ${value.r.n}'
                  : 'الناتج الدقيق: ${value.r.n}/${value.r.d}\nالناتج التقريبي: ${_exactDecimalPreview(value.r.n, value.r.d, 12)}')
              : 'الناتج: ${_fmt(value.toDouble())}';
          return '$result\n\nخطوات الحل:\n1) حللت التعبير بعد توحيد الأرقام والرموز والكلمات الرياضية.\n2) طبّقت ترتيب العمليات والأقواس والأسس والدوال عند وجودها.\n3) حافظت على الدقة الكاملة بالكسور عندما كان ذلك ممكنًا.';
        }
      } catch (_) {}
    }
    return null;
  }

  static String? _unitConversion(String s) {
    final normalized = s
        .replaceAll(RegExp(r'\bكيلومتر(?:ات)?\b', caseSensitive: false), 'km')
        .replaceAll(RegExp(r'\bكم\b', caseSensitive: false), 'km')
        .replaceAll(RegExp(r'\bمتر(?:ات)?\b', caseSensitive: false), 'm')
        .replaceAll(RegExp(r'\bسنتيمتر(?:ات)?\b', caseSensitive: false), 'cm')
        .replaceAll(RegExp(r'\bمليمتر(?:ات)?\b', caseSensitive: false), 'mm')
        .replaceAll(RegExp(r'\bميل(?:ات)?\b', caseSensitive: false), 'mile')
        .replaceAll(RegExp(r'\bقدم(?:اً|ا)?\b', caseSensitive: false), 'ft')
        .replaceAll(RegExp(r'\bبوصة(?:ات)?\b', caseSensitive: false), 'inch')
        .replaceAll(RegExp(r'\bكيلوغرام(?:ات)?\b|\bكغ\b|\bكيلو\b', caseSensitive: false), 'kg')
        .replaceAll(RegExp(r'\bغرام(?:ات)?\b', caseSensitive: false), 'g')
        .replaceAll(RegExp(r'\bميليغرام(?:ات)?\b|\bمغ\b', caseSensitive: false), 'mg')
        .replaceAll(RegExp(r'\bرطل(?:ان|ين)?\b', caseSensitive: false), 'lb')
        .replaceAll(RegExp(r'\bدرجة\s*مئوية\b|\bمئوية\b', caseSensitive: false), 'c')
        .replaceAll(RegExp(r'\bدرجة\s*فهرنهايت\b|\bفهرنهايت\b', caseSensitive: false), 'f');
    final m = RegExp(r'^\s*(\-?\d+(?:\.\d+)?)\s*(km|m|cm|mm|mile|miles|ft|foot|inch|in|kg|g|mg|lb|c|f|°c|°f)\s*(?:to|in|إلى|الى|لـ|ل)\s*(km|m|cm|mm|mile|miles|ft|foot|inch|in|kg|g|mg|lb|c|f|°c|°f)\s*$', caseSensitive: false).firstMatch(normalized);
    if (m == null) return null;
    final value = double.parse(m.group(1)!);
    final from = m.group(2)!.toLowerCase().replaceAll('°', '');
    final to = m.group(3)!.toLowerCase().replaceAll('°', '');
    double? out;
    if ({'km','m','cm','mm','mile','miles','ft','foot','inch','in'}.contains(from) && {'km','m','cm','mm','mile','miles','ft','foot','inch','in'}.contains(to)) {
      const metres = {'km':1000.0,'m':1.0,'cm':0.01,'mm':0.001,'mile':1609.344,'miles':1609.344,'ft':0.3048,'foot':0.3048,'inch':0.0254,'in':0.0254};
      out = value * metres[from]! / metres[to]!;
    } else if ({'kg','g','mg','lb'}.contains(from) && {'kg','g','mg','lb'}.contains(to)) {
      const grams = {'kg':1000.0,'g':1.0,'mg':0.001,'lb':453.59237};
      out = value * grams[from]! / grams[to]!;
    } else if ({'c','f'}.contains(from) && {'c','f'}.contains(to)) {
      out = from == to ? value : (from == 'c' ? value * 9 / 5 + 32 : (value - 32) * 5 / 9);
    }
    if (out == null) return null;
    return 'الناتج: ${_fmt(out)} $to';
  }

  static String? _solveEquation(String left, String right) {
    final l = left.trim().replaceAll('س', 'x');
    final r = right.trim().replaceAll('س', 'x');
    if (!RegExp(r'^[0-9A-Za-z_+\-*/^().,%!\s]+$').hasMatch(l) || !RegExp(r'^[0-9A-Za-z_+\-*/^().,%!\s]+$').hasMatch(r)) return null;

    double f(double x) {
      final a = _ExpressionParser(l, variableValue: x).parse().toDouble();
      final b = _ExpressionParser(r, variableValue: x).parse().toDouble();
      return a - b;
    }

    try {
      final f0 = f(0);
      final f1 = f(1);
      final fm1 = f(-1);
      final a = (f1 + fm1 - 2 * f0) / 2;
      final b = (f1 - fm1) / 2;
      const eps = 1e-8;
      // Verify that the sampled function really is quadratic/linear before
      // returning an equation solution. This prevents a non-polynomial
      // equation from accidentally being fitted by three samples.
      final f2 = f(2);
      final predicted2 = 4 * a + 2 * b + f0;
      if (!f2.isFinite || (f2 - predicted2).abs() > eps * math.max(1, f2.abs())) return null;
      if (a.abs() < eps) {
        if (b.abs() < eps) return f0.abs() < eps ? 'المعادلة صحيحة لأي قيمة لـ x.' : 'لا يوجد حل لهذه المعادلة.';
        final x = -f0 / b;
        final check = f(x);
        if (!check.isFinite || check.abs() > 1e-6 * math.max(1, x.abs())) return null;
        return 'الحل: x = ${_fmt(x)}';
      }
      final disc = b * b - 4 * a * f0;
      if (disc < -eps) return 'لا يوجد حل حقيقي لـ x.';
      if (disc.abs() < eps) {
        final x = -b / (2 * a);
        final check = f(x);
        if (!check.isFinite || check.abs() > 1e-6 * math.max(1, x.abs())) return null;
        return 'الحل: x = ${_fmt(x)}';
      }
      final root = math.sqrt(disc);
      final x1 = (-b + root) / (2 * a);
      final x2 = (-b - root) / (2 * a);
      final check1 = f(x1);
      final check2 = f(x2);
      if (!check1.isFinite || !check2.isFinite || check1.abs() > 1e-6 * math.max(1, x1.abs()) || check2.abs() > 1e-6 * math.max(1, x2.abs())) return null;
      return 'الحلول: x₁ = ${_fmt(x1)}\nx₂ = ${_fmt(x2)}';
    } catch (_) {
      return null;
    }
  }

  static String _fmt(double x) {
    if (!x.isFinite) return 'غير معرّف';
    if ((x - x.roundToDouble()).abs() < 1e-10) return x.round().toString();
    final s = x.toStringAsFixed(12).replaceFirst(RegExp(r'0+$'), '').replaceFirst(RegExp(r'\.$'), '');
    return s == '-0' ? '0' : s;
  }
}

class AdvancedMathEngine {
  static String? solve(String raw) {
    var s = raw.trim();
    if (s.isEmpty || s.contains('=')) return null;
    s = _normalize(s);
    // Only take over when the whole input is a mathematical expression.
    if (!RegExp(r'^[0-9a-zA-Z_+\-*/^().,%!π√×÷\s]+$').hasMatch(s)) return null;
    if (!RegExp(r'[0-9)]').hasMatch(s)) return null;
    try {
      final parser = _ExpressionParser(s);
      final value = parser.parse();
      if (!value.isFinite) return null;
      final resultLine = value.isExact
          ? (value.r.d == BigInt.one
              ? 'الناتج: ${value.r.n}'
              : 'الناتج الدقيق: ${value.r.n}/${value.r.d}\nالناتج التقريبي: ${_exactDecimalPreview(value.r.n, value.r.d, 12)}')
          : 'الناتج: ${_format(value.toDouble())}';
      return '$resultLine\n\nخطوات الحل:\n'
          '1) طبّقت الأقواس وترتيب العمليات من اليمين إلى اليسار عند الأسس ومن اليسار إلى اليمين عند العمليات المتساوية.\n'
          '2) طبّقت الدوال الرياضية والنِّسب المئوية والعوامل مثل ! عند وجودها.\n'
          '3) حافظت على الدقة الكاملة بالكسور بدل التقريب المبكر طوال الحساب.';
    } catch (_) {
      return null;
    }
  }

  static String _normalize(String s) {
    const arabic = '٠١٢٣٤٥٦٧٨٩';
    const eastern = '۰۱۲۳۴۵۶۷۸۹';
    for (var i = 0; i < 10; i++) {
      s = s.replaceAll(arabic[i], '$i').replaceAll(eastern[i], '$i');
    }
    return s
        .replaceAll('×', '*')
        .replaceAll('÷', '/')
        .replaceAll('−', '-')
        .replaceAll('٪', '%')
        .replaceAll('π', 'pi')
        .replaceAll('√', 'sqrt');
  }

  static String _format(double x) {
    if ((x - x.roundToDouble()).abs() < 1e-10) return x.round().toString();
    final out = x.toStringAsFixed(12).replaceFirst(RegExp(r'0+$'), '').replaceFirst(RegExp(r'\.$'), '');
    return out == '-0' ? '0' : out;
  }
}

class _ExpressionParser {
  final List<String> tokens;
  final double? variableValue;
  int index = 0;

  _ExpressionParser(String source, {this.variableValue}) : tokens = _tokenize(source);

  static List<String> _tokenize(String s) {
    final out = <String>[];
    var i = 0;
    while (i < s.length) {
      final c = s[i];
      if (c.trim().isEmpty) {
        i++;
        continue;
      }
      if ('+-*/^(),%!'.contains(c)) {
        out.add(c);
        i++;
        continue;
      }
      if (RegExp(r'[0-9.]').hasMatch(c)) {
        var j = i;
        var dots = 0;
        while (j < s.length && RegExp(r'[0-9.]').hasMatch(s[j])) {
          if (s[j] == '.') dots++;
          if (dots > 1) throw const FormatException();
          j++;
        }
        if (j < s.length && 'eE'.contains(s[j])) {
          j++;
          if (j < s.length && '+-'.contains(s[j])) {
            j++;
          }
          final start = j;
          while (j < s.length && RegExp(r'[0-9]').hasMatch(s[j])) {
            j++;
          }
          if (j == start) throw const FormatException();
        }
        out.add(s.substring(i, j));
        i = j;
        continue;
      }
      if (RegExp(r'[A-Za-z_]').hasMatch(c)) {
        var j = i + 1;
        while (j < s.length && RegExp(r'[A-Za-z0-9_]').hasMatch(s[j])) {
          j++;
        }
        out.add(s.substring(i, j).toLowerCase());
        i = j;
        continue;
      }
      throw const FormatException();
    }
    return out;
  }

  _Val parse() {
    if (tokens.isEmpty) throw const FormatException();
    final value = _expression();
    if (index != tokens.length) throw const FormatException();
    return value;
  }

  _Val _expression() {
    var value = _term();
    while (_match('+') || _match('-')) {
      final op = tokens[index - 1];
      final rhs = _term();
      value = op == '+' ? _vAdd(value, rhs) : _vSub(value, rhs);
    }
    return value;
  }

  _Val _term() {
    var value = _power();
    while (true) {
      if (_match('*')) {
        value = _vMul(value, _power());
      } else if (_match('/')) {
        value = _vDiv(value, _power());
      } else if (_startsPrimary()) {
        // Implicit multiplication: 2(3+4), 2pi, 3sqrt(9), etc.
        value = _vMul(value, _power());
      } else {
        break;
      }
    }
    return value;
  }

  _Val _power() {
    var value = _postfix();
    if (_match('^')) value = _vPow(value, _unary());
    return value;
  }

  _Val _unary() {
    if (_match('+')) return _unary();
    if (_match('-')) return _vNeg(_unary());
    return _power();
  }

  _Val _postfix() {
    var value = _primary();
    while (true) {
      if (_match('%')) {
        value = _vDiv(value, _Val.exact(_R(BigInt.from(100), BigInt.one)));
      } else if (_match('!')) {
        value = _vFactorial(value);
      } else {
        break;
      }
    }
    return value;
  }

  _Val _primary() {
    if (_match('(')) {
      final value = _expression();
      if (!_match(')')) throw const FormatException();
      return value;
    }
    if (index >= tokens.length) throw const FormatException();
    final token = tokens[index++];
    if (RegExp(r'^[0-9]*\.?[0-9]+$').hasMatch(token)) return _Val.exact(_R.fromString(token));
    final asDouble = double.tryParse(token);
    if (asDouble != null) return _Val.approx(asDouble);
    if (token == 'x') {
      final v = variableValue;
      if (v == null) throw const FormatException();
      return _Val.approx(v);
    }
    if (token == 'pi') return _Val.approx(math.pi);
    if (token == 'e') return _Val.approx(math.e);
    if (token == 'tau') return _Val.approx(math.pi * 2);
    if (token == 'phi') return _Val.approx((1 + math.sqrt(5)) / 2);
    if (token == 'inf' || token == 'infinity') return _Val.approx(double.infinity);
    if (_functions.contains(token)) {
      _Val argument;
      if (_match('(')) {
        argument = _expression();
        if (!_match(')')) throw const FormatException();
      } else {
        argument = _unary();
      }
      return _apply(token, argument);
    }
    throw const FormatException();
  }

  static const _functions = <String>{
    'sqrt', 'cbrt', 'sin', 'cos', 'tan', 'asin', 'acos', 'atan', 'ln', 'log', 'log10', 'abs', 'exp', 'floor', 'ceil', 'round',
  };

  _Val _apply(String name, _Val v) {
    if (name == 'abs') return v.isExact ? _Val.exact(_R(v.r.n.abs(), v.r.d)) : _Val.approx(v.toDouble().abs());
    final x = v.toDouble();
    switch (name) {
      case 'sqrt':
        if (x < 0) throw const FormatException();
        if (v.isExact) {
          // Exact perfect-square/perfect-fraction shortcut (e.g. sqrt(144)=12, sqrt(1/4)=1/2).
          final ns = _isqrtExact(v.r.n);
          final ds = _isqrtExact(v.r.d);
          if (ns != null && ds != null) return _Val.exact(_R(ns, ds).norm());
        }
        return _Val.approx(math.sqrt(x));
      case 'sin':
        return _Val.approx(math.sin(x * math.pi / 180));
      case 'cos':
        return _Val.approx(math.cos(x * math.pi / 180));
      case 'tan':
        return _Val.approx(math.tan(x * math.pi / 180));
      case 'asin':
        return _Val.approx(math.asin(x) * 180 / math.pi);
      case 'acos':
        return _Val.approx(math.acos(x) * 180 / math.pi);
      case 'atan':
        return _Val.approx(math.atan(x) * 180 / math.pi);
      case 'ln':
        if (x <= 0) throw const FormatException();
        return _Val.approx(math.log(x));
      case 'log':
      case 'log10':
        if (x <= 0) throw const FormatException();
        return _Val.approx(math.log(x) / math.ln10);
      case 'exp':
        return _Val.approx(math.exp(x));
      case 'cbrt':
        return _Val.approx(x == 0 ? 0 : math.pow(x.abs(), 1 / 3) * (x < 0 ? -1 : 1));
      case 'floor':
        return _Val.approx(x.floorToDouble());
      case 'ceil':
        return _Val.approx(x.ceilToDouble());
      case 'round':
        return _Val.approx(x.roundToDouble());
      default:
        throw const FormatException();
    }
  }

  /// Exact non-negative integer square root, or null if not a perfect square.
  static BigInt? _isqrtExact(BigInt n) {
    if (n < BigInt.zero) return null;
    if (n == BigInt.zero) return BigInt.zero;
    var x = n;
    var y = (x + BigInt.one) ~/ BigInt.two;
    while (y < x) {
      x = y;
      y = (x + n ~/ x) ~/ BigInt.two;
    }
    return x * x == n ? x : null;
  }

  bool _match(String token) {
    if (index < tokens.length && tokens[index] == token) {
      index++;
      return true;
    }
    return false;
  }

  bool _startsPrimary() {
    if (index >= tokens.length) return false;
    final t = tokens[index];
    return t == '(' || double.tryParse(t) != null || t == 'x' || t == 'pi' || t == 'e' || t == 'tau' || t == 'phi' || _functions.contains(t);
  }
}

class Api {
  String? gemini = _buildGeminiApiKey.isEmpty ? null : _buildGeminiApiKey;
  String? groq = _buildGroqApiKey.isEmpty ? null : _buildGroqApiKey;
  String? backend;
  String? token;
  String? userName;
  String? userEmail;
  String preferredLanguage = 'auto';
  String? fallbackImageEndpoint;
  http.Client httpClient = http.Client();
  final Dio dio = Dio(BaseOptions(connectTimeout: const Duration(seconds: 20), receiveTimeout: const Duration(seconds: 120)));
  CancelToken _dioCancel = CancelToken();

  /// Aborts whatever Gemini/Groq/backend/image request is currently in
  /// flight (used by the Stop button) and swaps in fresh tokens/clients so
  /// future requests still work.
  void cancelActive() {
    httpClient.close();
    httpClient = http.Client();
    if (!_dioCancel.isCancelled) _dioCancel.cancel('تم الإيقاف بواسطة المستخدم.');
    _dioCancel = CancelToken();
  }

  Map<String, String> _authHeaders() => token == null || token!.isEmpty
      ? {'Content-Type': 'application/json'}
      : {'Content-Type': 'application/json', 'Authorization': 'Bearer $token'};

  Future<Map<String, dynamic>> login(String email, String password) async {
    final base = (backend ?? '').replaceAll(RegExp(r'/$'), '');
    if (base.isEmpty) throw Exception('أضف رابط Backend أولًا.');
    final r = await httpClient.post(Uri.parse('$base/auth/login'), headers: {'Content-Type': 'application/json'}, body: jsonEncode({'email': email, 'password': password})).timeout(const Duration(seconds: 30));
    final d = jsonDecode(r.body);
    if (r.statusCode < 200 || r.statusCode > 299) throw Exception(d['error'] ?? 'فشل تسجيل الدخول.');
    token = '${d['token']}'; userName = '${d['user']?['name'] ?? ''}'; userEmail = '${d['user']?['email'] ?? email}';
    return Map<String, dynamic>.from(d);
  }

  Future<Map<String, dynamic>> register(String name, String email, String password) async {
    final base = (backend ?? '').replaceAll(RegExp(r'/$'), '');
    if (base.isEmpty) throw Exception('أضف رابط Backend أولًا.');
    final r = await httpClient.post(Uri.parse('$base/auth/register'), headers: {'Content-Type': 'application/json'}, body: jsonEncode({'name': name, 'email': email, 'password': password})).timeout(const Duration(seconds: 30));
    final d = jsonDecode(r.body);
    if (r.statusCode < 200 || r.statusCode > 299) throw Exception(d['error'] ?? 'فشل إنشاء الحساب.');
    token = '${d['token']}'; userName = '${d['user']?['name'] ?? name}'; userEmail = '${d['user']?['email'] ?? email}';
    return Map<String, dynamic>.from(d);
  }

  Future<Map<String, dynamic>> usage() async {
    final base = (backend ?? '').replaceAll(RegExp(r'/$'), '');
    final r = await httpClient.get(Uri.parse('$base/usage'), headers: _authHeaders()).timeout(const Duration(seconds: 20));
    final d = jsonDecode(r.body);
    if (r.statusCode < 200 || r.statusCode > 299) throw Exception(d['error'] ?? 'تعذر قراءة الاستخدام.');
    return Map<String, dynamic>.from(d);
  }

  int? _requestedWordCount(String text) {
    final patterns = [
      RegExp(r'(?:جملة|نص|إجابة|كلام)[^0-9]{0,80}(?:تتكون|تكون|من)\s*(\d+)\s*كلم(?:ة|ات)', caseSensitive: false),
      RegExp(r'(?:بالضبط|فقط|من)\s*(\d+)\s*كلمة', caseSensitive: false),
      RegExp(r'(?:exactly|exact)\s*(\d+)\s*words?', caseSensitive: false),
      RegExp(r'\b(\d+)\s+words?\b', caseSensitive: false),
    ];
    for (final p in patterns) { final m = p.firstMatch(text); if (m != null) { final value = m.group(1); if (value != null) return int.tryParse(value); } }
    return null;
  }

  int _wordCount(String text) => text.trim().split(RegExp(r'\s+')).where((x) => x.isNotEmpty).length;

  Future<Reply> _repairWordCount(String question, List<Msg> history, bool web, Reply reply) async {
    final target = _requestedWordCount(question);
    if (target == null || _wordCount(reply.text) == target) return reply;
    final instruction = 'أعد صياغة الإجابة التالية لتكون $target كلمة بالضبط، لا أكثر ولا أقل. حافظ على المعنى. أعد النص النهائي فقط دون شرح.\nالسؤال: $question\nالإجابة: ${reply.text}';
    try {
      final repaired = await _gemini(instruction, history, false, null);
      if (_wordCount(repaired.text) == target) return Reply(repaired.text.trim(), reply.sources);
    } catch (_) {}
    try {
      final repaired = await _groq(instruction, history);
      return Reply(repaired.text.trim(), reply.sources);
    } catch (_) {}
    return reply;
  }

  Future<Reply> ask(String q, List<Msg> history, bool web, String? file) async {
    if (file != null) {
      final reason = _unsupportedFileReason(file);
      if (reason != null) throw Exception(reason);
    }
    if (file == null) {
      final smartMath = SmartMathEngine.solve(q);
      if (smartMath != null) return Reply(smartMath, const []);
      final exactMath = MathEngine.solve(q);
      if (exactMath != null) return Reply(exactMath, const []);
      final advancedMath = AdvancedMathEngine.solve(q);
      if (advancedMath != null) return Reply(advancedMath, const []);
    }

    // Provider chain: Gemini (with Google Search when enabled) → optional
    // secure backend → Groq GPT-OSS/Qwen fallback. A temporary provider
    // failure should not make the whole app unusable.
    Object? lastError;
    if ((backend ?? '').trim().isNotEmpty && (token ?? '').trim().isNotEmpty) {
      try { return await _repairWordCount(q, history, web, await _backend(q, history, web, file)); } catch (e) { lastError = e; }
    }
    if ((gemini ?? '').trim().isNotEmpty) {
      try {
        return await _repairWordCount(q, history, web, await _gemini(q, history, web, file));
      } catch (e) {
        lastError = e;
      }
    }

    if ((backend ?? '').trim().isNotEmpty && (token ?? '').trim().isEmpty) {
      try { return await _repairWordCount(q, history, web, await _backend(q, history, web, file)); } catch (e) { lastError = e; }
    }

    if ((groq ?? '').trim().isNotEmpty) {
      try {
        return await _repairWordCount(q, history, web, await _groq(q, history, file: file));
      } catch (e) {
        lastError = e;
      }
    }

    throw Exception(lastError?.toString().replaceFirst('Exception: ', '') ??
        'أضف مفتاح Gemini أو Groq أو رابط Backend من الإعدادات.');
  }

  Future<Reply> _backend(String q, List<Msg> history, bool web, String? file) async {
    final request = http.MultipartRequest(
      'POST',
      Uri.parse('${backend!.replaceAll(RegExp(r'/$'), '')}/chat'),
    );
    request.headers['Authorization'] = 'Bearer ${token ?? ''}';
    request.fields['message'] = q;
    request.fields['web_search'] = '$web';
    request.fields['history'] = jsonEncode(history
        .take(18)
        .map((m) => {'role': m.user ? 'user' : 'assistant', 'text': m.text})
        .toList());
    if (file != null) request.files.add(await http.MultipartFile.fromPath('file', file));
    final response = await httpClient.send(request).timeout(const Duration(seconds: 120));
    final raw = await response.stream.bytesToString();
    final data = jsonDecode(raw);
    if (response.statusCode < 200 || response.statusCode > 299) {
      throw Exception(data['error'] ?? 'Backend error');
    }
    return Reply(
      '${data['reply'] ?? ''}',
      (data['sources'] as List? ?? const []).map((e) => '$e').where(_isUrl).toList(),
    );
  }

  Future<Reply> _gemini(String q, List<Msg> history, bool web, String? file) async {
    final contents = <Map<String, dynamic>>[];
    for (final m in history.take(18)) {
      contents.add({'role': m.user ? 'user' : 'model', 'parts': [{'text': m.text}]});
    }
    final parts = <Map<String, dynamic>>[{'text': q}];
    if (file != null) {
      final bytes = await File(file).readAsBytes();
      if (bytes.length > 18 * 1024 * 1024) throw Exception('الملف أكبر من 18MB.');
      parts.add({'inline_data': {'mime_type': _mime(file), 'data': base64Encode(bytes)}});
    }
    contents.add({'role': 'user', 'parts': parts});
    final body = <String, dynamic>{
      'systemInstruction': {'parts': [{'text': _effectiveSystem}]},
      'contents': contents,
      'generationConfig': {'temperature': 0.15, 'topP': 0.9},
    };
    if (web) body['tools'] = [{'google_search': {}}];
    final uri = Uri.parse(
      'https://generativelanguage.googleapis.com/v1beta/models/gemini-3.8-flash:generateContent?key=${Uri.encodeComponent(gemini?.trim() ?? '')}',
    );
    http.Response? response;
    for (var attempt = 0; attempt < 2; attempt++) {
      response = await httpClient
          .post(uri, headers: {'Content-Type': 'application/json'}, body: jsonEncode(body))
          .timeout(const Duration(seconds: 120));
      if (response.statusCode < 500 && response.statusCode != 429) break;
      if (attempt == 0) await Future<void>.delayed(const Duration(milliseconds: 700));
    }
    final data = jsonDecode(response!.body);
    if (response.statusCode < 200 || response.statusCode > 299) {
      throw Exception(data['error']?['message'] ?? 'Gemini error (${response.statusCode})');
    }
    final candidates = data['candidates'] as List? ?? const [];
    final partsOut = candidates.isEmpty
        ? const []
        : (candidates.first['content']?['parts'] as List? ?? const []);
    final text = partsOut.map((e) => e['text'] ?? '').join();
    return Reply(text.isEmpty ? 'لم تصل إجابة.' : text, _urls(data));
  }

  Future<Reply> _groq(String q, List<Msg> history, {String? file}) async {
    if ((groq ?? '').trim().isEmpty) throw Exception('مفتاح Groq غير موجود.');
    final image = file != null && _isImageFile(file);
    final baseMessages = <Map<String, dynamic>>[
      {'role': 'system', 'content': _effectiveSystem},
      ...history.take(18).map((m) => {
            'role': m.user ? 'user' : 'assistant',
            'content': m.text,
          }),
    ];
    if (image) {
      final imagePath = file;
      final bytes = await File(imagePath).readAsBytes();
      if (bytes.length > 10 * 1024 * 1024) throw Exception('الصورة أكبر من 10MB.');
      final dataUrl = 'data:${_mime(imagePath)};base64,${base64Encode(bytes)}';
      baseMessages.add({
        'role': 'user',
        'content': [
          {'type': 'text', 'text': q},
          {'type': 'image_url', 'image_url': {'url': dataUrl}},
        ],
      });
    } else if (file != null) {
      // Groq has no document/inline_data support like Gemini. For text-like
      // files (and now PDFs with a real text layer, extracted locally on
      // the device — no network/API needed) we inline the content as plain
      // text so the attachment isn't silently dropped. Only a genuinely
      // scanned/image-only PDF or an Office binary still needs Gemini.
      final mime = _mime(file);
      final isTextLike = mime.startsWith('text/') || mime == 'application/json';
      String? content;
      if (isTextLike) {
        content = await File(file).readAsString();
      } else if (mime == 'application/pdf') {
        content = await extractPdfText(file);
        if (content == null || content.trim().length < 20) {
          throw Exception('هذا الـ PDF يبدو صورة ممسوحة ضوئيًا بدون طبقة نص حقيقية، فلا يقدر Groq قراءته. فعّل مفتاح Gemini من الإعدادات لتحليله.');
        }
      } else {
        throw Exception('نموذج Groq الاحتياطي لا يقرأ هذا النوع من الملفات مباشرة (يحتاج مفتاح Gemini لتحليل صيغ Office). فعّل مفتاح Gemini من الإعدادات، أو أرسل الملف كنص.');
      }
      if (content.length > 15000) content = '${content.substring(0, 15000)}\n…(تم اقتصاص الملف لطوله)';
      baseMessages.add({'role': 'user', 'content': 'محتوى الملف المرفق:\n"""\n$content\n"""\n\nسؤال المستخدم: $q'});
    } else {
      baseMessages.add({'role': 'user', 'content': q});
    }

    Object? lastError;
    for (final model in const ['openai/gpt-oss-120b', 'qwen/qwen3.8-27b']) {
      try {
        final response = await httpClient
            .post(
              Uri.parse('https://api.groq.com/openai/v1/chat/completions'),
              headers: {'Authorization': 'Bearer $groq', 'Content-Type': 'application/json'},
              body: jsonEncode({
                'model': image ? 'qwen/qwen3.8-27b' : model,
                'messages': baseMessages,
                'temperature': 0.15,
                'reasoning_effort': image ? 'medium' : 'medium',
              }),
            )
            .timeout(const Duration(seconds: 120));
        final data = jsonDecode(response.body);
        if (response.statusCode < 200 || response.statusCode > 299) {
          throw Exception(data['error']?['message'] ?? 'Groq error (${response.statusCode})');
        }
        final text = '${data['choices']?[0]?['message']?['content'] ?? ''}'.trim();
        if (text.isNotEmpty) return Reply(text, const []);
        throw Exception('Groq returned an empty response.');
      } catch (e) {
        lastError = e;
        if (image) break;
      }
    }
    throw Exception(lastError?.toString().replaceFirst('Exception: ', '') ?? 'Groq error');
  }

  Future<String> _translateImagePrompt(String prompt) async {
    final clean = prompt.trim();
    if (clean.isEmpty) return clean;

    const instruction = '''
حوّل وصف الصورة التالي إلى Prompt إنجليزي احترافي جدًا لمولد صور Stable-Diffusion/Flux.
- الوصف قد يكون بأي لهجة عربية (خليجية، ليبية، مصرية...)؛ افهمه بدقة كاملة قبل الترجمة، ولا تفوّت أي تفصيل بسبب اللهجة.
- حافظ على كل العناصر والأشخاص والأماكن والألوان والأفعال التي طلبها المستخدم بدقة.
- حسّن التكوين (composition)، الإضاءة (lighting)، العمق، المنظور، والواقعية بما يناسب نوع الصورة.
- أضف كلمات تقنية تحسّن الجودة فعليًا مثل: highly detailed, sharp focus, professional photography/illustration, cinematic lighting, 8k, masterpiece — لكن فقط بما يناسب أسلوب الصورة المطلوبة (لا تفرض أسلوب تصوير واقعي على شعار أو رسمة كرتونية).
- إذا كانت صورة أشخاص أو مناظر واقعية: أضف تفاصيل إضاءة استوديو/طبيعية واقعية ودقة عالية.
- إذا كانت شعارًا (logo) أو تصميمًا مسطحًا: استخدم مصطلحات flat design, vector, clean minimal, high contrast بدل الواقعية.
- إذا كانت أنمي أو كرتون: استخدم مصطلحات anime style, cel shading, vibrant colors المناسبة.
- لا تضف أشخاصًا أو عناصر غير مطلوبة تغير معنى الصورة.
- إذا لم يحدد المستخدم أسلوبًا، اختر أسلوبًا بصريًا احترافيًا مناسبًا للوصف.
- لا تكتب شرحًا ولا عناوين ولا علامات اقتباس؛ أعد الـPrompt الإنجليزي فقط.
- لا تطلب من المولد كتابة نصوص داخل الصورة إلا إذا طلب المستخدم نصًا صراحة.
''';

    try {
      if ((gemini ?? '').trim().isNotEmpty) {
        final reply = await _gemini('$instruction\n\nوصف المستخدم:\n$clean', const [], false, null);
        if (reply.text.trim().isNotEmpty) return reply.text.trim();
      }
    } catch (_) {
      // Gemini failure is intentionally ignored here; Groq is the immediate fallback.
    }

    try {
      if ((groq ?? '').trim().isNotEmpty) {
        final reply = await _groq('$instruction\n\nوصف المستخدم:\n$clean', const []);
        if (reply.text.trim().isNotEmpty) return reply.text.trim();
      }
    } catch (_) {
      // If both translators fail, Pollinations still receives the original prompt.
    }

    return clean;
  }

  static String _pollinationsModel(String prompt) {
    final p = prompt.toLowerCase();
    final wantsText = RegExp(r'نص|كتابة|عنوان|شعار نصي|text|title|caption').hasMatch(p);
    final wantsAnime = RegExp(r'أنمي|انمي|كرتون|manga|anime|cartoon').hasMatch(p);
    final wantsLogoIllustration = RegExp(r'لوقو|لوجو|شعار|أيقونة|ايقونة|رسمة|رسم|illustration|logo|icon|vector|flat design').hasMatch(p);
    if (wantsText) return 'sd3';
    if (wantsAnime) return 'flux-anime';
    if (wantsLogoIllustration) return 'sdxl';
    return 'flux-realism';
  }

  Future<String> generateImage(String prompt, {int width = 1280, int height = 1280}) async {
    final clean = prompt.trim();
    if (clean.isEmpty) throw Exception('اكتب وصفًا للصورة أولًا.');
    final primaryModel = _pollinationsModel(clean);
    final enhanced = await _translateImagePrompt(clean);
    final safeWidth = width.clamp(512, 1536);
    final safeHeight = height.clamp(512, 1536);
    final directory = await getApplicationDocumentsDirectory();
    final path = '${directory.path}/ai_image_${DateTime.now().millisecondsSinceEpoch}.jpg';

    // Try the ideal model first, then a shrinking chain of other Pollinations
    // models if it's down/overloaded — most single-model outages recover by
    // just switching model, so this alone fixes the common case.
    final modelChain = <String>{primaryModel, 'flux', 'turbo', 'flux-realism'}.toList();
    Object? lastError;
    for (final model in modelChain) {
      try {
        final seed = math.Random().nextInt(999999999);
        final url = 'https://image.pollinations.ai/prompt/${Uri.encodeComponent(enhanced)}'
            '?model=$model&width=$safeWidth&height=$safeHeight&nologo=true&enhance=true&private=true&seed=$seed';
        await dio.download(url, path, cancelToken: _dioCancel, options: Options(responseType: ResponseType.bytes, receiveTimeout: const Duration(seconds: 45)));
        final size = await File(path).length();
        if (size < 500) throw Exception('استجابة فارغة من مولد الصور.');
        return path;
      } catch (e) {
        lastError = e;
        continue;
      }
    }

    // Last resort: an optional secondary image endpoint the user configured
    // themselves in Settings (their own key-based provider). Only used if set.
    if ((fallbackImageEndpoint ?? '').trim().isNotEmpty) {
      try {
        final base = fallbackImageEndpoint!.trim().replaceAll(RegExp(r'/$'), '');
        final url = '$base?prompt=${Uri.encodeComponent(enhanced)}&width=$safeWidth&height=$safeHeight';
        await dio.download(url, path, cancelToken: _dioCancel, options: Options(responseType: ResponseType.bytes, receiveTimeout: const Duration(seconds: 45)));
        final size = await File(path).length();
        if (size >= 500) return path;
      } catch (e) {
        lastError = e;
      }
    }
    throw Exception('تعذّر إنشاء الصورة حاليًا (كل مولدات الصور غير متاحة). حاول بعد قليل. ${lastError ?? ''}');
  }

  Future<String> generateVideo(String prompt, {String? imagePath, void Function(int percent, int completedSeconds, int totalSeconds)? onProgress}) async {
    final base = (backend ?? '').trim().replaceAll(RegExp(r'/$'), '');
    if (base.isEmpty) {
      throw Exception('توليد الفيديو يحتاج Backend مفعّلًا ومزود فيديو حقيقيًا.');
    }
    final request = http.MultipartRequest('POST', Uri.parse('$base/video/generate'));
    request.headers['Authorization'] = 'Bearer ${token ?? ''}';
    request.fields['prompt'] = prompt.trim();
    if (imagePath != null && File(imagePath).existsSync()) {
      request.files.add(await http.MultipartFile.fromPath('image', imagePath));
    }
    final response = await httpClient.send(request).timeout(const Duration(minutes: 2));
    final raw = await response.stream.bytesToString();
    final data = jsonDecode(raw);
    if (response.statusCode < 200 || response.statusCode > 299) {
      throw Exception(data['error'] ?? 'فشل بدء توليد الفيديو.');
    }
    final jobId = '${data['job_id'] ?? ''}'.trim();
    if (jobId.isEmpty) throw Exception('لم يرجع الخادم مهمة فيديو صالحة.');

    Map<String, dynamic>? statusData;
    final started = DateTime.now();
    while (DateTime.now().difference(started) < const Duration(hours: 3)) {
      await Future<void>.delayed(const Duration(seconds: 4));
      final r = await httpClient.get(
        Uri.parse('$base/video/status/${Uri.encodeComponent(jobId)}'),
        headers: _authHeaders(),
      ).timeout(const Duration(minutes: 2));
      final statusRaw = r.body;
      statusData = jsonDecode(statusRaw) as Map<String, dynamic>;
      if (r.statusCode < 200 || r.statusCode > 299) {
        throw Exception(statusData['error'] ?? 'تعذر متابعة توليد الفيديو.');
      }
      final progress = ((statusData['progress'] as num?)?.toInt() ?? 0).clamp(0, 100).toInt();
      final completed = (statusData['completed_seconds'] as num?)?.toInt() ?? 0;
      final total = (statusData['total_seconds'] as num?)?.toInt() ?? ((statusData['duration'] as num?)?.toInt() ?? 10);
      onProgress?.call(progress.clamp(0, 100), completed, total);
      final status = '${statusData['status'] ?? ''}'.toLowerCase();
      if (status == 'failed' || status == 'canceled') {
        throw Exception(statusData['error'] ?? 'فشل توليد الفيديو.');
      }
      if (status == 'succeeded') break;
    }

    if (statusData == null || '${statusData['status'] ?? ''}'.toLowerCase() != 'succeeded') {
      throw Exception('استغرق توليد الفيديو وقتًا أطول من المتوقع. حاول مرة أخرى.');
    }

    final url = '${statusData['video_url'] ?? ''}'.trim();
    if (!url.startsWith('http')) throw Exception('اكتمل التوليد لكن لم يُرجع مزود الفيديو ملفًا صالحًا.');

    // Download the MP4 into the app so the chat stores and plays the actual file,
    // rather than exposing an expiring provider URL to the user.
    final directory = await getApplicationDocumentsDirectory();
    final path = '${directory.path}/ai_video_${DateTime.now().millisecondsSinceEpoch}.mp4';
    await dio.download(
      url,
      path,
      cancelToken: _dioCancel,
      options: Options(responseType: ResponseType.bytes, receiveTimeout: const Duration(hours: 2)),
    );
    final size = await File(path).length();
    if (size < 10 * 1024) {
      try { await File(path).delete(); } catch (_) {}
      throw Exception('تم التوليد لكن ملف الفيديو الناتج غير صالح أو فارغ.');
    }
    return path;
  }

  static bool _isImageFile(String path) {
    final p = path.toLowerCase();
    return p.endsWith('.jpg') || p.endsWith('.jpeg') || p.endsWith('.png') ||
        p.endsWith('.webp') || p.endsWith('.gif');
  }

  static String _mime(String path) {
    final p = path.toLowerCase();
    if (p.endsWith('.pdf')) return 'application/pdf';
    if (p.endsWith('.png')) return 'image/png';
    if (p.endsWith('.jpg') || p.endsWith('.jpeg')) return 'image/jpeg';
    if (p.endsWith('.webp')) return 'image/webp';
    if (p.endsWith('.gif')) return 'image/gif';
    if (p.endsWith('.heic')) return 'image/heic';
    if (p.endsWith('.heif')) return 'image/heif';
    if (p.endsWith('.mp3')) return 'audio/mp3';
    if (p.endsWith('.wav')) return 'audio/wav';
    if (p.endsWith('.aac')) return 'audio/aac';
    if (p.endsWith('.ogg')) return 'audio/ogg';
    if (p.endsWith('.flac')) return 'audio/flac';
    if (p.endsWith('.m4a')) return 'audio/mp4';
    if (p.endsWith('.mp4')) return 'video/mp4';
    if (p.endsWith('.mov')) return 'video/quicktime';
    if (p.endsWith('.webm')) return 'video/webm';
    if (p.endsWith('.avi')) return 'video/x-msvideo';
    if (p.endsWith('.txt') ||
        p.endsWith('.md') ||
        p.endsWith('.csv') ||
        p.endsWith('.log') ||
        p.endsWith('.ini') ||
        p.endsWith('.yaml') ||
        p.endsWith('.yml') ||
        p.endsWith('.xml') ||
        p.endsWith('.js') ||
        p.endsWith('.ts') ||
        p.endsWith('.py') ||
        p.endsWith('.dart') ||
        p.endsWith('.java') ||
        p.endsWith('.kt') ||
        p.endsWith('.c') ||
        p.endsWith('.cpp') ||
        p.endsWith('.h') ||
        p.endsWith('.css') ||
        p.endsWith('.sql') ||
        p.endsWith('.sh')) {
      return 'text/plain';
    }
    if (p.endsWith('.json')) return 'application/json';
    if (p.endsWith('.html') || p.endsWith('.htm')) return 'text/html';
    if (p.endsWith('.docx')) return 'application/vnd.openxmlformats-officedocument.wordprocessingml.document';
    if (p.endsWith('.doc')) return 'application/msword';
    if (p.endsWith('.xlsx')) return 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet';
    if (p.endsWith('.xls')) return 'application/vnd.ms-excel';
    if (p.endsWith('.pptx')) return 'application/vnd.openxmlformats-officedocument.presentationml.presentation';
    if (p.endsWith('.ppt')) return 'application/vnd.ms-powerpoint';
    if (p.endsWith('.rtf')) return 'application/rtf';
    return 'application/octet-stream';
  }

  /// Only true archive formats are blocked up front — Gemini genuinely
  /// cannot extract text/vision from a compressed container. Office formats
  /// are sent through with their real mime type instead of being
  /// pre-emptively assumed unsupported, since document-format support on
  /// the provider side keeps expanding.
  static const _unsupportedExtensions = ['.zip', '.rar', '.7z'];

  static String? _unsupportedFileReason(String path) {
    final p = path.toLowerCase();
    for (final ext in _unsupportedExtensions) {
      if (p.endsWith(ext)) {
        return 'صيغة $ext (أرشيف مضغوط) غير مدعومة للتحليل المباشر. فك الضغط وأرسل الملفات بداخله كل واحد لحاله.';
      }
    }
    return null;
  }

  static bool _isUrl(String value) => value.startsWith('https://') || value.startsWith('http://');

  static List<String> _urls(dynamic root) {
    final found = <String>{};
    void walk(dynamic value) {
      if (value is Map) {
        for (final entry in value.entries) {
          if (entry.value is String && _isUrl(entry.value as String)) {
            found.add(entry.value as String);
          }
          walk(entry.value);
        }
      } else if (value is List) {
        for (final item in value) {
          walk(item);
        }
      }
    }
    walk(root);
    return found.take(16).toList();
  }

  static const _langNames = {
    'ar': 'العربية',
    'en': 'English',
    'fr': 'Français',
    'es': 'Español',
    'tr': 'Türkçe',
    'ur': 'اردو',
  };

  String get _effectiveSystem {
    if (preferredLanguage == 'auto' || !_langNames.containsKey(preferredLanguage)) return _system;
    return '$_system\nملاحظة: اختار المستخدم لغته المفضلة في إعدادات التطبيق: ${_langNames[preferredLanguage]}. رد بهذه اللغة افتراضيًا، إلا إذا كتب المستخدم بلغة أخرى صراحة، فحينها رد بلغته الفعلية.';
  }

  static const _system = '''
أنت AI Assistant عربي متقدم جدًا، هدفك تقديم إجابات دقيقة وعملية ومفهومة.
- افهم السؤال كاملًا قبل الإجابة، وتتبع السياق والمعلومات التي ذكرها المستخدم سابقًا في نفس المحادثة.
- أجب بلغة المستخدم، والعربية هي الافتراضية، ولا تغيّر معنى السؤال لمجرد تبسيطه.
- اللغات واللهجات: افهم وتفاعل بطلاقة مع جميع اللهجات العربية (الخليجية، الليبية، المصرية، الشامية، المغربية، السودانية، العراقية...) وبأي لغة عالمية أخرى يكتب بها المستخدم (إنجليزية، فرنسية، إسبانية، تركية، إلخ)، وحاول الرد بنفس اللهجة أو اللغة التي يستخدمها المستخدم قدر الإمكان بدل الفصحى الجامدة إذا كتب بلهجة.
- مرجع لهجة ليبية (لا تخمّن معناها من الفصحى): «نبي/نبغي»=أريد، «عايز»=أريد، «دير/ديري لي»=اعمل لي، «شنو/شنهو»=ماذا، «كيفاش»=كيف، «وقتاش»=متى، «علاش»=لماذا، «هذاك/هذيك»=ذلك/تلك، «برشة»=كثير جدًا، «زعمة»=يعني/أظن، «توا/هسة»=الآن، «ماشي»=حسنًا، «صاير»=حاصل، «بطل»=توقف، «حوس»=دوّر/ابحث، «فيسع»=بسرعة، «نتاعي/نتاعك»=خاصتي/خاصتك، «هالبا/يمكن»=ربما، «قاعد»=(فعل مضارع مستمر، مثل "قاعد ناكل"=أنا آكل الآن)، «واحد» تُستخدم كأداة تنكير قبل الاسم (مثل "واحد راجل"=رجل ما)، «-ش» تُضاف لنفي الفعل أحيانًا مع «ما» (مثل "ما نعرفش"=لا أعرف). الأفعال بصيغة المتكلم غالبًا تبدأ بـ«ن» (نمشي=أذهب، نحب=أحب) لا بالتاء أو الهمزة.
- إذا طلب المستخدم صراحة أن تتكلم أنت باللهجة الليبية (أو أي لهجة أخرى)، فهذا أصعب من مجرد فهمها: لا تكتفِ باستبدال كلمة أو كلمتين وسط جملة فصحى، بل غيّر بنية الجملة نفسها لتطابق قواعد اللهجة (تصريف الأفعال، أدوات النفي والاستفهام) بالكامل، واحرص على الاتساق طوال الرد كله لا سطر واحد فقط. إذا شعرت بعدم يقين من صياغة معينة، اختر أبسط تعبير ليبي شائع بدل تركيب فصيح مموّه بكلمات ليبية.
- مرجع لهجة خليجية: «أبغى/أبي»=أريد، «شلون»=كيف، «وش/ايش»=ماذا، «ليش»=لماذا، «وايد/كثير»=كثير، «الحين»=الآن، «زين»=حسنًا/جيد، «شوي»=قليلًا، «يبيلك»=يحتاج، «خوش»=جيد، «مو»=ليس.
- مرجع لهجة مصرية: «عايز/عاوز»=أريد، «إزاي»=كيف، «ليه»=لماذا، «فين»=أين، «إمتى»=متى، «كده»=هكذا، «خالص»=أبدًا/تمامًا، «دلوقتي»=الآن، «مش»=ليس.
- مرجع لهجة شامية (سورية/لبنانية/أردنية/فلسطينية): «بدي»=أريد، «كيفك»=كيف حالك، «شو»=ماذا، «ليش»=لماذا، «وين»=أين، «هلق»=الآن، «كتير»=كثير، «منيح»=جيد.
- مرجع لهجة مغاربية (مغربية/جزائرية/تونسية): «بغيت»=أريد، «كيفاش»=كيف، «علاش»=لماذا، «فين»=أين، «دابا»=الآن، «بزاف»=كثير، «واخا»=حسنًا، «مزيان»=جيد.
هذه قائمة مرجعية أساسية لا شاملة؛ استخدمها كأرضية ثابتة، وفي أي كلمة لهجة أخرى غير مذكورة هنا اعتمد على السياق الكامل للجملة لفهمها بدقة بدل تعميم الفصحى عليها، واسأل توضيحًا فقط عند غموض حقيقي لا يُحل بالسياق.
- كن عميقًا في التفكير قبل الإجابة: افحص كل الاحتمالات الممكنة، تحقق من افتراضاتك، ولا تكتفِ بأول إجابة تخطر ببالك إذا كان السؤال يحتمل خطأ أو تعقيدًا. الدقة أهم من السرعة.
- الرياضيات: تعامل معها كآلة حاسبة دقيقة لا كمسألة تخمين. طبّق ترتيب العمليات، الأقواس، الإشارات، والكسور، وراجع الناتج قبل عرضه. عند المسائل الهندسية استخدم رموزًا طبيعية واضحة مثل ∠ABC و60° و△ABC وπ و√ و× و÷. ممنوع عرض LaTeX بين علامات الدولار أو وضع علامة الدولار حول الأرقام أو المعادلات. إذا كانت المسألة معقدة، اعرض خطوات الحساب الفعلية لا كلامًا عامًا.
- العلوم والبرمجة: تعامل مع الفيزياء والكيمياء والأحياء والبرمجة بنفس الصرامة — استخدم القوانين والوحدات الصحيحة (SI عند عدم تحديد غير ذلك)، تحقق من أبعاد الوحدات (dimensional analysis) في مسائل الفيزياء، وازن المعادلات الكيميائية فعليًا قبل عرضها، واختبر منطق الكود ذهنيًا سطرًا سطرًا قبل تقديمه. لا تقدّم إجابة "تبدو صحيحة" دون التحقق الفعلي منها؛ إذا لم تكن متأكدًا 100%، قل ذلك صراحة بدل تخمين واثق.
- إذا كانت المسألة رقمية بحتة، افحصها حسابيًا أولًا قبل إعطاء شرح لغوي. إذا كان هناك أكثر من تفسير، اذكر الافتراض بدل اختراع معلومة.
- الهندسة: ميّز بين الزاوية، القوس، المثلث، الضلع، المحيط، المساحة، التشابه، التطابق، والدائرة، واستخدم الوحدات والدرجات ° بشكل صحيح.
- المنطق والاستدلال: تتبع الحالة الزمنية والمكانية لكل جسم. لا تفترض أن جسمًا فوق جسم انتقل معه عندما نُقل الجسم السفلي، إلا إذا نص السؤال على ذلك. اشرح سلسلة الاستنتاج باختصار واضح.
- الصور: إذا سأل المستخدم «تقدر تسوي صور؟» أو «هل تستطيع تصميم صورة؟» فأجب بوضوح «نعم، أقدر» ثم اطلب وصف الصورة أو نفّذ إنشاء الصورة عندما يطلب ذلك. توليد الصور في التطبيق يتم عبر Pollinations وتظهر الصورة نفسها داخل المحادثة تلقائيًا. ممنوع منعًا باتًا أن تكتب رابط صورة (مثل رابط Pollinations أو أي رابط صورة آخر) كنص عادي؛ التطبيق هو من يعرض الصورة، وليس عليك أنت ذكر رابطها أبدًا.
- ذاكرة الصور: عندما يسأل المستخدم عن صورة سابقة («مين اللي بالصورة؟»، «الصورة اللي قبل هذي؟»، «الصورة الأولى اللي سويتها؟») تتبّع سجل المحادثة بعناية وحدد بالضبط أي طلب نص كان مرتبطًا بأي صورة حسب ترتيبها الزمني، وأجب بناءً على وصف ذلك الطلب تحديدًا، لا آخر صورة فقط. إذا لم تستطع تحديد أي صورة يقصد بثقة، اسأله ليوضح أيّ صورة بالضبط بدل التخمين.
- البحث والروابط: البحث على الويب مفعّل تلقائيًا. عندما يطلب المستخدم رابطًا (تطبيق، لعبة، خدمة، موقع...) استخدم البحث المتاح وأعطِ روابط حقيقية قابلة للفتح فعليًا بالنقر، ولا تخترع روابط أبدًا. عند طلب تطبيق أو لعبة، ابحث عن صفحة Google Play (أو App Store عند الحاجة) الرسمية وأعد رابطها المباشر؛ وعند طلب خدمة أو شركة، أعطِ الموقع الرسمي. لا يكفي أن تذكر اسم المصدر فقط دون رابط قابل للفتح عندما يكون الرابط متاحًا. إذا كنت تعمل عبر Groq كبديل، لا تدّعِ أنك أجريت بحثًا مباشرًا إذا لم تكن أداة البحث متاحة لك.
- عند البحث، لا تكتفِ بذكر اسم المصدر: اعرض الروابط التي أعادها البحث عندما تكون مفيدة، وميّز بين المصدر الرسمي والمصدر الإخباري/التوثيقي.
- الملفات والصور: حلل المرفق فعليًا، واستخرج الجداول والنصوص والأرقام والأخطاء المهمة قدر الإمكان. إذا كان الملف كبيرًا أو جزء منه غير قابل للقراءة، اذكر ذلك بدل التخمين.
- عند الإجابات العلمية: ميّز بين حقيقة معروفة، حساب، واستنتاج. إذا كانت البيانات ناقصة، اذكر الافتراضات بوضوح.
- في الأسئلة المعقدة: قسّم المشكلة إلى خطوات، افحص النتيجة مرة ثانية، ثم قدّم الخلاصة بوضوح دون حشو.
- إذا طلب المستخدم عددًا محددًا من الكلمات، احترم العدد المطلوب تمامًا بعد عد الكلمات وإعادة المراجعة.
- لا تستخدم عناوين مثل ### أو تنسيقًا غريبًا؛ اكتب بتنسيق نظيف وطبيعي مثل مساعد محادثة حديث. عند مقارنة بيانات (دول، أسعار، مواصفات...) استخدم جدول Markdown حقيقي (| عمود | عمود |) لأن التطبيق يعرضه كجدول منسّق فعليًا. كن مباشرًا ومختصرًا بدون حشو أو تكرار أو مقدمات طويلة غير ضرورية — أجب على السؤال مباشرة ثم أضف التفاصيل المفيدة فقط.
- إذا سأل المستخدم عن صانع التطبيق أو مطوره، قل: «صانع هذا التطبيق هو المبرمج علي أحمد قرباج (Ali Ahmed Gorbaj)، وهو مبرمج يطوّر تطبيقات مثل هذا التطبيق.» ولا تخترع اسمًا آخر.
- إذا كان السؤال يحتاج معلومات حديثة والبحث متاح، اعتمد على نتائج البحث لا على الذاكرة وحدها، وأدرج المصادر القابلة للفتح.
- لا تدّعي استخدام أداة أو مصدر أو تنفيذ عملية لم تستخدمها فعليًا.
- البرمجة: أعطِ حلولًا قابلة للتطبيق، وانتبه للنسخ والتوافق والأخطاء الشائعة.
- كن صريحًا بشأن حدود الأدوات أو المعلومات. لا تدّعِ تنفيذ عملية لم تنفذها.
- لا تكرر السؤال بلا داعٍ. إذا كانت المهمة واضحة، نفذها مباشرة.
''';
}

class ChatPage extends StatefulWidget {
  const ChatPage({super.key});
  @override
  State<ChatPage> createState() => _ChatPageState();
}

class _ChatPageState extends State<ChatPage> {
  final api = Api();
  final input = TextEditingController();
  final scroll = ScrollController();
  final picker = ImagePicker();
  final speech = stt.SpeechToText();
  final tts = FlutterTts();
  final sessions = <ChatSession>[];

  int active = 0;
  bool busy = false;
  String statusText = 'أفكر…';
  bool _cancelledByUser = false;
  bool web = true; // Web search is ON by default.
  bool listening = false;
  String heard = '';
  String? file;
  final Set<Msg> _animated = {};

  ChatSession get chat => sessions[active];

  @override
  void initState() {
    super.initState();
    _load();
    tts.setLanguage('ar');
    tts.setSpeechRate(.48);
    tts.setVolume(1.0);
  }

  @override
  void dispose() {
    input.dispose();
    scroll.dispose();
    tts.stop();
    super.dispose();
  }

  Future<void> _load() async {
    final prefs = await SharedPreferences.getInstance();
    final savedGemini = prefs.getString('gemini');
    final savedGroq = prefs.getString('groq');
    api.gemini = (savedGemini != null && savedGemini.trim().isNotEmpty) ? savedGemini : (_buildGeminiApiKey.isEmpty ? null : _buildGeminiApiKey);
    api.groq = (savedGroq != null && savedGroq.trim().isNotEmpty) ? savedGroq : (_buildGroqApiKey.isEmpty ? null : _buildGroqApiKey);
    api.backend = prefs.getString('backend');
    api.token = prefs.getString('auth_token');
    api.userName = prefs.getString('user_name');
    api.userEmail = prefs.getString('user_email');
    web = prefs.getBool('web_search') ?? true;
    api.preferredLanguage = prefs.getString('preferred_language') ?? 'auto';
    api.fallbackImageEndpoint = prefs.getString('fallback_image_endpoint');
    final onboarded = prefs.getBool('onboarded') ?? false;
    final savedTheme = prefs.getString('theme_mode');
    themeModeNotifier.value = switch (savedTheme) {
      'light' => ThemeMode.light,
      'dark' => ThemeMode.dark,
      _ => ThemeMode.system,
    };
    accentPresetNotifier.value = prefs.getString('accent_preset') ?? 'claude';
    final raw = prefs.getString('chats');
    if (raw != null) {
      try {
        sessions.addAll((jsonDecode(raw) as List).map((e) => ChatSession.fromJson(Map<String, dynamic>.from(e))));
      } catch (_) {}
    }
    if (sessions.isEmpty) _newChat(save: false);
    if (mounted) setState(() {});
    if (!onboarded && mounted) {
      WidgetsBinding.instance.addPostFrameCallback((_) => _pickLanguage(firstLaunch: true));
    }
  }

  Future<void> _pickLanguage({bool firstLaunch = false}) async {
    final options = <String, String>{'auto': 'تلقائي (حسب لغتي)', 'ar': 'العربية', 'en': 'English', 'fr': 'Français', 'es': 'Español', 'tr': 'Türkçe', 'ur': 'اردو'};
    final choice = await showDialog<String>(
      context: context,
      barrierDismissible: !firstLaunch,
      builder: (dialogContext) => AlertDialog(
        title: Text(firstLaunch ? 'Choose your language / اختر لغتك' : 'اللغة المفضلة'),
        content: SizedBox(
          width: double.maxFinite,
          child: ListView(
            shrinkWrap: true,
            children: options.entries
                .map((e) => RadioListTile<String>(
                      value: e.key,
                      groupValue: api.preferredLanguage,
                      title: Text(e.value),
                      onChanged: (v) => Navigator.pop(dialogContext, v),
                    ))
                .toList(),
          ),
        ),
      ),
    );
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('onboarded', true);
    if (choice != null) {
      api.preferredLanguage = choice;
      await prefs.setString('preferred_language', choice);
    }
    if (mounted) setState(() {});
  }

  Future<void> _save() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('chats', jsonEncode(sessions.map((c) => c.toJson()).toList()));
    await prefs.setBool('web_search', web);
  }

  void _newChat({bool save = true}) {
    final id = DateTime.now().microsecondsSinceEpoch.toString();
    sessions.insert(0, ChatSession(id: id, title: 'محادثة جديدة'));
    active = 0;
    input.clear();
    file = null;
    if (save) _save();
    if (mounted) setState(() {});
  }

  void _selectChat(int index) {
    setState(() {
      active = index;
      input.clear();
      file = null;
    });
    Navigator.of(context).pop();
    _jump();
  }

  Future<void> _deleteChat(int index) async {
    if (sessions.length == 1) {
      sessions[0].title = 'محادثة جديدة';
      sessions[0].messages.clear();
      active = 0;
    } else {
      sessions.removeAt(index);
      if (active >= sessions.length) active = sessions.length - 1;
    }
    await _save();
    if (mounted) setState(() {});
  }

  void _jump() => WidgetsBinding.instance.addPostFrameCallback((_) {
        if (scroll.hasClients) {
          scroll.animateTo(
            scroll.position.maxScrollExtent,
            duration: const Duration(milliseconds: 250),
            curve: Curves.easeOut,
          );
        }
      });

  bool _looksLikeImageQuestion(String text) {
    final s = text.toLowerCase();
    return RegExp(r'(هذي|هذه|ذي|هاذي|نفس)?\s*(الصورة|صورتك|صورتي)|(من|مين|منو|ايش|إيش|وش|شنو|شنهو|ما هذا|ماهذا|what|who).{0,15}(بالصورة|في الصورة|الصورة)').hasMatch(s);
  }

  String? _mostRecentImage(List<Msg> history) {
    for (var i = history.length - 1; i >= 0; i--) {
      final m = history[i];
      if (m.image != null) return m.image;
      if (m.file != null && Api._isImageFile(m.file!)) return m.file;
    }
    return null;
  }

  bool _isVideoCapabilityQuestion(String text) {
    final s = text.toLowerCase().trim();
    final asksCapability = RegExp(r'(^(هل\s*)?|\b)(تقدر|تستطيع|تقدرين|تقدرون|يقدر|يقدرون|ممكن|هل يمكن|can you|are you able to|do you support|هل عندك)\b').hasMatch(s);
    final explicitCreation = RegExp(r'(سويلي|سوّيلي|سوي لي|سوّي لي|سوي لنا|سوّي لنا|اعملي|اعمل لي|اعمل لنا|أنشئ لي|انشئ لي|اصنع لي|اصنعلي|اصنع لنا|ديرلي|دير لي|ديرلنا|ديريلي|ديري لي|نبّيْك|نبيك\s+(تدير|تسوي|تعمل)|نبغيك\s+(تسوي|تعمل)|أبيك\s+(تسوي|تعمل)|ابيك\s+(تسوي|تعمل)|بديك\s+(تعمل|تسوي)|عايزك\s+(تعمل|تسوي)|محتاجك\s+(تعمل|تسوي)|generate|create|make|generate me|make me)').hasMatch(s);
    return asksCapability && !explicitCreation && RegExp(r'(فيديو|فديو|مقطع|مقطع فيديو|video|clip|movie)').hasMatch(s);
  }

  bool _looksLikeVideoRequest(String text) {
    final s = text.toLowerCase().trim();
    if (_isVideoCapabilityQuestion(s)) return false;
    final hasVideo = RegExp(r'(فيديو|فديو|مقطع|مقطع فيديو|video|clip|movie)').hasMatch(s);
    final hasCreation = RegExp(r'(سوي|سوّي|سويلي|سوّيلي|سوي لي|سوّي لي|سوي لنا|سوّي لنا|اعمل|اعملي|اعمل لي|اعمل لنا|أنشئ|انشئ|أنشئ لي|انشئ لي|صمم|صمّم|صمملي|صمم لي|ولد|ولّد|ولدي|ولّدلي|اصنع|اصنعلي|اصنع لي|اصنع لنا|نبي|نبغي|نبِّي|نحب|نحبلك|بدي|ابي|أبي|أبغى|ابغى|ودي|دير|ديرلي|دير لي|ديري|ديريلي|ديري لي|ديرلنا|سويلنا|بغيتك|بغيت|عايزك|عايز|محتاجك|نبغيك|أبيك|ابيك|بديك|نبيك|generate|create|make|generate me|make me|animate)').hasMatch(s);
    final hasVideoDescription = RegExp(r'^(فيديو|فديو|مقطع)(\s+عن|\s+ل|\s+في|\s+من|\s+حيث)').hasMatch(s);
    return hasVideo && (hasCreation || hasVideoDescription);
  }

  bool _looksLikeImageRequest(String text) {
    final s = text.toLowerCase();
    final verbNounPattern = RegExp(
      r'(اصنع|اصنعلي|سوي|سوّي|سويلي|سوّيلي|اعمل|اعملي|أنشئ|انشئ|صمم|صمّم|صممي|صممّلي|ارسم|ارسملي|ولّد|ولد|وريني|ورني|عطني|أعطني|جيب|جيبلي|ابغى|أبغى|ابي|أبي|ابغالي|احتاج|بغيت|دشلي|نبي|نبغي|نحب|حاب|حابب|عايز|عايزلي|دير|ديرلي|ديري|ديريلي|نتاعي|generate|create|draw|design|make me|paint).{0,25}(صورة|صور|رسمة|رسوم|خلفية|خلفيه|لوقو|لوجو|شعار|بوستر|ملصق|أيقونة|ايقونة|image|picture|art|logo|poster|wallpaper|icon)',
    );
    final startsWithNoun = RegExp(r'^(صورة|صوره|رسمة|رسمة كرتونية|خلفية|خلفيه|لوقو|لوجو|شعار|بوستر|image|logo|wallpaper)\b');
    return verbNounPattern.hasMatch(s) || startsWithNoun.hasMatch(s);
  }

  Future<void> send([String? preset, String? presetFile]) async {
    if (busy) return;
    final q = (preset ?? input.text).trim();
    final attached = presetFile ?? file;
    if (q.isEmpty && attached == null) return;
    input.clear();
    file = null;
    final userText = q.isEmpty ? 'حلل الملف المرفق.' : q;
    final before = List<Msg>.from(chat.messages);
    final videoRequest = attached == null && _looksLikeVideoRequest(userText);
    final imageRequest = attached == null && !videoRequest && _looksLikeImageRequest(userText);
    var apiFile = attached;
    if (apiFile == null && !imageRequest && _looksLikeImageQuestion(userText)) {
      apiFile = _mostRecentImage(before);
    }
    setState(() {
      chat.messages.add(Msg(userText, true, file: attached));
      if (chat.title == 'محادثة جديدة') {
        chat.title = userText.replaceAll(RegExp(r'\s+'), ' ').trim();
        if (chat.title.length > 34) chat.title = '${chat.title.substring(0, 34)}…';
      }
      busy = true;
      statusText = videoRequest ? 'جاري إنشاء الفيديو…' : (imageRequest ? 'جاري إنشاء الصورة…' : (attached != null ? 'جاري رفع الملف وتحليله…' : 'أفكر…'));
    });
    _jump();
    try {
      if (videoRequest) {
        final sourceImage = attached != null && Api._isImageFile(attached) ? attached : _mostRecentImage(before);
        final url = await api.generateVideo(
          userText,
          imagePath: sourceImage,
          onProgress: (percent, completedSeconds, totalSeconds) {
            if (!mounted) return;
            setState(() {
              statusText = totalSeconds > 10
                  ? 'جاري إنشاء الفيديو… $percent% ($completedSeconds/$totalSeconds ثانية)'
                  : 'جاري إنشاء الفيديو… $percent%';
            });
          },
        );
        if (!mounted) return;
        setState(() => chat.messages.add(Msg('تم إنشاء الفيديو 🎬', false, video: url)));
      } else if (imageRequest) {
        final path = await api.generateImage(userText);
        final bytes = await File(path).readAsBytes();
        try { await Gal.putImageBytes(bytes, album: 'AI Assistant'); } catch (_) {}
        if (!mounted) return;
        setState(() => chat.messages.add(Msg('تم إنشاء الصورة 🎨', false, image: path)));
      } else {
        final reply = await api.ask(userText, before, web, apiFile);
        if (!mounted) return;
        setState(() => chat.messages.add(Msg(reply.text, false, sources: reply.sources)));
      }
    } catch (e) {
      if (!mounted) return;
      final message = _cancelledByUser ? 'تم إيقاف التوليد. تقدر تكمل من نفس المكان.' : 'حدث خطأ: ${e.toString().replaceFirst('Exception: ', '')}';
      setState(() => chat.messages.add(Msg(message, false, retryOf: userText, retryFile: attached)));
    } finally {
      _cancelledByUser = false;
      if (mounted) setState(() => busy = false);
      await _save();
      _jump();
    }
  }

  void stopGenerating() {
    if (!busy) return;
    _cancelledByUser = true;
    api.cancelActive();
  }

  Future<void> voice() async {
    if (listening) { await speech.stop(); if (mounted) setState(() => listening = false); return; }
    try {
      final micStatus = await Permission.microphone.request();
      if (!mounted) return;
      if (micStatus.isPermanentlyDenied) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
          content: const Text('صلاحية الميكروفون مرفوضة. فعّلها من إعدادات الهاتف.'),
          action: SnackBarAction(label: 'فتح الإعدادات', onPressed: openAppSettings),
        ));
        return;
      }
      if (!micStatus.isGranted) {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('يحتاج التطبيق إذن الميكروفون ليعمل التحدث الصوتي.')));
        return;
      }
      final available = await speech.initialize(
        debugLogging: false,
        onStatus: (status) {
          if (!mounted) return;
          if (status == 'notListening' || status == 'done') {
            setState(() => listening = false);
            final spoken = heard.trim();
            if (spoken.isNotEmpty) {
              heard = '';
              send(spoken);
            }
          }
        },
        onError: (error) { if (mounted) { setState(() => listening = false); ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('تعذر تشغيل الميكروفون: ${error.errorMsg}'))); } },
      );
      if (!available) {
        if (mounted) {
          showDialog<void>(
            context: context,
            builder: (_) => AlertDialog(
              title: const Text('تعرّف الكلام غير متاح'),
              content: const Text(
                'الجهاز رفض أو لا يدعم خدمة التعرف على الكلام. تأكد من:\n'
                '• منح إذن الميكروفون للتطبيق من إعدادات النظام.\n'
                '• تثبيت وتفعيل تطبيق "Google" (الذي يوفر خدمة التعرف على الصوت) على جهازك.\n'
                '• إعادة تشغيل التطبيق بعد منح الإذن.',
              ),
              actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('حسنًا'))],
            ),
          );
        }
        return;
      }
      final locales = await speech.locales();
      final arabic = locales.where((x) => x.localeId.toLowerCase().startsWith('ar')).toList();
      if (mounted) setState(() { listening = true; heard = ''; });
      await speech.listen(
        listenOptions: stt.SpeechListenOptions(
          localeId: arabic.isEmpty ? null : arabic.first.localeId,
          partialResults: true,
          autoPunctuation: true,
          cancelOnError: false,
          listenFor: const Duration(seconds: 60),
          pauseFor: const Duration(seconds: 4),
          listenMode: stt.ListenMode.dictation,
          contextualPhrases: const ['AI Assistant', 'جوجل', 'غروك', 'جيميني', 'رياضيات', 'فيزياء', 'برمجة'],
        ),
        onResult: (result) { if (!mounted) return; final value = result.recognizedWords.trim(); setState(() { heard = value; if (value.isNotEmpty) input.value = TextEditingValue(text: value, selection: TextSelection.collapsed(offset: value.length)); }); },
      );
    } catch (e) {
      if (mounted) {
        setState(() => listening = false);
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('تعذر تشغيل الميكروفون: ${e.toString().replaceFirst('Exception: ', '')}')));
      }
    }
  }

  Future<void> pickFile() async {
    final result = await FilePicker.pickFile(type: FileType.any);
    if (result?.path != null) setState(() => file = result!.path);
  }

  Future<void> pickImage(ImageSource source) async {
    final result = await picker.pickImage(source: source, imageQuality: 90, maxWidth: 2200);
    if (result != null) setState(() => file = result.path);
  }

  Future<void> draw() async {
    final controller = TextEditingController();
    String ratio = '1:1';
    final result = await showDialog<Map<String, String>>(
      context: context,
      builder: (dialogContext) => StatefulBuilder(
        builder: (context, setDialogState) => AlertDialog(
          title: const Text('🎨 إنشاء صورة'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: controller,
                autofocus: true,
                maxLines: 5,
                decoration: const InputDecoration(hintText: 'صف الصورة بالتفصيل…'),
              ),
              const SizedBox(height: 12),
              DropdownButtonFormField<String>(
                initialValue: ratio,
                decoration: const InputDecoration(labelText: 'نسبة الصورة'),
                items: const [
                  DropdownMenuItem(value: '1:1', child: Text('مربع 1:1')),
                  DropdownMenuItem(value: '16:9', child: Text('أفقي 16:9')),
                  DropdownMenuItem(value: '9:16', child: Text('عمودي 9:16')),
                ],
                onChanged: (v) => setDialogState(() => ratio = v ?? '1:1'),
              ),
            ],
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(dialogContext), child: const Text('إلغاء')),
            FilledButton(onPressed: () => Navigator.pop(dialogContext, {'prompt': controller.text.trim(), 'ratio': ratio}), child: const Text('إنشاء')),
          ],
        ),
      ),
    );
    controller.dispose();
    if (result == null || (result['prompt'] ?? '').isEmpty || busy) return;
    final prompt = result['prompt']!;
    final selectedRatio = result['ratio'] ?? '1:1';
    final dimensions = selectedRatio == '16:9'
        ? (width: 1536, height: 864)
        : selectedRatio == '9:16'
            ? (width: 864, height: 1536)
            : (width: 1024, height: 1024);
    setState(() => busy = true);
    try {
      final path = await api.generateImage(prompt, width: dimensions.width, height: dimensions.height);
      final bytes = await File(path).readAsBytes();
      await Gal.putImageBytes(bytes, album: 'AI Assistant');
      chat.messages.add(Msg('تم إنشاء الصورة وحفظها في الاستوديو 🎨\n\nالوصف: $prompt\nالنسبة: $selectedRatio', false, image: path));
    } catch (e) {
      chat.messages.add(Msg('تعذر إنشاء الصورة الآن: ${e.toString().replaceFirst('Exception: ', '')}', false));
    } finally {
      if (mounted) setState(() => busy = false);
      await _save();
      _jump();
    }
  }

  Future<void> account() async {
    final name = TextEditingController(text: api.userName ?? '');
    final email = TextEditingController(text: api.userEmail ?? '');
    final password = TextEditingController();
    bool registerMode = false;
    try {
      await showModalBottomSheet<void>(
        context: context,
        isScrollControlled: true,
        builder: (sheetContext) => StatefulBuilder(
          builder: (context, setSheetState) => Padding(
            padding: EdgeInsets.only(bottom: MediaQuery.of(sheetContext).viewInsets.bottom),
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(20),
              child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
                Text(registerMode ? 'إنشاء حساب' : 'تسجيل الدخول', style: const TextStyle(fontSize: 26, fontWeight: FontWeight.w900)),
                const SizedBox(height: 8),
                Text(api.userName == null ? 'حسابك يحفظ بيانات الاستخدام على الـBackend.' : 'مرحبًا ${api.userName}'),
                const SizedBox(height: 14),
                if (registerMode) ...[TextField(controller: name, decoration: const InputDecoration(labelText: 'الاسم')), const SizedBox(height: 10)],
                TextField(controller: email, keyboardType: TextInputType.emailAddress, decoration: const InputDecoration(labelText: 'البريد الإلكتروني')), const SizedBox(height: 10),
                TextField(controller: password, obscureText: true, decoration: const InputDecoration(labelText: 'كلمة المرور (8 أحرف على الأقل)')), const SizedBox(height: 14),
                FilledButton(
                  onPressed: () async {
                    try {
                      if (registerMode) { await api.register(name.text.trim(), email.text.trim(), password.text); }
                      else { await api.login(email.text.trim(), password.text); }
                      final prefs = await SharedPreferences.getInstance();
                      await prefs.setString('auth_token', api.token ?? '');
                      await prefs.setString('user_name', api.userName ?? '');
                      await prefs.setString('user_email', api.userEmail ?? '');
                      if (sheetContext.mounted) Navigator.pop(sheetContext);
                      if (mounted) setState(() {});
                    } catch (e) {
                      if (sheetContext.mounted) ScaffoldMessenger.of(sheetContext).showSnackBar(SnackBar(content: Text(e.toString().replaceFirst('Exception: ', ''))));
                    }
                  },
                  child: Text(registerMode ? 'إنشاء الحساب' : 'دخول'),
                ),
                TextButton(onPressed: () => setSheetState(() => registerMode = !registerMode), child: Text(registerMode ? 'لدي حساب بالفعل' : 'إنشاء حساب جديد')),
                if (api.token != null && api.token!.isNotEmpty) ...[
                  const Divider(height: 28),
                  OutlinedButton.icon(onPressed: () async { try { final u = await api.usage(); if (sheetContext.mounted) showDialog(context: sheetContext, builder: (_) => AlertDialog(title: const Text('استخدامك'), content: Text('إجمالي الطلبات: ${u['total']}\\nطلبات اليوم: ${u['today']}'), actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('إغلاق'))])); } catch (e) { if (sheetContext.mounted) ScaffoldMessenger.of(sheetContext).showSnackBar(SnackBar(content: Text(e.toString().replaceFirst('Exception: ', '')))); } }, icon: const Icon(Icons.bar_chart), label: const Text('عرض إحصائيات الاستخدام')),
                  TextButton(onPressed: () async { api.token = null; api.userName = null; api.userEmail = null; final prefs = await SharedPreferences.getInstance(); await prefs.remove('auth_token'); await prefs.remove('user_name'); await prefs.remove('user_email'); if (sheetContext.mounted) Navigator.pop(sheetContext); if (mounted) setState(() {}); }, child: const Text('تسجيل الخروج')),
                ],
              ]),
            ),
          ),
        ),
      );
    } finally { name.dispose(); email.dispose(); password.dispose(); }
  }

  Future<void> settings() async {
    final gemini = TextEditingController(text: api.gemini ?? '');
    final groq = TextEditingController(text: api.groq ?? '');
    final backend = TextEditingController(text: api.backend ?? '');
    final fallbackImg = TextEditingController(text: api.fallbackImageEndpoint ?? '');
    var localWeb = web;
    var localTheme = themeModeNotifier.value;
    var localAccent = accentPresetNotifier.value;
    await showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      builder: (sheetContext) => StatefulBuilder(
        builder: (sheetContext, setSheet) => Padding(
          padding: EdgeInsets.only(bottom: MediaQuery.of(sheetContext).viewInsets.bottom),
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                const Text('الإعدادات', style: TextStyle(fontSize: 26, fontWeight: FontWeight.w900)),
                const SizedBox(height: 10),
                FilledButton.tonalIcon(onPressed: account, icon: const Icon(Icons.person_outline), label: Text(api.token == null ? 'الحساب وتسجيل الدخول' : 'الحساب: ${api.userName ?? ''}')),
                const SizedBox(height: 10),
                FilledButton.tonalIcon(onPressed: () => _pickLanguage(), icon: const Icon(Icons.language_outlined), label: const Text('لغة الرد المفضلة')),
                const SizedBox(height: 18),
                const Text('المظهر', style: TextStyle(fontWeight: FontWeight.w800)),
                const SizedBox(height: 8),
                SegmentedButton<ThemeMode>(
                  segments: const [
                    ButtonSegment(value: ThemeMode.system, label: Text('تلقائي'), icon: Icon(Icons.brightness_auto_outlined)),
                    ButtonSegment(value: ThemeMode.light, label: Text('فاتح'), icon: Icon(Icons.light_mode_outlined)),
                    ButtonSegment(value: ThemeMode.dark, label: Text('داكن'), icon: Icon(Icons.dark_mode_outlined)),
                  ],
                  selected: {localTheme},
                  onSelectionChanged: (selection) => setSheet(() => localTheme = selection.first),
                ),
                const SizedBox(height: 14),
                const Text('لون التطبيق', style: TextStyle(fontWeight: FontWeight.w800)),
                const SizedBox(height: 8),
                Row(
                  children: [
                    for (final entry in const {'claude': 'Claude', 'ocean': 'Ocean', 'mono': 'أبيض/أسود'}.entries) ...[
                      Expanded(
                        child: InkWell(
                          borderRadius: BorderRadius.circular(14),
                          onTap: () => setSheet(() => localAccent = entry.key),
                          child: Container(
                            padding: const EdgeInsets.symmetric(vertical: 10),
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(14),
                              border: Border.all(color: localAccent == entry.key ? _accentPresets[entry.key]!.$1 : Colors.grey.withValues(alpha: .3), width: localAccent == entry.key ? 2 : 1),
                            ),
                            child: Column(
                              children: [
                                CircleAvatar(radius: 12, backgroundColor: _accentPresets[entry.key]!.$1),
                                const SizedBox(height: 6),
                                Text(entry.value, style: const TextStyle(fontSize: 11)),
                              ],
                            ),
                          ),
                        ),
                      ),
                      if (entry.key != 'mono') const SizedBox(width: 8),
                    ],
                  ],
                ),
                const SizedBox(height: 14),
                SwitchListTile(
                  contentPadding: EdgeInsets.zero,
                  title: const Text('تفعيل البحث في الويب افتراضيًا'),
                  subtitle: const Text('يمنح الردود روابط ومعلومات حديثة عند الحاجة'),
                  value: localWeb,
                  onChanged: (value) => setSheet(() => localWeb = value),
                ),
                const SizedBox(height: 14),
                const Text('مفاتيح الذكاء الاصطناعي', style: TextStyle(fontWeight: FontWeight.w800)),
                const SizedBox(height: 8),
                TextField(controller: gemini, obscureText: true, decoration: const InputDecoration(labelText: 'Gemini API Key')),
                const SizedBox(height: 10),
                TextField(controller: groq, obscureText: true, decoration: const InputDecoration(labelText: 'Groq API Key')),
                const SizedBox(height: 10),
                TextField(controller: backend, decoration: const InputDecoration(labelText: 'Backend URL')),
                const SizedBox(height: 10),
                TextField(
                  controller: fallbackImg,
                  decoration: const InputDecoration(
                    labelText: 'رابط مولد صور احتياطي (اختياري)',
                    helperText: 'يُستخدم فقط إذا فشلت كل نماذج Pollinations — اختياري تمامًا.',
                    helperMaxLines: 2,
                  ),
                ),
                const SizedBox(height: 16),
                FilledButton.icon(
                  onPressed: () async {
                    api.gemini = gemini.text.trim();
                    api.groq = groq.text.trim();
                    api.backend = backend.text.trim();
                    api.fallbackImageEndpoint = fallbackImg.text.trim();
                    themeModeNotifier.value = localTheme;
                    accentPresetNotifier.value = localAccent;
                    final prefs = await SharedPreferences.getInstance();
                    await prefs.setString('gemini', api.gemini ?? '');
                    await prefs.setString('groq', api.groq ?? '');
                    await prefs.setString('backend', api.backend ?? '');
                    await prefs.setString('fallback_image_endpoint', api.fallbackImageEndpoint ?? '');
                    await prefs.setBool('web_search', localWeb);
                    await prefs.setString('accent_preset', localAccent);
                    await prefs.setString('theme_mode', switch (localTheme) {
                      ThemeMode.light => 'light',
                      ThemeMode.dark => 'dark',
                      ThemeMode.system => 'system',
                    });
                    if (sheetContext.mounted) Navigator.pop(sheetContext);
                    if (mounted) setState(() => web = localWeb);
                  },
                  icon: const Icon(Icons.save_outlined),
                  label: const Text('حفظ الإعدادات'),
                ),
              ],
            ),
          ),
        ),
      ),
    );
    gemini.dispose();
    groq.dispose();
    backend.dispose();
    fallbackImg.dispose();
  }

  Future<void> speak(String text) async {
    await tts.stop();
    await tts.speak(prettyMath(text));
  }

  Future<void> _downloadVideoToGallery(String path) async {
    try {
      if (!File(path).existsSync()) {
        throw Exception('ملف الفيديو غير موجود على الجهاز.');
      }

      var access = await Gal.hasAccess();
      if (!access) {
        access = await Gal.requestAccess();
      }
      if (!access) {
        throw Exception('السماح بالوصول إلى الصور والفيديوهات مطلوب لحفظ الفيديو.');
      }

      await Gal.putVideo(path, album: 'AI Assistant');
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('تم تنزيل الفيديو وحفظه في المعرض 🎬')),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('تعذر تنزيل الفيديو: ${e.toString().replaceFirst('Exception: ', '')}')),
        );
      }
    }
  }

  Future<void> shareText(String text) async {
    final clean = prettyMath(text).trim();
    if (clean.isEmpty) return;
    await SharePlus.instance.share(ShareParams(text: clean, subject: 'AI Assistant'));
  }

  @override
  Widget build(BuildContext context) => Directionality(
        textDirection: TextDirection.rtl,
        child: Scaffold(
          drawer: _drawer(),
          appBar: AppBar(
            elevation: 0,
            scrolledUnderElevation: 0,
            backgroundColor: Theme.of(context).scaffoldBackgroundColor.withValues(alpha: .92),
            leading: Builder(builder: (c) => IconButton(onPressed: () => Scaffold.of(c).openDrawer(), icon: const Icon(Icons.menu_rounded))),
            title: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('AI Assistant', style: TextStyle(fontWeight: FontWeight.w900)),
                Text(chat.title, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 11)),
              ],
            ),
            actions: [
              IconButton(onPressed: () { setState(() => input.text = 'سويلي فيديو '); }, tooltip: 'إنشاء فيديو', icon: const Icon(Icons.videocam_outlined)),
              IconButton(onPressed: draw, tooltip: 'إنشاء صورة', icon: const Icon(Icons.image_outlined)),
              IconButton(onPressed: settings, tooltip: 'الإعدادات', icon: const Icon(Icons.tune_rounded)),
            ],
          ),
          body: Column(
            children: [
              Expanded(
                child: chat.messages.isEmpty
                    ? _home()
                    : ListView.builder(
                        controller: scroll,
                        padding: const EdgeInsets.fromLTRB(12, 12, 12, 18),
                        itemCount: chat.messages.length + (busy ? 1 : 0),
                        itemBuilder: (context, i) => i < chat.messages.length
                            ? _bubble(chat.messages[i])
                            : _bubble(Msg(statusText, false)),
                      ),
              ),
              _composer(),
            ],
          ),
        ),
      );

  Widget _drawer() => Drawer(
        child: SafeArea(
          child: Column(
            children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(12, 10, 12, 8),
                child: Row(
                  children: [
                    Container(
                      width: 44,
                      height: 44,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(14),
                        gradient: LinearGradient(colors: [kAccent, kAccentDeep]),
                      ),
                      child: const Icon(Icons.auto_awesome, color: Colors.white),
                    ),
                    const SizedBox(width: 10),
                    const Expanded(child: Text('محادثاتك', style: TextStyle(fontSize: 21, fontWeight: FontWeight.w900))),
                    IconButton(onPressed: () { _newChat(); Navigator.of(context).pop(); }, icon: const Icon(Icons.edit_square)),
                  ],
                ),
              ),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 12),
                child: FilledButton.icon(
                  onPressed: () { _newChat(); Navigator.of(context).pop(); },
                  style: FilledButton.styleFrom(minimumSize: const Size(double.infinity, 48)),
                  icon: const Icon(Icons.add_rounded),
                  label: const Text('محادثة جديدة'),
                ),
              ),
              const SizedBox(height: 12),
              const Divider(height: 1),
              Expanded(
                child: ListView.builder(
                  itemCount: sessions.length,
                  itemBuilder: (context, i) {
                    final selected = i == active;
                    return ListTile(
                      selected: selected,
                      leading: Icon(selected ? Icons.chat_bubble : Icons.chat_bubble_outline),
                      title: Text(sessions[i].title, maxLines: 2, overflow: TextOverflow.ellipsis),
                      onTap: () => _selectChat(i),
                      trailing: PopupMenuButton<String>(
                        onSelected: (v) {
                          if (v == 'delete') _deleteChat(i);
                        },
                        itemBuilder: (_) => const [PopupMenuItem(value: 'delete', child: Text('حذف المحادثة'))],
                      ),
                    );
                  },
                ),
              ),
              const Divider(height: 1),
              ListTile(leading: const Icon(Icons.tune), title: const Text('الإعدادات'), onTap: settings),
            ],
          ),
        ),
      );

  Widget _home() => ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Container(
            padding: const EdgeInsets.all(26),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(32),
              gradient: LinearGradient(
                colors: [
                  Theme.of(context).colorScheme.primaryContainer,
                  Theme.of(context).colorScheme.surfaceContainerHighest,
                ],
              ),
            ),
            child: const Column(
              children: [
                Icon(Icons.auto_awesome, size: 58),
                SizedBox(height: 12),
                Text('مساعدك الذكي', style: TextStyle(fontSize: 30, fontWeight: FontWeight.w900)),
                SizedBox(height: 8),
                Text('ذكاء • رياضيات • بحث وروابط • صوت • ملفات • صور • محادثات متعددة', textAlign: TextAlign.center),
              ],
            ),
          ),
          const SizedBox(height: 18),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: [
              ActionChip(label: const Text('🧮 اختبار رياضيات'), onPressed: () => send('4747+4847-3747÷3737×3737+373÷3737')),
              ActionChip(label: const Text('🧠 اختبار استدلال'), onPressed: () => send('أنا في غرفتي الآن. وضعت كتاباً على الطاولة، ثم وضعت فوق الكتاب تفاحة حمراء، وفوق التفاحة وضعت كوباً فارغاً. بعد ذلك، قمت بنقل الكتاب بعناية ووضعته داخل الخزانة، ثم أخذت الكوب الفارغ ووضعته في المطبخ. أين توجد التفاحة الحمراء الآن؟ اشرح لي خطوة بخطوة كيف توصلت لمكانها.')),
              ActionChip(label: const Text('🎨 صمّم صورة'), onPressed: draw),
              ActionChip(label: const Text('🌐 ابحث عن رابط'), onPressed: () {
                setState(() => web = true);
                input.text = 'ابحث لي عن الرابط الرسمي المناسب لهذا الشيء واذكر مصادر موثوقة.';
              }),
              ActionChip(label: const Text('📎 حلل ملف'), onPressed: pickFile),
            ],
          ),
        ],
      );

  String _extensionForLang(String lang) {
    const map = {
      'python': '.py', 'py': '.py', 'javascript': '.js', 'js': '.js', 'typescript': '.ts', 'ts': '.ts',
      'dart': '.dart', 'java': '.java', 'kotlin': '.kt', 'kt': '.kt', 'c': '.c', 'cpp': '.cpp', 'c++': '.cpp',
      'csharp': '.cs', 'cs': '.cs', 'html': '.html', 'css': '.css', 'json': '.json', 'xml': '.xml',
      'yaml': '.yaml', 'yml': '.yaml', 'sql': '.sql', 'bash': '.sh', 'sh': '.sh', 'shell': '.sh',
      'php': '.php', 'ruby': '.rb', 'go': '.go', 'rust': '.rs', 'swift': '.swift',
    };
    return map[lang.toLowerCase()] ?? '.txt';
  }

  List<Widget> _renderBody(String raw, {required bool isUser, required Color linkColor}) {
    final codeFence = RegExp(r'```([a-zA-Z0-9_+-]*)\n?([\s\S]*?)```');
    final widgets = <Widget>[];
    var last = 0;
    for (final m in codeFence.allMatches(raw)) {
      if (m.start > last) {
        widgets.addAll(_renderTextWithTables(raw.substring(last, m.start), isUser: isUser, linkColor: linkColor));
      }
      widgets.add(_codeBlock((m.group(2) ?? '').trim(), m.group(1) ?? ''));
      last = m.end;
    }
    final tailWidgets = _renderTextWithTables(raw.substring(last), isUser: isUser, linkColor: linkColor);
    if (tailWidgets.isNotEmpty) {
      widgets.addAll(tailWidgets);
    } else if (widgets.isEmpty) {
      widgets.add(_textBlock(raw, isUser: isUser, linkColor: linkColor));
    }
    return widgets;
  }

  /// Splits a chunk of plain text into normal paragraphs and real markdown
  /// tables, rendering tables as an actual bordered Table widget instead of
  /// leaving raw "| a | b |" / "|---|---|" syntax visible as text.
  List<Widget> _renderTextWithTables(String raw, {required bool isUser, required Color linkColor}) {
    final lines = raw.split('\n');
    final widgets = <Widget>[];
    final textBuffer = StringBuffer();
    void flushText() {
      final chunk = textBuffer.toString().trim();
      if (chunk.isNotEmpty) widgets.add(_textBlock(chunk, isUser: isUser, linkColor: linkColor));
      textBuffer.clear();
    }

    final separatorPattern = RegExp(r'^\s*\|?\s*:?-{2,}:?\s*(\|\s*:?-{2,}:?\s*)+\|?\s*$');
    var i = 0;
    while (i < lines.length) {
      final line = lines[i];
      final next = i + 1 < lines.length ? lines[i + 1] : '';
      if (line.trim().contains('|') && separatorPattern.hasMatch(next)) {
        flushText();
        final tableLines = <String>[line];
        var j = i + 2;
        while (j < lines.length && lines[j].trim().contains('|') && lines[j].trim().isNotEmpty) {
          tableLines.add(lines[j]);
          j++;
        }
        widgets.add(_tableBlock(tableLines, isUser: isUser));
        i = j;
        continue;
      }
      textBuffer.writeln(line);
      i++;
    }
    flushText();
    return widgets;
  }

  List<String> _tableCells(String line) {
    var t = line.trim();
    if (t.startsWith('|')) t = t.substring(1);
    if (t.endsWith('|')) t = t.substring(0, t.length - 1);
    return t.split('|').map((c) => c.trim()).toList();
  }

  Widget _tableBlock(List<String> lines, {required bool isUser}) {
    final scheme = Theme.of(context).colorScheme;
    final header = _tableCells(lines.first);
    final rows = lines.skip(1).map(_tableCells).toList();
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: SingleChildScrollView(
        scrollDirection: Axis.horizontal,
        child: Table(
          defaultVerticalAlignment: TableCellVerticalAlignment.middle,
          border: TableBorder.all(color: scheme.outlineVariant.withValues(alpha: .4), width: 1, borderRadius: BorderRadius.circular(8)),
          children: [
            TableRow(
              decoration: BoxDecoration(color: kAccent.withValues(alpha: .14)),
              children: header
                  .map((cell) => Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
                        child: Text(cell, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 13)),
                      ))
                  .toList(),
            ),
            for (final row in rows)
              TableRow(
                children: [
                  for (var c = 0; c < header.length; c++)
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
                      child: Text(c < row.length ? row[c] : '', style: const TextStyle(fontSize: 13)),
                    ),
                ],
              ),
          ],
        ),
      ),
    );
  }

  Widget _textBlock(String text, {required bool isUser, required Color linkColor}) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 3),
        child: SelectableText.rich(
          TextSpan(
            children: richSpans(
              text,
              linkColor: linkColor,
              bold: isUser ? const TextStyle(fontWeight: FontWeight.w800, color: Colors.white) : null,
            ),
          ),
          textDirection: _detectDirection(text),
          style: TextStyle(
            fontSize: 15.5,
            height: 1.6,
            letterSpacing: .1,
            fontWeight: FontWeight.w400,
            color: isUser ? Colors.white : null,
          ),
        ),
      );

  Widget _codeBlock(String code, String lang) => Container(
        margin: const EdgeInsets.symmetric(vertical: 6),
        clipBehavior: Clip.antiAlias,
        decoration: BoxDecoration(
          color: const Color(0xFF14120E),
          borderRadius: BorderRadius.circular(14),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Container(
              color: Colors.white.withValues(alpha: .06),
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
              child: Row(
                children: [
                  Expanded(child: Text(lang.isEmpty ? 'code' : lang, style: const TextStyle(color: Colors.white70, fontSize: 12, fontWeight: FontWeight.w600))),
                  InkWell(
                    onTap: () async {
                      try {
                        final dir = await getApplicationDocumentsDirectory();
                        final ext = _extensionForLang(lang);
                        final path = '${dir.path}/code_${DateTime.now().millisecondsSinceEpoch}$ext';
                        await File(path).writeAsString(code);
                        await SharePlus.instance.share(ShareParams(files: [XFile(path)]));
                      } catch (e) {
                        if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('تعذر إنشاء الملف: $e')));
                      }
                    },
                    child: const Padding(
                      padding: EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                      child: Row(mainAxisSize: MainAxisSize.min, children: [
                        Icon(Icons.save_alt_outlined, size: 15, color: Colors.white70),
                        SizedBox(width: 4),
                        Text('حفظ', style: TextStyle(color: Colors.white70, fontSize: 12)),
                      ]),
                    ),
                  ),
                  InkWell(
                    onTap: () async {
                      await Clipboard.setData(ClipboardData(text: code));
                      if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('تم نسخ الكود.')));
                    },
                    child: const Padding(
                      padding: EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                      child: Row(mainAxisSize: MainAxisSize.min, children: [
                        Icon(Icons.copy_outlined, size: 15, color: Colors.white70),
                        SizedBox(width: 4),
                        Text('نسخ', style: TextStyle(color: Colors.white70, fontSize: 12)),
                      ]),
                    ),
                  ),
                ],
              ),
            ),
            SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.all(12),
              child: SelectableText(
                code,
                textDirection: TextDirection.ltr,
                style: const TextStyle(color: Color(0xFFE6E1D8), fontSize: 13.5, height: 1.5, fontFamily: 'monospace'),
              ),
            ),
          ],
        ),
      );

  Widget _videoBubble(String path) => _InlineVideo(path: path);

  Widget _bubble(Msg message) {
    final scheme = Theme.of(context).colorScheme;
    return Align(
      alignment: message.user ? Alignment.centerRight : Alignment.centerLeft,
      child: Container(
        margin: const EdgeInsets.symmetric(vertical: 5),
        padding: const EdgeInsets.all(14),
        constraints: const BoxConstraints(maxWidth: 520),
        decoration: BoxDecoration(
          color: message.user ? kAccent : scheme.surfaceContainerHighest,
          borderRadius: BorderRadius.circular(22),
          border: message.user ? null : Border.all(color: scheme.outlineVariant.withValues(alpha: .3)),
          boxShadow: [BoxShadow(blurRadius: 14, spreadRadius: -12, color: Colors.black.withValues(alpha: .22))],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            if (message.file != null) ...[
              Row(children: [
                Icon(Icons.attach_file, size: 17, color: message.user ? Colors.white : scheme.primary),
                const SizedBox(width: 5),
                Expanded(child: Text(File(message.file!).uri.pathSegments.last, overflow: TextOverflow.ellipsis)),
              ]),
              const SizedBox(height: 6),
            ],
            if (message.image != null)
              Padding(
                padding: const EdgeInsets.only(bottom: 9),
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(17),
                  child: GestureDetector(
                    onTap: () => Navigator.of(context).push(PageRouteBuilder(
                      opaque: false,
                      barrierColor: Colors.black,
                      pageBuilder: (_, _, _) => _FullscreenImage(path: message.image!),
                    )),
                    child: Image.file(File(message.image!), height: 290, width: double.infinity, fit: BoxFit.cover),
                  ),
                ),
              ),
            if (message.video != null)
              Padding(
                padding: const EdgeInsets.only(bottom: 9),
                child: _videoBubble(message.video!),
              ),
            if (!message.user)
              Padding(
                padding: const EdgeInsets.only(bottom: 6),
                child: Row(
                  children: [
                    Icon(Icons.auto_awesome, size: 16, color: scheme.primary),
                    const SizedBox(width: 5),
                    Text('AI Assistant', style: TextStyle(fontSize: 12, fontWeight: FontWeight.w700, color: scheme.primary)),
                  ],
                ),
              ),
            if (!message.user && !_animated.contains(message))
              _TypeReveal(
                text: prettyMath(message.text),
                builder: (visible) {
                  if (visible.length >= prettyMath(message.text).length) _animated.add(message);
                  return Column(crossAxisAlignment: CrossAxisAlignment.start, children: _renderBody(visible, isUser: false, linkColor: kAccentDeep));
                },
              )
            else
              ..._renderBody(
                prettyMath(message.text),
                isUser: message.user,
                linkColor: message.user ? Colors.white : kAccentDeep,
              ),
            if (!message.user && message.sources.isNotEmpty) ...[
              const SizedBox(height: 10),
              Text('🔗 المصادر والروابط', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 13, color: scheme.primary)),
              const SizedBox(height: 4),
              ...message.sources.map((url) => InkWell(
                    onTap: () async {
                      final uri = Uri.tryParse(url);
                      if (uri != null) await launchUrl(uri, mode: LaunchMode.externalApplication);
                    },
                    child: Padding(
                      padding: const EdgeInsets.symmetric(vertical: 4),
                      child: Text(
                        url,
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(color: scheme.primary, fontSize: 13, decoration: TextDecoration.underline),
                      ),
                    ),
                  )),
            ],
            if (!message.user)
              Padding(
                padding: const EdgeInsets.only(top: 4),
                child: Row(
                  children: [
                    if (message.retryOf != null)
                      _bubbleAction(Icons.refresh, 'إعادة المحاولة', () => send(message.retryOf, message.retryFile)),
                    if (message.image != null) _bubbleAction(Icons.ios_share_outlined, 'مشاركة الصورة', () async { await SharePlus.instance.share(ShareParams(files: [XFile(message.image!)])); }),
                    if (message.video != null) ...[
                      _bubbleAction(Icons.download_outlined, 'تنزيل الفيديو', () => _downloadVideoToGallery(message.video!)),
                      _bubbleAction(Icons.ios_share_outlined, 'مشاركة الفيديو', () async {
                        final path = message.video!;
                        if (path.toLowerCase().startsWith('http')) {
                          await SharePlus.instance.share(ShareParams(text: path, subject: 'AI Assistant video'));
                        } else if (File(path).existsSync()) {
                          await SharePlus.instance.share(ShareParams(files: [XFile(path)], subject: 'AI Assistant video'));
                        }
                      }),
                    ],
                    _bubbleAction(Icons.volume_up_outlined, 'استماع', () => speak(message.text)),
                    _bubbleAction(Icons.copy_outlined, 'نسخ', () async {
                      await Clipboard.setData(ClipboardData(text: prettyMath(message.text)));
                      if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('تم نسخ الإجابة.')));
                    }),
                    _bubbleAction(Icons.share_outlined, 'مشاركة', () => shareText(message.text)),
                    if (message.image == null && message.video == null)
                      _bubbleAction(Icons.save_alt_outlined, 'حفظ كملف', () async {
                        try {
                          final dir = await getApplicationDocumentsDirectory();
                          final path = '${dir.path}/رد_${DateTime.now().millisecondsSinceEpoch}.txt';
                          await File(path).writeAsString(prettyMath(message.text));
                          await SharePlus.instance.share(ShareParams(files: [XFile(path)]));
                        } catch (e) {
                          if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('تعذر إنشاء الملف: $e')));
                        }
                      }),
                    _bubbleAction(Icons.stop_circle_outlined, 'إيقاف الصوت', () async {
                      await tts.stop();
                      if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('تم إيقاف الصوت.')));
                    }),
                  ],
                ),
              ),
          ],
        ),
      ),
    );
  }

  Widget _bubbleAction(IconData icon, String tooltip, VoidCallback onPressed) {
    final scheme = Theme.of(context).colorScheme;
    return Tooltip(
      message: tooltip,
      child: Material(
        color: Colors.transparent,
        shape: const CircleBorder(),
        clipBehavior: Clip.antiAlias,
        child: InkWell(
          onTap: onPressed,
          customBorder: const CircleBorder(),
          child: Padding(
            padding: const EdgeInsets.all(7),
            child: Icon(icon, size: 16, color: scheme.onSurfaceVariant.withValues(alpha: .75)),
          ),
        ),
      ),
    );
  }

  Widget _composer() => SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(8, 5, 8, 9),
          child: Column(
            children: [
              if (listening || heard.isNotEmpty)
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.all(10),
                  margin: const EdgeInsets.only(bottom: 6),
                  decoration: BoxDecoration(
                    color: Theme.of(context).colorScheme.primaryContainer,
                    borderRadius: BorderRadius.circular(16),
                  ),
                  child: Text('🎙️ $heard'),
                ),
              if (file != null)
                Container(
                  margin: const EdgeInsets.only(bottom: 5),
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                  decoration: BoxDecoration(
                    color: Theme.of(context).colorScheme.surfaceContainerHighest,
                    borderRadius: BorderRadius.circular(16),
                  ),
                  child: Row(children: [
                    const Icon(Icons.attach_file),
                    Expanded(child: Text(File(file!).uri.pathSegments.last, overflow: TextOverflow.ellipsis)),
                    IconButton(onPressed: () => setState(() => file = null), icon: const Icon(Icons.close)),
                  ]),
                ),
              Row(
                children: [
                  PopupMenuButton<String>(
                    onSelected: (value) {
                      switch (value) {
                        case 'file':
                          pickFile();
                          break;
                        case 'image':
                          pickImage(ImageSource.gallery);
                          break;
                        case 'camera':
                          pickImage(ImageSource.camera);
                          break;
                        case 'draw':
                          draw();
                          break;
                      }
                    },
                    itemBuilder: (_) => const [
                      PopupMenuItem(value: 'file', child: Text('📎 تحليل ملف')),
                      PopupMenuItem(value: 'image', child: Text('🖼️ تحليل صورة')),
                      PopupMenuItem(value: 'camera', child: Text('📷 تصوير وتحليل')),
                      PopupMenuItem(value: 'draw', child: Text('🎨 إنشاء صورة')),
                    ],
                    child: const Padding(padding: EdgeInsets.all(10), child: Icon(Icons.add_circle_outline)),
                  ),
                  Expanded(
                    child: TextField(
                      controller: input,
                      minLines: 1,
                      maxLines: 5,
                      onSubmitted: (_) => send(),
                      decoration: const InputDecoration(hintText: 'اسألني أي شيء…'),
                    ),
                  ),
                  IconButton(
                    onPressed: voice,
                    tooltip: listening ? 'إرسال الكلام' : 'تحدث',
                    icon: Icon(listening ? Icons.stop_circle : Icons.mic_none, color: listening ? Colors.red : null),
                  ),
                  IconButton.filled(
                    onPressed: busy ? stopGenerating : () => send(),
                    tooltip: busy ? 'إيقاف التوليد' : 'إرسال',
                    icon: Icon(busy ? Icons.stop_rounded : Icons.arrow_upward_rounded),
                  ),
                ],
              ),
            ],
          ),
        ),
      );
}
