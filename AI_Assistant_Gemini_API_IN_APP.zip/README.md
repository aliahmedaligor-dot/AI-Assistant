# AI Assistant 2.0
Gemini + Groq + Google Search + sources/links + images + files + audio/video + microphone + TTS + device info + math + history + dark/light + image generation.

Upload this ZIP to the repository root with the exact name:
`AI_Assistant_Gemini_API_IN_APP.zip`

The current repository workflow extracts this ZIP and runs Flutter build.

For testing, enter Gemini/Groq keys in app Settings. For production, use Backend so API keys are not shipped in the APK.

Backend environment:
GEMINI_API_KEY
GROQ_API_KEY
GEMINI_MODEL (optional)
GROQ_MODEL (optional)
