# AI Assistant - Gemini API inside the app

This version connects directly from the Flutter Android app to Gemini.

On first use, the app asks for the Gemini API key. The key is saved locally on the device so it does not need to be entered every time.

IMPORTANT: A Gemini API key entered directly in a client app can potentially be extracted from the device/app. For a public production app, a server-side backend is safer.
