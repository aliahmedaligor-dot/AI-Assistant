import 'package:flutter_test/flutter_test.dart';

void main() {
  test('smart-math expectations documented', () {
    expect(2 + 2, 4);
    expect(2 * 3 + 4, 10);
  });
}
