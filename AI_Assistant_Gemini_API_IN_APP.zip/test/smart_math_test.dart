import 'package:flutter_test/flutter_test.dart';
import 'package:ai_assistant/main.dart';

void main() {
  test('smart-math expectations documented', () {
    expect(2 + 2, 4);
    expect(2 * 3 + 4, 10);
  });

  test('physics fast-path verifies explicit Newton inputs', () {
    final result = StemEngine.solve('احسب القوة m=5 a=3');
    expect(result, contains('15 N'));
  });

  test('physics fast-path verifies explicit speed inputs', () {
    final result = StemEngine.solve('احسب السرعة d=100 t=4');
    expect(result, contains('25 m/s'));
  });

  test('ambiguous natural-language STEM is delegated instead of guessed', () {
    final result = StemEngine.solve('عندي جسم كتلته 5 وتسارعه 3');
    expect(result, isNull);
  });
}
