import 'package:flutter_test/flutter_test.dart';
import 'package:ai_assistant/main.dart';

void main() {
  test('AI Assistant widget can be constructed', () {
    const app = AiApp();
    expect(app, isA<AiApp>());
  });
}
