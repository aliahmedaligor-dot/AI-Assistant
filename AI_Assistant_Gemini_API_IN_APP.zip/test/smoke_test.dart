import 'package:flutter_test/flutter_test.dart';
import 'package:ai_assistant/main.dart';

void main() {
  testWidgets('AI Assistant boots', (tester) async {
    await tester.pumpWidget(const AiApp());
    expect(find.text('AI Assistant'), findsOneWidget);
  });
}
