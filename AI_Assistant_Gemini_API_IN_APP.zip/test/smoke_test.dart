import 'package:flutter_test/flutter_test.dart';
import 'package:ai_assistant/main.dart';

void main() {
  test('AI Assistant app class is available', () {
    expect(AiApp, isNotNull);
  });
}
