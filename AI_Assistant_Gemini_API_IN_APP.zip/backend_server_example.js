// Backend contract for v1.3:
// POST /chat as multipart/form-data
// fields: message, web_search; optional file: image
// Return JSON: {"reply":"..."}
// Keep provider API keys on the server only.
// The server should route text + image to a multimodal model,
// and when web_search=true, use an approved search/browsing service.
// Audio transcription can be added as POST /transcribe, then send its text to /chat.
