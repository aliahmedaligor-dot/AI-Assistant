# Arabic AI Assistant - Streamlit

نسخة ويب من مساعد الذكاء الاصطناعي باستخدام Streamlit وGemini.

في Streamlit Secrets:
GEMINI_API_KEY = "مفتاحك"
AI_MODEL = "gemini-2.5-flash"

لا تضع مفتاح Gemini داخل GitHub.
