import os
import base64
import requests
import streamlit as st

st.set_page_config(page_title="Arabic AI Assistant", page_icon="🤖")
st.title("🤖 Arabic AI Assistant")
st.caption("مساعدك الذكي")

api_key = st.secrets.get("GEMINI_API_KEY", os.getenv("GEMINI_API_KEY", ""))
model = st.secrets.get("AI_MODEL", os.getenv("AI_MODEL", "gemini-2.5-flash"))

if not api_key:
    st.error("لم يتم إعداد مفتاح Gemini. أضفه في Streamlit → Settings → Secrets.")
    st.stop()

if "messages" not in st.session_state:
    st.session_state.messages = []

for m in st.session_state.messages:
    with st.chat_message(m["role"]):
        st.markdown(m["content"])

uploaded = st.file_uploader("📷 أضف صورة (اختياري)", type=["png", "jpg", "jpeg", "webp"])
prompt = st.chat_input("اكتب سؤالك هنا...")

if prompt:
    st.session_state.messages.append({"role": "user", "content": prompt})
    with st.chat_message("user"):
        st.markdown(prompt)

    parts = [{"text": (
        "أنت مساعد ذكي عربي. أجب باللغة العربية بوضوح. "
        "في المسائل الرياضية احسب بدقة. حلل الصور إذا أرسلت."
    )}]

    context = "\n".join(
        f'{m["role"]}: {m["content"]}' for m in st.session_state.messages[-10:]
    )
    parts.append({"text": "سياق المحادثة الأخيرة:\n" + context})

    if uploaded:
        parts.append({"inline_data": {
            "mime_type": uploaded.type,
            "data": base64.b64encode(uploaded.getvalue()).decode()
        }})

    url = f"https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent"
    payload = {"contents": [{"parts": parts}], "generationConfig": {"temperature": 0.7}}

    try:
        r = requests.post(
            url,
            headers={"Content-Type": "application/json", "x-goog-api-key": api_key},
            json=payload,
            timeout=90,
        )
        r.raise_for_status()
        reply = r.json()["candidates"][0]["content"]["parts"][0]["text"]
    except requests.HTTPError:
        reply = "حدث خطأ من Gemini:\n\n" + r.text
    except Exception as e:
        reply = f"تعذر الاتصال بالخادم:\n\n{e}"

    st.session_state.messages.append({"role": "assistant", "content": reply})
    with st.chat_message("assistant"):
        st.markdown(reply)

if st.button("🗑️ مسح المحادثة"):
    st.session_state.messages = []
    st.rerun()
