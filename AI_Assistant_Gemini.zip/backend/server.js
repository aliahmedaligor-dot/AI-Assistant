import 'dotenv/config';
import express from 'express';
import multer from 'multer';

const app = express();
const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 8 * 1024 * 1024 }
});

const PORT = process.env.PORT || 8080;
const MODEL = process.env.AI_MODEL || 'gemini-3.8-flash';

const SYSTEM = `أنت AI Assistant، مساعد عربي عام.
أجب بالعربية السهلة إذا كتب المستخدم بالعربية، وبنفس لغة المستخدم إن كانت مختلفة.
في الرياضيات: اعرض خطوات الحل وتحقق من النتيجة.
في أسئلة الهاتف: قدم خطوات عملية وآمنة ولا تدّعي معرفة شيء غير متاح.
في الصور: صف ما تراه بدقة وحل المسائل الظاهرة إن أمكن.
لا تخترع حقائق أو مصادر.`;

function partFromFile(file) {
  const mime = file.mimetype || 'image/jpeg';
  return {
    inline_data: {
      mime_type: mime,
      data: file.buffer.toString('base64')
    }
  };
}

app.get('/health', (_req, res) => res.json({ ok: true, model: MODEL }));

app.post('/chat', upload.single('image'), async (req, res) => {
  const message = String(req.body?.message || '').trim();

  if (!message && !req.file) {
    return res.status(400).json({ error: 'message required' });
  }

  if (!process.env.GEMINI_API_KEY) {
    return res.status(500).json({ error: 'GEMINI_API_KEY missing' });
  }

  const parts = [];
  if (message) parts.push({ text: message });
  else parts.push({ text: 'حلل هذه الصورة.' });
  if (req.file) parts.push(partFromFile(req.file));

  const payload = {
    system_instruction: { parts: [{ text: SYSTEM }] },
    contents: [{ role: 'user', parts }]
  };

  try {
    const url =
      `https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(MODEL)}:generateContent`;

    const r = await fetch(url, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-goog-api-key': process.env.GEMINI_API_KEY
      },
      body: JSON.stringify(payload)
    });

    const raw = await r.text();
    let data;
    try { data = JSON.parse(raw); } catch { data = { error: raw }; }

    if (!r.ok) {
      return res.status(r.status).json({
        error: data?.error?.message || 'Gemini request failed'
      });
    }

    const reply =
      data?.candidates?.[0]?.content?.parts
        ?.map(p => p.text || '')
        .join('')
        .trim() || 'لم تصل إجابة.';

    res.json({ reply, model: MODEL });
  } catch (e) {
    res.status(500).json({ error: 'Server error', detail: e.message });
  }
});

app.listen(PORT, '0.0.0.0', () => {
  console.log(`AI Assistant Gemini backend listening on ${PORT}`);
});
