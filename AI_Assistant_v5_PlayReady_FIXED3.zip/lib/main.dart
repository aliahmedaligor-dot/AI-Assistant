import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:image_picker/image_picker.dart';
import 'package:record/record.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main()=>runApp(const App());

class App extends StatelessWidget{
 const App({super.key});
 @override Widget build(BuildContext c)=>MaterialApp(
  debugShowCheckedModeBanner:false,title:'AI Assistant',
  theme:ThemeData(useMaterial3:true,colorSchemeSeed:const Color(0xFF6750A4),brightness:Brightness.light),
  darkTheme:ThemeData(useMaterial3:true,colorSchemeSeed:const Color(0xFF9B7BFF),brightness:Brightness.dark),
  themeMode:ThemeMode.system,home:const ChatPage());
}
class Msg{
 final String text;final bool user;final String? imagePath;
 Msg(this.text,this.user,{this.imagePath});
 Map<String,dynamic> json()=>{'text':text,'user':user,'imagePath':imagePath};
 factory Msg.from(Map<String,dynamic> x)=>Msg(x['text']??'',x['user']==true,imagePath:x['imagePath']);
}
class ChatPage extends StatefulWidget{const ChatPage({super.key});@override State<ChatPage> createState()=>_ChatPageState();}
class _ChatPageState extends State<ChatPage>{
 final input=TextEditingController(),scroll=ScrollController(),recorder=AudioRecorder();
 final picker=ImagePicker();
 List<Msg> msgs=[];bool loading=false,recording=false,webSearch=false;String? pendingImage;

 static const apiUrl='https://YOUR-BACKEND.example.com/chat';

 @override void initState(){super.initState();load();}
 @override void dispose(){input.dispose();scroll.dispose();recorder.dispose();super.dispose();}
 Future<void> load()async{final p=await SharedPreferences.getInstance(),s=p.getString('msgs');if(s!=null)setState(()=>msgs=(jsonDecode(s) as List).map((x)=>Msg.from(x)).toList());}
 Future<void> save()async{final p=await SharedPreferences.getInstance();await p.setString('msgs',jsonEncode(msgs.map((x)=>x.json()).toList()));}
 void jump()=>WidgetsBinding.instance.addPostFrameCallback((_){if(scroll.hasClients)scroll.animateTo(scroll.position.maxScrollExtent,duration:const Duration(milliseconds:280),curve:Curves.easeOut);});
 void ask(String s){input.text=s;send();}

 Future<void> chooseImage()async{
  final x=await picker.pickImage(source:ImageSource.gallery,imageQuality:80,maxWidth:1600);
  if(x!=null)setState(()=>pendingImage=x.path);
 }
 Future<void> takePhoto()async{
  final x=await picker.pickImage(source:ImageSource.camera,imageQuality:80,maxWidth:1600);
  if(x!=null)setState(()=>pendingImage=x.path);
 }
 Future<void> toggleRecording()async{
  if(recording){await recorder.stop();setState(()=>recording=false);return;}
  if(!await recorder.hasPermission()){if(mounted)ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('يلزم السماح بالميكروفون للتسجيل الصوتي.')));return;}
  final dir=Directory.systemTemp.path;
  await recorder.start(const RecordConfig(encoder:AudioEncoder.aacLc),path:'$dir/ai_${DateTime.now().millisecondsSinceEpoch}.m4a');
  setState(()=>recording=true);
 }

 Future<void> send()async{
  final q=input.text.trim();if((q.isEmpty&&pendingImage==null)||loading)return;
  final image=pendingImage;input.clear();setState((){msgs.add(Msg(q.isEmpty?'حلل هذه الصورة':q,true,imagePath:image));pendingImage=null;loading=true;});await save();jump();
  try{
   final request=http.MultipartRequest('POST',Uri.parse(apiUrl));
   request.fields['message']=q.isEmpty?'حلل هذه الصورة':q;
   request.fields['web_search']=webSearch?'true':'false';
   if(image!=null)request.files.add(await http.MultipartFile.fromPath('image',image));
   final streamed=await request.send().timeout(const Duration(seconds:90));
   final body=await streamed.stream.bytesToString();
   final d=jsonDecode(body);
   msgs.add(Msg(streamed.statusCode>=200&&streamed.statusCode<300?(d['reply']??'لم تصل إجابة.'):'حدث خطأ في الخادم.',false));
  }catch(_){msgs.add(Msg('تعذر الاتصال بالخادم. تأكد من رابط الـBackend والإنترنت.',false));}
  setState(()=>loading=false);await save();jump();
 }

 @override Widget build(BuildContext c)=>Directionality(textDirection:TextDirection.rtl,child:Scaffold(
  appBar:AppBar(
   title:Row(children:[Container(width:42,height:42,decoration:BoxDecoration(
    gradient:const LinearGradient(colors:[Color(0xFF6750A4),Color(0xFF9B7BFF)]),borderRadius:BorderRadius.circular(13)),
    child:const Icon(Icons.auto_awesome,color:Colors.white)),const SizedBox(width:12),
    const Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text('AI Assistant',style:TextStyle(fontWeight:FontWeight.w800,fontSize:18)),Text('مساعدك الذكي',style:TextStyle(fontSize:12))])]),
   actions:[IconButton(tooltip:'البحث على الإنترنت',onPressed:()=>setState(()=>webSearch=!webSearch),
    icon:Icon(webSearch?Icons.travel_explore:Icons.language_outlined,color:webSearch?Theme.of(c).colorScheme.primary:null)),
    IconButton(tooltip:'مسح',onPressed:msgs.isEmpty?null:()async{setState(()=>msgs=[]);await save();},icon:const Icon(Icons.delete_sweep_outlined))]),
  body:Column(children:[
   if(webSearch)Container(width:double.infinity,padding:const EdgeInsets.symmetric(horizontal:16,vertical:7),color:Theme.of(c).colorScheme.primaryContainer,
    child:const Text('🌐 البحث مفعّل — سيطلب التطبيق من الخادم استخدام مصادر حديثة عند توفرها.')),
   Expanded(child:msgs.isEmpty?_home():ListView.builder(controller:scroll,padding:const EdgeInsets.fromLTRB(16,8,16,18),itemCount:msgs.length+(loading?1:0),
    itemBuilder:(c,i)=>i<msgs.length?_bubble(msgs[i]):_bubble(Msg('يفكر الآن…',false)))),
   _composer()
  ])));

 Widget _home()=>ListView(padding:const EdgeInsets.fromLTRB(20,24,20,12),children:[
  Container(padding:const EdgeInsets.all(24),decoration:BoxDecoration(borderRadius:BorderRadius.circular(28),
   gradient:LinearGradient(begin:Alignment.topRight,end:Alignment.bottomLeft,colors:[Theme.of(context).colorScheme.primaryContainer,Theme.of(context).colorScheme.surfaceContainerHighest]))),
   child:Column(children:[Container(width:68,height:68,decoration:BoxDecoration(shape:BoxShape.circle,color:Theme.of(context).colorScheme.surface.withOpacity(.75)),
    child:Icon(Icons.auto_awesome,size:34,color:Theme.of(context).colorScheme.primary)),const SizedBox(height:16),
    const Text('أهلاً بك 👋',style:TextStyle(fontSize:29,fontWeight:FontWeight.w800)),const SizedBox(height:7),
    Text('اسألني، أرسل صورة، أو استخدم صوتك. أستطيع مساعدتك في الرياضيات والجوال والدراسة والبرمجة والأسئلة العامة.',textAlign:TextAlign.center,style:TextStyle(color:Theme.of(context).colorScheme.onSurfaceVariant,fontSize:15,height:1.4))])),
  const SizedBox(height:22),const Text('ماذا تريد أن تفعل؟',style:TextStyle(fontWeight:FontWeight.w700,fontSize:16)),const SizedBox(height:12),
  _card('🧮','حل مسألة رياضيات','حل 125 × 48 خطوة بخطوة وتحقق من الناتج'),
  _card('📷','حل من صورة','أرسل صورة لمسألة رياضيات وحاول حلها'),
  _card('📱','مساعدة في الجوال','كيف أفرغ مساحة من هاتفي؟'),
  _card('🌐','سؤال يحتاج معلومات حديثة','ابحث عن آخر أخبار Android ومزاياه الجديدة')]);

 Widget _card(String icon,String title,String q)=>InkWell(onTap:()=>ask(q),borderRadius:BorderRadius.circular(18),child:Container(
  margin:const EdgeInsets.only(bottom:10),padding:const EdgeInsets.all(15),
  decoration:BoxDecoration(color:Theme.of(context).colorScheme.surfaceContainerLow,borderRadius:BorderRadius.circular(18),border:Border.all(color:Theme.of(context).colorScheme.outlineVariant)),
  child:Row(children:[Text(icon,style:const TextStyle(fontSize:25)),const SizedBox(width:13),Expanded(child:Text(title,style:const TextStyle(fontWeight:FontWeight.w700))),const Icon(Icons.arrow_back_ios_new,size:16)])));

 Widget _bubble(Msg m)=>Padding(padding:const EdgeInsets.symmetric(vertical:5),child:Row(
  crossAxisAlignment:CrossAxisAlignment.start,mainAxisAlignment:m.user?MainAxisAlignment.start:MainAxisAlignment.end,children:[
   if(!m.user)Container(width:34,height:34,margin:const EdgeInsets.only(left:8,top:2),decoration:BoxDecoration(shape:BoxShape.circle,color:Theme.of(context).colorScheme.primaryContainer),child:Icon(Icons.auto_awesome,size:18,color:Theme.of(context).colorScheme.primary)),
   Flexible(child:Container(padding:const EdgeInsets.symmetric(horizontal:16,vertical:13),decoration:BoxDecoration(
    color:m.user?Theme.of(context).colorScheme.primary:Theme.of(context).colorScheme.surfaceContainerHighest,
    borderRadius:BorderRadius.only(topLeft:const Radius.circular(20),topRight:const Radius.circular(20),bottomLeft:Radius.circular(m.user?20:5),bottomRight:Radius.circular(m.user?5:20))),
    child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
     if(m.imagePath!=null&&File(m.imagePath!).existsSync())ClipRRect(borderRadius:BorderRadius.circular(12),child:Image.file(File(m.imagePath!),height:180,width:260,fit:BoxFit.cover)),
     if(m.imagePath!=null)const SizedBox(height:7),
     SelectableText(m.text,style:TextStyle(color:m.user?Theme.of(context).colorScheme.onPrimary:null,fontSize:16,height:1.45))
    ])))
  ]));

 Widget _composer()=>SafeArea(child:Padding(padding:const EdgeInsets.fromLTRB(10,7,10,10),child:Column(children:[
  if(pendingImage!=null)Container(width:double.infinity,margin:const EdgeInsets.only(bottom:7),padding:const EdgeInsets.all(8),
   decoration:BoxDecoration(color:Theme.of(context).colorScheme.surfaceContainerHighest,borderRadius:BorderRadius.circular(15)),
   child:Row(children:[ClipRRect(borderRadius:BorderRadius.circular(10),child:Image.file(File(pendingImage!),width:55,height:55,fit:BoxFit.cover)),const SizedBox(width:10),const Expanded(child:Text('الصورة جاهزة للتحليل')),IconButton(onPressed:()=>setState(()=>pendingImage=null),icon:const Icon(Icons.close))])),
  Row(crossAxisAlignment:CrossAxisAlignment.end,children:[
   PopupMenuButton<String>(onSelected:(v){if(v=='gallery')chooseImage();if(v=='camera')takePhoto();},itemBuilder:(c)=>const[
    PopupMenuItem(value:'gallery',child:ListTile(leading:Icon(Icons.photo_library_outlined),title:Text('اختيار صورة'))),
    PopupMenuItem(value:'camera',child:ListTile(leading:Icon(Icons.camera_alt_outlined),title:Text('تصوير')))],
    child:const Padding(padding:EdgeInsets.all(12),child:Icon(Icons.add_circle_outline))),
   Expanded(child:TextField(controller:input,minLines:1,maxLines:5,decoration:InputDecoration(hintText:recording?'جاري التسجيل…':'اسأل AI Assistant…',filled:true,fillColor:Theme.of(context).colorScheme.surfaceContainerHighest,contentPadding:const EdgeInsets.symmetric(horizontal:18,vertical:13),border:OutlineInputBorder(borderRadius:BorderRadius.circular(25),borderSide:BorderSide.none)))),
   const SizedBox(width:5),
   IconButton(onPressed:toggleRecording,tooltip:recording?'إيقاف التسجيل':'تسجيل صوت',icon:Icon(recording?Icons.stop_circle_outlined:Icons.mic_none_rounded,color:recording?Colors.red:null)),
   const SizedBox(width:2),SizedBox(width:50,height:50,child:IconButton.filled(onPressed:loading?null:send,icon:const Icon(Icons.arrow_upward_rounded)))
  ])
 ])));
}
